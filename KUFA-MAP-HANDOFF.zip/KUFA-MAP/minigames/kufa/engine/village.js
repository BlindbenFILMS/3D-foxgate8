// 8 GATES · KUFA WORLD — the small helpers from village-game.js, COPIED UNCHANGED (rnd/rr/pick/clamp/smooth/lerp/damp, makeGradient, glowTexture, dotTexture, Ambience).
// The full village-game.js is not loaded in the world (it is a whole other game).
import * as THREE from '../../../vendor/three/three.module.js';
let seed = 20260930;
const rnd = () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
const rr = (a, b) => a + rnd() * (b - a);
const pick = a => a[Math.floor(rnd() * a.length)];
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const lerp = (a, b, t) => a + (b - a) * t;
const damp = (a, b, k, dt) => lerp(a, b, 1 - Math.exp(-k * dt));
function makeGradient() {
  const tones = [70, 150, 215, 255];
  const data = new Uint8Array(tones.length * 4);
  tones.forEach((t, i) => data.set([t, t, t, 255], i * 4));
  const tex = new THREE.DataTexture(data, tones.length, 1, THREE.RGBAFormat);
  tex.minFilter = tex.magFilter = THREE.NearestFilter; tex.generateMipmaps = false; tex.needsUpdate = true;
  return tex;
}
function glowTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const g = c.getContext('2d'); const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.25, 'rgba(255,255,255,0.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
function dotTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 32;
  const g = c.getContext('2d'); g.fillStyle = '#fff'; g.beginPath(); g.arc(16, 16, 14, 0, 7); g.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
class Ambience {
  constructor() { this.ctx = null; this.muted = false; this.tBird = 2; this.tCricket = 1; }
  init() {
    if (this.ctx) { this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    const ctx = this.ctx = new AC();
    this.master = ctx.createGain(); this.master.gain.value = this.muted ? 0 : 0.6; this.master.connect(ctx.destination);
    const buf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate); const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    this.noise = buf;
    const loop = (filters, g) => { const s = ctx.createBufferSource(); s.buffer = buf; s.loop = true; let n = s; for (const f of filters) { n.connect(f); n = f; } const gain = ctx.createGain(); gain.gain.value = g; n.connect(gain); gain.connect(this.master); s.start(); return gain; };
    const bq = (type, f, q = 0.7) => { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; return b; };
    this.wind = loop([bq('lowpass', 380)], 0.1);
    this.rain = loop([bq('highpass', 900), bq('lowpass', 7000)], 0);
    this.water = loop([bq('bandpass', 2400, 0.9)], 0);
  }
  setMuted(m) { this.muted = m; if (this.master) this.master.gain.setTargetAtTime(m ? 0 : 0.6, this.ctx.currentTime, 0.1); }
  tone(freq, dur, vol, type = 'sine', sweep = 0, pan = 0) {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t = ctx.currentTime;
    const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(freq, t); if (sweep) o.frequency.exponentialRampToValueAtTime(freq * sweep, t + dur);
    const g = ctx.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    const p = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    if (p) { p.pan.value = pan; o.connect(g); g.connect(p); p.connect(this.master); } else { o.connect(g); g.connect(this.master); }
    o.start(t); o.stop(t + dur + 0.05);
  }
  burst(dur, f, vol) {
    if (!this.ctx || this.muted) return; const ctx = this.ctx, t = ctx.currentTime;
    const s = ctx.createBufferSource(); s.buffer = this.noise; const b = ctx.createBiquadFilter(); b.type = 'lowpass'; b.frequency.value = f;
    const g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(b); b.connect(g); g.connect(this.master); s.start(t, Math.random()); s.stop(t + dur + 0.02);
  }
  step() { this.burst(0.07, 700 + Math.random() * 400, 0.12); }
  blip() { this.tone(880, 0.08, 0.05, 'triangle'); }
  update(dt, e) {
    if (!this.ctx) return; const t = this.ctx.currentTime;
    this.wind.gain.setTargetAtTime(0.07 + 0.08 * e.fog + 0.1 * e.rain + 0.03 * Math.sin(t * 0.3), t, 0.5);
    this.rain.gain.setTargetAtTime(0.32 * e.rain, t, 0.6);
    this.water.gain.setTargetAtTime(0.05 * (1 - smooth(4, 20, e.fountainDist)), t, 0.2);
    if (e.day > 0.5 && e.rain < 0.5 && (this.tBird -= dt) < 0) {
      this.tBird = rr(1.5, 6); const f = rr(2200, 3600), pan = rr(-0.8, 0.8), n = 2 + Math.floor(rnd() * 3);
      for (let i = 0; i < n; i++) setTimeout(() => this.tone(f * rr(0.9, 1.15), 0.09, 0.025, 'sine', rr(1.2, 1.6), pan), i * 110);
    }
    if (e.night > 0.5 && e.rain < 0.5 && (this.tCricket -= dt) < 0) {
      this.tCricket = rr(0.3, 1.2); const pan = rr(-1, 1);
      for (let i = 0; i < 3; i++) setTimeout(() => this.tone(4600, 0.03, 0.012, 'sine', 0, pan), i * 45);
    }
  }
  dispose() { try { this.ctx && this.ctx.close(); } catch (e) {} }
}
export { rnd, rr, pick, clamp, smooth, lerp, damp, makeGradient, glowTexture, dotTexture, Ambience };
