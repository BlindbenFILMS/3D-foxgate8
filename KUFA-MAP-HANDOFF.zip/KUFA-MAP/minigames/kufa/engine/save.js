// 8 GATES · KUFA WORLD — the SAVE ADAPTER (in memory while building; the main project swaps in engine/save.js at the merge)
const data = { v: 1, world: 'kufa', zone: 'kufaTownSquare', gold: 50, xp: 0, items: {}, relics: [], outfit: null, flags: {}, stats: {} }, subs = new Set(), changed = () => subs.forEach(f => { try { f(data); } catch (e) {} });
export const save = {
  get data() { return data; }, flag: k => !!data.flags[k], setFlag(k, v = true) { if (v) data.flags[k] = true; else delete data.flags[k]; changed(); },
  test(req) { const L = req == null ? [] : [].concat(req); return !!L.length && L.every(k => { k = String(k); const not = k[0] === '!'; return !!data.flags[not ? k.slice(1) : k] !== not; }); },
  stat: (k, d = 0) => data.stats[k] ?? d, setStat(k, v) { data.stats[k] = v; changed(); }, best(k, v) { if (v > (data.stats[k] || 0)) { data.stats[k] = v; changed(); return true; } return false; },
  addGold(n) { data.gold = Math.max(0, data.gold + n); changed(); return data.gold; }, spend(n) { if (data.gold < n) return false; data.gold -= n; changed(); return true; }, addXp(n) { data.xp += n; changed(); return data.xp; },
  count: id => data.items[id] || 0, give(id, n = 1) { data.items[id] = (data.items[id] || 0) + n; changed(); }, take(id, n = 1) { if ((data.items[id] || 0) < n) return false; data.items[id] -= n; changed(); return true; },
  dropRelic(id) { const i = data.relics.indexOf(id); if (i < 0) return false; data.relics.splice(i, 1); changed(); return true; }, addRelic(id) { if (!data.relics.includes(id)) { data.relics.push(id); changed(); } },
  setOutfit(o) { data.outfit = o; changed(); }, where(world, zone) { data.world = world; if (zone) data.zone = zone; }, on(fn) { subs.add(fn); return () => subs.delete(fn); }, reset() {}, reload: () => data,
};

