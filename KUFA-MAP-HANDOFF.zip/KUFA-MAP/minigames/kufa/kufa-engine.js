// 8 GATES · KUFA WORLD — the ONE engine adapter the copied game files import instead of the big shared files
// (village-game.js, meru-game.js, engine/textures.js, engine/cast.js, engine/save.js, engine/restaurant-kit.js, fox-kit.js).
// Why: meru-game.js pulls in the whole Meru world (~1 MB of modules). The world loads only these small copies:
//   engine/village.js (helpers + Ambience, copied unchanged) · engine/textures.js (copied) · fox-kit.js + engine/cast.js (copied, the real foxes)
//   engine/save.js (the SAVE ADAPTER: in memory while building; the main project swaps in its engine/save.js at the merge)
//   engine/restaurant-kit.js (copied + WORLD MODE in createStage: the game draws through the world's renderer)
// AT THE MERGE: point these imports back at the real engine files of the main project (same names, same signatures).
import * as THREE from '../../vendor/three/three.module.js';
import { rr, clamp, damp, smooth, pick, makeGradient } from './engine/village.js';
import { canvasTex } from './engine/textures.js';
export { rnd, rr, pick, clamp, smooth, lerp, damp, makeGradient, glowTexture, dotTexture, Ambience } from './engine/village.js';
export { FONT, canvasTex, crestTex, emblemTex, signTex, bannerTex } from './engine/textures.js';
export { foxKit, PLAYER_MALE, PLAYER_FEMALE, HOPE_LOOK } from './fox-kit.js';
export { CAST, castKit, loadCastRigs } from './engine/cast.js';
export { save } from './engine/save.js';
export { createStage, cameraFit, hintRings, registerKit, dinerUniform } from './engine/restaurant-kit.js';

// ---- the room ctx the repo room builders expect (same shape as restaurant-kit createStage's toon / M / addOutline / canvasTex)
export function roomCtx(parent, { touch = false } = {}) {
  const grad = makeGradient(), cache = new Map(), V3 = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
  const toon = (c, extra) => { const k = c + (extra ? JSON.stringify(extra) : ''); if (!cache.has(k)) cache.set(k, new THREE.MeshToonMaterial({ color: c, gradientMap: grad, ...extra })); return cache.get(k); };
  toon.grad = grad;
  const outlineMat = new THREE.MeshBasicMaterial({ color: 0x1a1626, side: THREE.BackSide });
  function addOutline(mesh, t = 0.04, radius) { if (touch) return mesh; const g = mesh.geometry; g.computeBoundingBox(); const s = V3(); g.boundingBox.getSize(s); const o = new THREE.Mesh(g, outlineMat); if (radius) o.scale.setScalar(1 + t / radius); else o.scale.set(1 + 2 * t / Math.max(s.x, 0.01), 1 + 2 * t / Math.max(s.y, 0.01), 1 + 2 * t / Math.max(s.z, 0.01)); mesh.add(o); return mesh; }
  function M(geo, mat, x = 0, y = 0, z = 0, p, outline = 0.02, radius) { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); if (outline) addOutline(m, outline, radius); (p || parent).add(m); return m; }
  M.scene = parent;
  return { THREE, T3: THREE, scene: parent, toon, M, addOutline, outlineMat, grad, canvasTex, CTX: canvasTex, V3, rr, clamp, damp, smooth, pick, touch };
}
