// 8 GATES · KUFA — TREASURE DIG (open-air JOB at layout spot kufaTreasureDig, the east dunes). Built NEW for the world (Phase 4): no page of its own.
// createTreasureDig(host) — host = { container, renderer, onState, active(), bd } from worlds/kufa-games.js (bd.grp = a group at the spot, local metres, +z south).
// The set: a roped 17 x 17 m patch of gently mounded sand, SOUTH of the spot marker (so the world's "TREASURE DIG" label floats behind it as a title),
// a 6 x 6 grid of 2 m squares (rows A–F north→south, columns 1–6 west→east), marker stakes, a caravan obelisk stump, a sieve, a shovel.
// Play: 3 rounds. Each round hides 3 finds (round 3: 4, a GOLD RELIC joins). Limited digs (14 / 12 / 10). Each empty hole says HOT / WARM / COLD
// (distance in squares, diagonals count, to the nearest find still buried) with a red / orange / blue ring and a beep that rises when hot.
// HINT (once a round, costs 2 digs) rings the row of the find nearest the cursor. Score = finds × 100 + digs left × 20, per round.
// Controls: tap a square in 3D (digs it), or the big buttons (arrows move the yellow cursor, DIG digs it); keys: arrows, Enter/Space, H.
// The world renders: tick(dt) only updates. The camera is a child of our group; the host eases the walk camera to it.
// DRAFT (Ben): the finds' names, the dig counts, the points, the HOT/WARM/COLD distances.
import * as THREE from '../../../vendor/three/three.module.js';

export const GAME = { key: 'kufaTreasureDig', name: 'TREASURE DIG' };
const N = 6, CELL = 2, PZ = 8.5, HALF = 8.5, ROWS = 'ABCDEF';
// DRAFT: finds + rounds
export const FINDS = {
  coins: { name: 'OLD COINS', pts: 100, col: '#e6b45a' },
  lamp: { name: 'CLAY LAMP', pts: 100, col: '#c0643a' },
  bell: { name: 'CARAVAN BELL', pts: 100, col: '#d9a441' },
  relic: { name: 'GOLD RELIC', pts: 100, col: '#ffd23a' },
};
export const ROUNDS = [{ digs: 14, finds: ['coins', 'lamp', 'bell'] }, { digs: 12, finds: ['coins', 'lamp', 'bell'] }, { digs: 10, finds: ['coins', 'lamp', 'bell', 'relic'] }];
const PER_FIND = 100, PER_DIG = 20, HINT_COST = 2;
const HEAT = {
  hot: { word: 'HOT', col: '#ec3013', fg: '#ffffff', line: 'VERY CLOSE · A FIND IS NEXT TO THIS HOLE' },
  warm: { word: 'WARM', col: '#ff8a1f', fg: '#000000', line: 'CLOSE · A FIND IS 2 SQUARES AWAY' },
  cold: { word: 'COLD', col: '#38bdf8', fg: '#000000', line: 'FAR · NOTHING NEAR THIS HOLE' },
};
const cellName = (r, c) => ROWS[r] + (c + 1);
const cheb = (a, b) => Math.max(Math.abs(a.r - b.r), Math.abs(a.c - b.c));
const smooth = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
// sand height (local metres) — gently mounded, falls to the ground at the patch edge
const hAt = (x, z) => { const zr = z - PZ, e = smooth(0, 1.1, HALF - Math.max(Math.abs(x), Math.abs(zr))); return e * (0.38 + 0.2 * (1 - (x / HALF) ** 2) * (1 - (zr / HALF) ** 2) + 0.03 * Math.sin(x * 1.7) * Math.sin(zr * 1.3)); };
const cellXZ = (r, c) => [(c - 2.5) * CELL, PZ + (r - 2.5) * CELL];

// the static dig patch (sand, grid + labels, rope, stakes, obelisk, sieve, shovel). Used by the game AND, while walking, by the host (idle set).
function buildSet(grp, keep) {
  const grad = keep(new THREE.DataTexture(new Uint8Array([95, 175, 255]), 3, 1, THREE.RedFormat)); grad.minFilter = grad.magFilter = THREE.NearestFilter; grad.needsUpdate = true;
  const toon = (color, extra) => keep(new THREE.MeshToonMaterial({ color, gradientMap: grad, ...extra }));
  const basic = (color, extra) => keep(new THREE.MeshBasicMaterial({ color, ...extra }));
  const outlineMat = basic('#1a1410', { side: THREE.BackSide });
  const add = (geo, mat, x = 0, y = 0, z = 0, p = grp) => { keep(geo); const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); p.add(m); return m; };
  const hull = (m, s = 1.08) => { const o = new THREE.Mesh(m.geometry, outlineMat); o.scale.setScalar(s); m.add(o); return o; };
  const canvasTex = (w, h, draw) => { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return keep(t); };
  const FONT = '"Archivo", "Arial Black", Arial, sans-serif';

  // ---------- the board: one mesh, grid + labels painted on ----------
  const PPM = 1024 / (HALF * 2), X = x => (x + HALF) * PPM, Y = zr => (zr + HALF) * PPM;
  const boardTex = canvasTex(1024, 1024, (g) => {
    g.fillStyle = '#e9c681'; g.fillRect(0, 0, 1024, 1024);
    g.strokeStyle = 'rgba(160,110,50,0.18)'; g.lineWidth = 4; for (let i = 0; i < 26; i++) { g.beginPath(); const y0 = i * 42 + 10; g.moveTo(0, y0); for (let x = 0; x <= 1024; x += 32) g.lineTo(x, y0 + Math.sin(x * 0.02 + i) * 7); g.stroke(); }
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) { g.fillStyle = (r + c) % 2 ? '#e0b467' : '#f2d596'; g.fillRect(X((c - 3) * CELL), Y((r - 3) * CELL), CELL * PPM, CELL * PPM); }
    g.strokeStyle = '#7a5328'; g.lineWidth = 5; for (let i = 0; i <= N; i++) { const v = (i - 3) * CELL; g.beginPath(); g.moveTo(X(v), Y(-6)); g.lineTo(X(v), Y(6)); g.stroke(); g.beginPath(); g.moveTo(X(-6), Y(v)); g.lineTo(X(6), Y(v)); g.stroke(); }
    g.lineWidth = 10; g.strokeRect(X(-6), Y(-6), 12 * PPM, 12 * PPM);
    g.fillStyle = '#201e1d'; g.font = '900 78px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle';
    for (let i = 0; i < N; i++) { const v = (i - 2.5) * CELL; g.fillText(ROWS[i], X(-7.15), Y(v)); g.fillText(ROWS[i], X(7.15), Y(v)); g.fillText(String(i + 1), X(v), Y(7.15)); }
  });
  const boardGeo = new THREE.PlaneGeometry(HALF * 2, HALF * 2, 34, 34); boardGeo.rotateX(-Math.PI / 2); boardGeo.translate(0, 0, PZ);
  { const p = boardGeo.attributes.position; for (let i = 0; i < p.count; i++) p.setY(i, hAt(p.getX(i), p.getZ(i))); boardGeo.computeVertexNormals(); }
  const board = add(boardGeo, toon('#ffffff', { map: boardTex }));

  // ---------- rope, posts, stakes ----------
  const R8 = 8.1, postPts = []; for (const [x, z] of [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]) postPts.push([x * R8, PZ + z * R8]);
  const postGeo = keep(new THREE.CylinderGeometry(0.11, 0.14, 1.25, 7)); postGeo.translate(0, 0.62, 0);
  const posts = new THREE.InstancedMesh(postGeo, toon('#6b4424'), postPts.length); const M4 = new THREE.Matrix4(), Q0 = new THREE.Quaternion(), S1 = new THREE.Vector3(1, 1, 1), V = new THREE.Vector3();
  postPts.forEach(([x, z], i) => posts.setMatrixAt(i, M4.compose(V.set(x, 0, z), Q0, S1))); grp.add(posts);
  const ropeGeo = keep(new THREE.BoxGeometry(1, 0.09, 0.09)); const ropes = new THREE.InstancedMesh(ropeGeo, toon('#ec3013'), postPts.length * 2);
  postPts.forEach(([x, z], i) => { const [x2, z2] = postPts[(i + 1) % postPts.length], L = Math.hypot(x2 - x, z2 - z), q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), -Math.atan2(z2 - z, x2 - x));
    for (const [k, y] of [[0, 1.12], [1, 0.62]]) ropes.setMatrixAt(i * 2 + k, M4.compose(V.set((x + x2) / 2, y, (z + z2) / 2), q, new THREE.Vector3(L, 1, 1))); }); grp.add(ropes);
  const stakePts = [[-6, PZ - 6], [6, PZ - 6], [-6, PZ + 6], [6, PZ + 6]];
  const stakeGeo = keep(new THREE.BoxGeometry(0.14, 1.5, 0.14)); stakeGeo.translate(0, 0.75, 0); const stakes = new THREE.InstancedMesh(stakeGeo, toon('#f3f2f2'), 4);
  const flagGeo = keep(new THREE.BufferGeometry()); flagGeo.setAttribute('position', new THREE.Float32BufferAttribute([0, 1.5, 0, 0, 1.0, 0, 0.7, 1.25, 0], 3)); flagGeo.computeVertexNormals();
  const flags = new THREE.InstancedMesh(flagGeo, toon('#ffd23a', { side: THREE.DoubleSide }), 4);
  stakePts.forEach(([x, z], i) => { const y = hAt(x, z) - 0.15; stakes.setMatrixAt(i, M4.compose(V.set(x, y, z), Q0, S1)); flags.setMatrixAt(i, M4.compose(V.set(x, y, z), new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), 0.5), S1)); });
  grp.add(stakes, flags);

  // ---------- props: obelisk stump (NE), sieve (SW), shovel (SE) ----------
  const obGeo = new THREE.CylinderGeometry(0.55, 0.8, 1.7, 4, 1); obGeo.rotateY(Math.PI / 4);
  { const p = obGeo.attributes.position; for (let i = 0; i < p.count; i++) if (p.getY(i) > 0) p.setY(i, p.getY(i) + (p.getX(i) > 0 ? 0.25 : -0.15) + (p.getZ(i) > 0 ? 0.1 : 0)); obGeo.computeVertexNormals(); }
  const ob = add(obGeo, toon('#b8a07c'), 7.0, hAt(7, PZ - 7) + 0.7, PZ - 7.0); ob.rotation.y = 0.3; hull(ob, 1.06);
  const obBand = add(new THREE.BoxGeometry(1.25, 0.18, 1.25), toon('#7a5a3a'), 7.0, hAt(7, PZ - 7) + 0.55, PZ - 7.0); obBand.rotation.y = 0.3 + Math.PI / 4;
  const sieve = new THREE.Group(); sieve.position.set(-7.0, hAt(-7, PZ + 7) + 0.35, PZ + 7.0); sieve.rotation.set(-0.9, 0.5, 0); grp.add(sieve);
  add(new THREE.TorusGeometry(0.62, 0.09, 6, 18), toon('#8a5a2e'), 0, 0, 0, sieve);
  const mesh = add(new THREE.CircleGeometry(0.6, 18), toon('#5f5a55', { side: THREE.DoubleSide, transparent: true, opacity: 0.75 }), 0, 0, 0, sieve);
  add(new THREE.ConeGeometry(0.7, 0.45, 10), toon('#e2b56c'), -7.0, hAt(-7, PZ + 7) + 0.2, PZ + 7.6);   // a little pile of sieved sand
  // shovel: pivot at the blade tip (what goes into the sand)
  const shovel = new THREE.Group(); grp.add(shovel);
  const blade = add(new THREE.BoxGeometry(0.42, 0.5, 0.06), toon('#9aa3ab'), 0, 0.25, 0, shovel); hull(blade, 1.12);
  const shaft = add(new THREE.CylinderGeometry(0.05, 0.05, 1.5, 6), toon('#8a5a2e'), 0, 1.25, 0, shovel); hull(shaft, 1.25);
  add(new THREE.BoxGeometry(0.36, 0.08, 0.08), toon('#201e1d'), 0, 2.0, 0, shovel);
  const SHOVEL_HOME = new THREE.Vector3(6.9, hAt(6.9, PZ + 7.3) - 0.25, PZ + 7.3);
  shovel.position.copy(SHOVEL_HOME); shovel.rotation.set(0.25, 0.4, -0.2); shovel.scale.setScalar(1.4);
  return { grad, toon, basic, outlineMat, add, hull, canvasTex, FONT, board, shovel, SHOVEL_HOME, M4, Q0, S1, V };
}
// KUFA WORLD idle set: the host calls this at world load (entry idle: 'buildTreasureDigSet') and hides the returned group while the game plays.
export function buildTreasureDigSet(_THREE, parent) { const g = new THREE.Group(); g.name = 'treasureDigIdle'; buildSet(g, o => o); parent.add(g); return g; }

export function createTreasureDig(host) {
  const { renderer, onState = () => {}, bd } = host, active = () => { try { return host.active(); } catch (e) { return false; } };
  const el = renderer.domElement;
  const grp = new THREE.Group(); grp.name = 'treasureDig'; bd.grp.add(grp);
  const disposables = [];
  const keep = o => { disposables.push(o); return o; };
  const { toon, basic, outlineMat, add, hull, canvasTex, FONT, board, shovel, SHOVEL_HOME, M4, Q0, S1, V } = buildSet(grp, keep);

  // ---------- holes, heat rings, cursor, hint frame, word sign, puff ----------
  const holeGeo = keep(new THREE.CircleGeometry(0.62, 20)); holeGeo.rotateX(-Math.PI / 2);
  const holes = new THREE.InstancedMesh(holeGeo, basic('#4a2f17'), N * N); holes.count = 0; grp.add(holes);
  const rimGeo = keep(new THREE.TorusGeometry(0.66, 0.15, 6, 20)); rimGeo.rotateX(-Math.PI / 2); rimGeo.scale(1, 0.6, 1);
  const rims = new THREE.InstancedMesh(rimGeo, toon('#c99a52'), N * N); rims.count = 0; grp.add(rims);
  const ringGeo = keep(new THREE.RingGeometry(0.78, 0.96, 28)); ringGeo.rotateX(-Math.PI / 2);
  const rings = new THREE.InstancedMesh(ringGeo, basic('#ffffff', { side: THREE.DoubleSide }), N * N); rings.count = 0; rings.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(N * N * 3), 3); grp.add(rings);
  const curGeo = keep(new THREE.RingGeometry(1.08, 1.38, 4, 1)); curGeo.rotateZ(Math.PI / 4); curGeo.rotateX(-Math.PI / 2);
  const cursorM = add(curGeo, basic('#ffd23a', { side: THREE.DoubleSide, transparent: true, depthWrite: false })); cursorM.renderOrder = 3;
  const hintShape = new THREE.Shape(); hintShape.moveTo(-6.45, -1.45); hintShape.lineTo(6.45, -1.45); hintShape.lineTo(6.45, 1.45); hintShape.lineTo(-6.45, 1.45); hintShape.lineTo(-6.45, -1.45);
  const hh = new THREE.Path(); hh.moveTo(-6.05, -1.05); hh.lineTo(-6.05, 1.05); hh.lineTo(6.05, 1.05); hh.lineTo(6.05, -1.05); hh.lineTo(-6.05, -1.05); hintShape.holes.push(hh);
  const hintGeo = keep(new THREE.ShapeGeometry(hintShape)); hintGeo.rotateX(-Math.PI / 2);
  const hintM = add(hintGeo, basic('#ec3013', { side: THREE.DoubleSide, transparent: true, depthWrite: false })); hintM.visible = false; hintM.renderOrder = 2;
  // the big word over the last hole (HOT / WARM / COLD / a find's name)
  const signCanvas = document.createElement('canvas'); signCanvas.width = 512; signCanvas.height = 256; const signTex = keep(new THREE.CanvasTexture(signCanvas)); signTex.colorSpace = THREE.SRGBColorSpace;
  const sign = new THREE.Sprite(keep(new THREE.SpriteMaterial({ map: signTex, depthTest: false, transparent: true }))); sign.renderOrder = 10; sign.scale.set(5.2, 2.6, 1); sign.visible = false; grp.add(sign);
  const drawSign = (big, small, bg, fg) => { const g = signCanvas.getContext('2d'); g.clearRect(0, 0, 512, 256); g.fillStyle = '#201e1d'; g.fillRect(0, 0, 512, 256); g.fillStyle = bg; g.fillRect(10, 10, 492, 236);
    g.fillStyle = fg; g.textAlign = 'center'; g.textBaseline = 'middle'; let fs = small ? 112 : 150; g.font = '900 ' + fs + 'px ' + FONT; while (g.measureText(big).width > 470 && fs > 40) { fs -= 6; g.font = '900 ' + fs + 'px ' + FONT; }
    g.fillText(big, 256, small ? 100 : 132); if (small) { g.font = '900 64px ' + FONT; g.fillText(small, 256, 200); } signTex.needsUpdate = true; };
  const puffGeo = keep(new THREE.IcosahedronGeometry(0.22, 0)); const PUFFN = 18; const puff = new THREE.InstancedMesh(puffGeo, toon('#efd193'), PUFFN); puff.count = 0; grp.add(puff);
  const puffs = [];

  // ---------- the finds (one of each, re-used every round) ----------
  const findObj = {};
  { const gold = toon('#ffc93a', { emissive: '#5a3a00' });
    const coins = new THREE.Group(); const cg = new THREE.CylinderGeometry(0.34, 0.34, 0.1, 18);
    for (const [x, y, z, rx] of [[0, 0, 0, 0], [0.05, 0.11, 0.03, 0.05], [-0.04, 0.22, -0.02, -0.05], [0.42, 0.15, 0.1, 1.2]]) { const m = add(cg, gold, x, y, z, coins); m.rotation.x = rx; hull(m, 1.1); }
    const lamp = new THREE.Group(); const clay = toon('#c0643a');
    const body = add(new THREE.SphereGeometry(0.42, 14, 10), clay, 0, 0.2, 0, lamp); body.scale.set(1, 0.55, 0.8); hull(body, 1.1);
    const spout = add(new THREE.ConeGeometry(0.16, 0.6, 10), clay, 0.5, 0.24, 0, lamp); spout.rotation.z = Math.PI / 2; hull(spout, 1.15);
    add(new THREE.TorusGeometry(0.17, 0.06, 6, 12), clay, -0.45, 0.3, 0, lamp);
    add(new THREE.ConeGeometry(0.1, 0.3, 8), basic('#ffb02e'), 0.82, 0.38, 0, lamp);   // the flame
    const bell = new THREE.Group(); const brass = toon('#d9a441', { emissive: '#3a2400' });
    const bp = []; for (let i = 0; i <= 8; i++) { const t = i / 8; bp.push(new THREE.Vector2(0.18 + 0.32 * t * t + (t > 0.9 ? 0.06 : 0), 0.75 - t * 0.75)); }
    const shell = add(new THREE.LatheGeometry(bp, 16), toon('#d9a441', { emissive: '#3a2400', side: THREE.DoubleSide }), 0, 0, 0, bell);
    add(new THREE.TorusGeometry(0.12, 0.05, 6, 12), brass, 0, 0.84, 0, bell); add(new THREE.SphereGeometry(0.12, 10, 8), toon('#5f5a55'), 0, 0.02, 0, bell);
    const relic = new THREE.Group();
    const gem = add(new THREE.OctahedronGeometry(0.42, 0), toon('#ffd23a', { emissive: '#7a5200' }), 0, 0.75, 0, relic); gem.scale.set(1, 1.35, 1); hull(gem, 1.1);
    add(new THREE.CylinderGeometry(0.32, 0.42, 0.25, 6), toon('#ec3013'), 0, 0.12, 0, relic);
    Object.assign(findObj, { coins, lamp, bell, relic });
    for (const g of Object.values(findObj)) { g.visible = false; g.scale.setScalar(1.8); grp.add(g); } }

  // ---------- camera ----------
  const camera = new THREE.PerspectiveCamera(40, 1, 0.5, 400); grp.add(camera);
  const camTarget = { pos: new THREE.Vector3(), quat: new THREE.Quaternion(), ok: false };
  let safe = null, lastFit = '';
  const view = () => { const r = el.getBoundingClientRect(); return { w: r.width || innerWidth, h: r.height || innerHeight }; };
  const FIT_PTS = []; for (const x of [-7.6, 6.9]) for (const z of [PZ - 6.9, PZ + 7.7]) for (const y of [0.3, 1.4]) FIT_PTS.push(new THREE.Vector3(x, y, z));
  function fitCamera(force) {
    const { w, h } = view(), port = h >= w, s = safe || (port ? { top: 130, bottom: 250, left: 0, right: 0 } : { top: 0, bottom: 0, left: 250, right: 250 });
    const key = [w, h, s.top, s.bottom, s.left, s.right].map(Math.round).join(','); if (!force && key === lastFit) return; lastFit = key;
    const fl = s.left + 8, fr = w - s.right - 8, ft = s.top + 8, fb = h - s.bottom - 8, fw = Math.max(80, fr - fl), fh = Math.max(80, fb - ft), fcx = (fl + fr) / 2, fcy = (ft + fb) / 2;
    const pitch = port ? 1.12 : 0.92;   // radians down from horizontal: steeper on a phone held upright
    const C = new THREE.PerspectiveCamera(40, w / h, 0.5, 400); grp.add(C);
    const T = new THREE.Vector3(0, 0.4, PZ + 0.4), dir = new THREE.Vector3(0, Math.sin(pitch), Math.cos(pitch)); let d = 30;
    const place = () => { C.position.copy(T).addScaledVector(dir, d); C.up.set(0, 1, 0); C.lookAt(grp.localToWorld(T.clone())); C.updateMatrixWorld(true); };
    grp.updateMatrixWorld(true);
    for (let it = 0; it < 8; it++) { place(); let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
      for (const p of FIT_PTS) { const v = grp.localToWorld(p.clone()).project(C), px = (v.x + 1) / 2 * w, py = (1 - v.y) / 2 * h; x0 = Math.min(x0, px); x1 = Math.max(x1, px); y0 = Math.min(y0, py); y1 = Math.max(y1, py); }
      const k = Math.max((x1 - x0) / fw, (y1 - y0) / fh); const wpp = 2 * d * Math.tan(THREE.MathUtils.degToRad(C.fov / 2)) / h;
      const right = new THREE.Vector3(1, 0, 0), up = new THREE.Vector3(0, 1, 0).applyQuaternion(C.quaternion); right.applyQuaternion(C.quaternion);
      const bx = (x0 + x1) / 2 - fcx, by = (y0 + y1) / 2 - fcy; T.addScaledVector(right, bx * wpp).addScaledVector(up, -by * wpp); d = Math.max(8, Math.min(120, d * (0.25 + 0.75 * k))); }
    place(); camTarget.pos.copy(C.position); camTarget.quat.copy(C.quaternion); grp.remove(C);
    camera.aspect = w / h; camera.updateProjectionMatrix();
    if (!camTarget.ok) { camera.position.copy(camTarget.pos); camera.quaternion.copy(camTarget.quat); camTarget.ok = true; }
  }
  fitCamera(true);

  // ---------- audio (one context, made on the first tap) ----------
  let ac = null, noiseBuf = null;
  const audio = () => { if (ac) { if (ac.state === 'suspended') ac.resume().catch(() => {}); return ac; } try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { ac = null; } return ac; };
  const tone = (f, at = 0, dur = 0.16, type = 'triangle', vol = 0.22, f2) => { const A = ac; if (!A) return; const t0 = A.currentTime + at, o = A.createOscillator(), g = A.createGain(); o.type = type; o.frequency.setValueAtTime(f, t0); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur); o.connect(g); g.connect(A.destination); o.start(t0); o.stop(t0 + dur + 0.05); };
  const shh = (at = 0, dur = 0.22, vol = 0.35) => { const A = ac; if (!A) return; if (!noiseBuf) { noiseBuf = A.createBuffer(1, A.sampleRate * 0.4, A.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
    const s = A.createBufferSource(), f = A.createBiquadFilter(), g = A.createGain(), t0 = A.currentTime + at; s.buffer = noiseBuf; f.type = 'bandpass'; f.frequency.value = 900; f.Q.value = 0.8; g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur); s.connect(f); f.connect(g); g.connect(A.destination); s.start(t0); s.stop(t0 + dur + 0.02); };
  const SFX = {
    move: () => tone(720, 0, 0.05, 'sine', 0.08),
    dig: () => { shh(0, 0.2); shh(0.28, 0.22); },
    hot: () => { for (let i = 0; i < 3; i++) tone(1046, i * 0.12, 0.1, 'square', 0.12); },
    warm: () => { for (let i = 0; i < 2; i++) tone(622, i * 0.17, 0.14, 'triangle', 0.22); },
    cold: () => tone(262, 0, 0.38, 'sine', 0.3, 220),
    find: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.09, 0.22, 'triangle', 0.22)),
    relic: () => { [523, 659, 784, 1047, 1319, 1568].forEach((f, i) => tone(f, i * 0.08, 0.3, 'triangle', 0.2)); tone(2093, 0.5, 0.6, 'sine', 0.1); },
    no: () => tone(150, 0, 0.18, 'sawtooth', 0.12),
    hint: () => [440, 554, 659, 880].forEach((f, i) => tone(f, i * 0.07, 0.2, 'sine', 0.18)),
    win: () => [523, 784, 1047, 784, 1047].forEach((f, i) => tone(f, i * 0.13, 0.24, 'triangle', 0.22)),
    out: () => [392, 330, 262].forEach((f, i) => tone(f, i * 0.2, 0.3, 'triangle', 0.22)),
  };
  const sfx = k => { if (!ac) return; try { SFX[k](); } catch (e) {} };

  // ---------- the game ----------
  let phase = 'start', round = 0, digs = 0, items = [], dug = [], cur = { r: 2, c: 2 }, total = 0, best = 0, roundRows = [], hintUsed = false, hintRow = -1, busy = 0, last = null, live = '', alive = true, dead = false, t = 0, banner = null, queue = [];
  const roundFound = () => items.filter(i => i.found).length;
  const emit = () => { const R = ROUNDS[round] || ROUNDS[0], cd = !!dug.find(d => d.r === cur.r && d.c === cur.c);
    onState({ phase, round: round + 1, rounds: ROUNDS.length, digs, digsMax: R.digs, found: roundFound(), total: items.length || R.finds.length, score: total + roundFound() * PER_FIND,
      best, cursor: cellName(cur.r, cur.c), cursorDug: cd, busy: busy > 0, last, canHint: phase === 'play' && !hintUsed && digs > HINT_COST && !busy, hintUsed, hintRow: hintRow >= 0 ? ROWS[hintRow] : null,
      finds: items.map(i => ({ name: FINDS[i.kind].name, found: i.found })), card: banner, live, perFind: PER_FIND, perDig: PER_DIG, hintCost: HINT_COST }); };
  const say = (txt) => { live = txt; };
  const heatOf = (r, c) => { const left = items.filter(i => !i.found); if (!left.length) return null; const d = Math.min(...left.map(i => cheb(i, { r, c }))); return d <= 1 ? 'hot' : d === 2 ? 'warm' : 'cold'; };
  const COL = new THREE.Color();
  function redrawHoles() { holes.count = rims.count = dug.length; let n = 0;
    dug.forEach((d, i) => { const [x, z] = cellXZ(d.r, d.c), y = hAt(x, z); holes.setMatrixAt(i, M4.compose(V.set(x, y + 0.07, z), Q0, S1)); rims.setMatrixAt(i, M4.compose(V.set(x, y + 0.02, z), Q0, S1));
      if (!d.find && d.heat) { rings.setMatrixAt(n, M4.compose(V.set(x, y + 0.14, z), Q0, S1)); rings.setColorAt(n, COL.set(HEAT[d.heat].col)); n++; } });
    rings.count = n; holes.instanceMatrix.needsUpdate = rims.instanceMatrix.needsUpdate = rings.instanceMatrix.needsUpdate = true; if (rings.instanceColor) rings.instanceColor.needsUpdate = true; }
  function placeCursor() { const [x, z] = cellXZ(cur.r, cur.c); cursorM.position.set(x, hAt(x, z) + 0.2, z); }
  function showSign(big, small, bg, fg, r, c) { drawSign(big, small, bg, fg); const [x, z] = cellXZ(r, c); sign.position.set(x, hAt(x, z) + 3.4, z - 1.3); sign.visible = true; sign.userData.t = 0; }
  function newRound(n) { round = n; const R = ROUNDS[n]; digs = R.digs; dug = []; hintUsed = false; hintRow = -1; hintM.visible = false; last = null; banner = null; sign.visible = false;
    for (const g of Object.values(findObj)) { g.visible = false; g.userData.anim = null; }
    items = []; let tries = 0; while (items.length < R.finds.length && tries++ < 5000) { const r = Math.floor(Math.random() * N), c = Math.floor(Math.random() * N); if (items.some(i => cheb(i, { r, c }) < 2)) continue; items.push({ r, c, kind: R.finds[items.length], found: false }); }
    if (items.length < R.finds.length) { items = R.finds.map((kind, i) => ({ r: [0, 3, 5, 1][i], c: [1, 4, 2, 5][i], kind, found: false })); }
    cur = { r: 2, c: 2 }; placeCursor(); redrawHoles(); shovelTo(null);
    phase = 'play'; say('ROUND ' + (n + 1) + '. ' + R.finds.length + ' THINGS ARE BURIED. YOU HAVE ' + R.digs + ' DIGS.'); emit(); }
  function popFind(item, missed) { const g = findObj[item.kind], [x, z] = cellXZ(item.r, item.c), y = hAt(x, z); g.visible = true; g.position.set(x, y - 0.6, z); g.rotation.set(0, 0, 0); g.userData = { anim: 0, y0: y - 0.6, y1: y + (missed ? 0.15 : 0.45), missed }; }
  function endRound(allFound) { const f = roundFound(), pts = f * PER_FIND + digs * PER_DIG; total += pts; roundRows.push({ label: 'ROUND ' + (round + 1), finds: f, of: items.length, digsLeft: digs, pts });
    for (const i of items) if (!i.found) popFind(i, true); sign.visible = false;
    const lastRound = round >= ROUNDS.length - 1; if (lastRound) best = Math.max(best, total);
    banner = { kind: lastRound ? 'results' : 'round', title: lastRound ? 'DIG DONE' : allFound ? 'ROUND ' + (round + 1) + ' CLEAR' : 'OUT OF DIGS', allFound, finds: f, of: items.length, digsLeft: digs, findPts: f * PER_FIND, digPts: digs * PER_DIG, pts, total, best, rows: roundRows.slice(), newBest: lastRound && total >= best && total > 0 };
    phase = lastRound ? 'results' : 'round';
    say((allFound ? 'ALL FOUND! ' : 'OUT OF DIGS. ') + 'ROUND ' + (round + 1) + ': ' + pts + ' POINTS.' + (lastRound ? ' TOTAL ' + total + '. BEST ' + best + '.' : ''));
    sfx(allFound ? 'win' : 'out'); emit(); }
  // shovel animation: fly over, dig twice, then call back
  let shovelAnim = null;
  function shovelTo(cell, done) { if (!cell) { shovelAnim = { t: 0, dur: 0.5, from: shovel.position.clone(), to: SHOVEL_HOME.clone(), home: true }; return; }
    const [x, z] = cellXZ(cell.r, cell.c); shovelAnim = { t: 0, dur: 1.15, from: shovel.position.clone(), to: new THREE.Vector3(x + 0.85, hAt(x, z) - 0.05, z + 0.35), done, fired: false, cell }; }
  function doDig(r, c) { if (phase !== 'play' || busy) return; audio(); if (r != null) { cur = { r, c }; placeCursor(); }
    if (dug.find(d => d.r === cur.r && d.c === cur.c)) { sfx('no'); last = { kind: 'dug', word: 'DUG', col: '#5f5a55', fg: '#ffffff', line: cellName(cur.r, cur.c) + ' IS ALREADY DUG · PICK ANOTHER SQUARE', cell: cellName(cur.r, cur.c) }; say(last.line); emit(); return; }
    if (digs <= 0) return; busy = 1; digs--; const cell = { ...cur }; emit();
    shovelTo(cell, () => { const it = items.find(i => !i.found && i.r === cell.r && i.c === cell.c), d = { r: cell.r, c: cell.c, find: it ? it.kind : null, heat: null };
      dug.push(d); burst(cell);
      if (it) { it.found = true; popFind(it); const F = FINDS[it.kind]; last = { kind: 'find', word: F.name, col: '#ffd23a', fg: '#000000', line: 'YOU FOUND THE ' + F.name + '! +' + F.pts, cell: cellName(cell.r, cell.c), pts: F.pts }; showSign(F.name, '+' + F.pts, '#ffd23a', '#000', cell.r, cell.c); sfx(it.kind === 'relic' ? 'relic' : 'find');
        for (const q of dug) if (!q.find) q.heat = heatOf(q.r, q.c);   // the old rings now tell about the finds still buried
        if (hintRow === it.r && !items.some(i => !i.found && i.r === hintRow)) { hintRow = -1; hintM.visible = false; } }
      else { d.heat = heatOf(cell.r, cell.c); const H = HEAT[d.heat]; last = { kind: 'heat', heat: d.heat, word: H.word, col: H.col, fg: H.fg, line: H.line, cell: cellName(cell.r, cell.c) }; showSign(H.word, null, H.col, H.fg, cell.r, cell.c); sfx(d.heat); }
      redrawHoles(); busy = 0; say(cellName(cell.r, cell.c) + ': ' + last.word + '. ' + last.line + '. ' + digs + ' DIGS LEFT.');
      const all = items.every(i => i.found);
      if (all || digs <= 0) { phase = 'ending'; emit(); setTimeout(() => { if (alive) endRound(all); }, all ? 1400 : 1100); } else emit(); }); }
  function burst(cell) { const [x, z] = cellXZ(cell.r, cell.c), y = hAt(x, z); for (let i = 0; i < 12; i++) { const a = Math.random() * Math.PI * 2, s = 1.2 + Math.random() * 2; puffs.push({ p: new THREE.Vector3(x, y + 0.2, z), v: new THREE.Vector3(Math.cos(a) * s, 2.5 + Math.random() * 2.5, Math.sin(a) * s), life: 0.9 + Math.random() * 0.4, age: 0 }); } while (puffs.length > PUFFN) puffs.shift(); }
  function move(dr, dc) { if (phase !== 'play') return; audio(); const r = Math.max(0, Math.min(N - 1, cur.r + dr)), c = Math.max(0, Math.min(N - 1, cur.c + dc)); if (r === cur.r && c === cur.c) { sfx('no'); return; } cur = { r, c }; placeCursor(); sfx('move');
    const dd = dug.find(d => d.r === r && d.c === c); say(cellName(r, c) + (dd ? ' · ALREADY DUG' : '')); emit(); }
  function hint() { if (phase !== 'play' || hintUsed || busy || digs <= HINT_COST) { audio(); sfx('no'); return; } audio(); const left = items.filter(i => !i.found); if (!left.length) return;
    const it = left.slice().sort((a, b) => cheb(a, cur) - cheb(b, cur) || Math.abs(a.r - cur.r) - Math.abs(b.r - cur.r))[0]; hintUsed = true; digs -= HINT_COST; hintRow = it.r;
    const [, z] = cellXZ(it.r, 0); hintM.position.set(0, hAt(0, z) + 0.25, z); hintM.visible = true; sfx('hint');
    last = { kind: 'hint', word: 'ROW ' + ROWS[it.r], col: '#ec3013', fg: '#ffffff', line: 'HINT · SOMETHING IS BURIED IN ROW ' + ROWS[it.r] + ' · −' + HINT_COST + ' DIGS', cell: 'ROW ' + ROWS[it.r] };
    showSign('ROW ' + ROWS[it.r], 'HINT', '#ec3013', '#fff', it.r, 2.5 < cur.c ? 1 : 4); say(last.line + '. ' + digs + ' DIGS LEFT.'); emit(); }

  // ---------- input ----------
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  const hostReady = () => { if (!active()) return false; const H = globalThis.__kufaGames; return !H || H.blend == null || H.blend < 0 || H.blend > 0.97; };
  const cellAt = (cx, cy) => { const b = el.getBoundingClientRect(); ndc.set(((cx - b.left) / b.width) * 2 - 1, -((cy - b.top) / b.height) * 2 + 1); camera.updateMatrixWorld(true); ray.setFromCamera(ndc, camera); const hit = ray.intersectObject(board, false)[0]; if (!hit) return null;
    const p = grp.worldToLocal(hit.point.clone()), c = Math.floor(p.x / CELL + 3), r = Math.floor((p.z - PZ) / CELL + 3); return r >= 0 && r < N && c >= 0 && c < N ? { r, c } : null; };
  const onDown = e => { if (!hostReady() || (e.button && e.button > 0)) return; audio(); if (phase !== 'play') return; const cell = cellAt(e.clientX, e.clientY); if (cell) doDig(cell.r, cell.c); };
  el.addEventListener('pointerdown', onDown);
  const onKey = e => { if (!hostReady() || /INPUT|TEXTAREA|SELECT/.test((e.target && e.target.tagName) || '')) return; const k = e.key;
    if (k === 'ArrowUp') move(-1, 0); else if (k === 'ArrowDown') move(1, 0); else if (k === 'ArrowLeft') move(0, -1); else if (k === 'ArrowRight') move(0, 1);
    else if (k === 'Enter' || k === ' ') { if (phase === 'play') doDig(); else if (phase === 'start') api.start(); else if (phase === 'round') api.next(); else if (phase === 'results') api.start(); }
    else if (k === 'h' || k === 'H') hint(); else return; e.preventDefault(); };
  addEventListener('keydown', onKey);

  // ---------- per frame ----------
  const Q1 = new THREE.Quaternion(), SV = new THREE.Vector3();
  function tick(dt) { dt = Math.min(0.1, dt || 0.016); t += dt;
    fitCamera(false);
    if (camTarget.ok) { const k = 1 - Math.exp(-dt * 5); camera.position.lerp(camTarget.pos, k); camera.quaternion.slerp(camTarget.quat, k); }
    cursorM.visible = phase === 'play'; cursorM.material.opacity = 0.7 + 0.3 * Math.sin(t * 6); const cs = 1 + 0.04 * Math.sin(t * 6); cursorM.scale.set(cs, 1, cs);
    if (hintM.visible) hintM.material.opacity = 0.55 + 0.4 * Math.sin(t * 5);
    if (sign.visible) { sign.userData.t += dt; const a = sign.userData.t, s = a < 0.25 ? 0.6 + 1.6 * a : 1; sign.scale.set(5.2 * s, 2.6 * s, 1); if (a > 4.5 && phase === 'play') sign.visible = false; }
    if (shovelAnim) { const A = shovelAnim; A.t += dt; const u = Math.min(1, A.t / A.dur);
      if (A.home) { shovel.position.lerpVectors(A.from, A.to, u); shovel.position.y += Math.sin(u * Math.PI) * 1.2; shovel.rotation.set(0.25, 0.4, -0.2); if (u >= 1) shovelAnim = null; }
      else { const fly = Math.min(1, A.t / 0.35); shovel.position.lerpVectors(A.from, A.to, fly); shovel.position.y += Math.sin(fly * Math.PI) * 1.6;
        if (A.t > 0.35) { const dgt = (A.t - 0.35) / 0.8, ph = Math.sin(Math.min(1, dgt) * Math.PI * 2); shovel.position.y = A.to.y + 0.35 - Math.abs(ph) * 0.55; shovel.rotation.set(-0.35 + Math.abs(ph) * 0.5, 0, -0.25); if (!A.sfx) { A.sfx = true; sfx('dig'); } }
        else shovel.rotation.set(-0.2, 0, -0.25);
        if (u >= 1 && !A.fired) { A.fired = true; shovelAnim = null; A.done && A.done(); } } }
    for (const g of Object.values(findObj)) { const U = g.userData; if (!g.visible || U.anim == null) continue; U.anim += dt; const a = Math.min(1, U.anim / 0.6);
      const y = U.y0 + (U.y1 - U.y0) * (1 - Math.pow(1 - a, 3)) + (a < 1 ? Math.sin(a * Math.PI) * 1.4 : Math.sin(t * 2.2) * 0.08 * (U.missed ? 0 : 1)); g.position.y = y; g.rotation.y += dt * (U.missed ? 0.3 : 1.4); }
    let n = 0; for (const p of puffs) { p.age += dt; if (p.age > p.life) continue; p.v.y -= 9 * dt; p.p.addScaledVector(p.v, dt); const s = Math.max(0.05, 1 - p.age / p.life) * 1.3; puff.setMatrixAt(n++, M4.compose(p.p, Q0, SV.set(s, s, s))); }
    for (let i = puffs.length - 1; i >= 0; i--) if (puffs[i].age > puffs[i].life) puffs.splice(i, 1); puff.count = n; puff.instanceMatrix.needsUpdate = true; }

  placeCursor(); emit();
  const api = {
    camera, tick, GAME,
    setSafe(s) { if (!s) return; const o = safe || {}; if (['top', 'bottom', 'left', 'right'].every(k => Math.abs((o[k] || 0) - (s[k] || 0)) < 3)) return; safe = { top: s.top || 0, bottom: s.bottom || 0, left: s.left || 0, right: s.right || 0 }; },
    start() { audio(); total = 0; roundRows = []; sfx('hint'); newRound(0); },
    next() { audio(); if (phase !== 'round') return; newRound(round + 1); },
    dig() { doDig(); }, digAt(r, c) { doDig(r, c); }, move, hint,
    up: () => move(-1, 0), down: () => move(1, 0), left: () => move(0, -1), right: () => move(0, 1),
    menu() { phase = 'start'; banner = null; sign.visible = false; for (const g of Object.values(findObj)) g.visible = false; dug = []; items = []; hintM.visible = false; redrawHoles(); shovelTo(null); emit(); },
    debug: { get phase() { return phase; }, items: () => items.map(i => ({ ...i, cell: cellName(i.r, i.c) })), dug: () => dug.slice(), cam: () => [camera.position.toArray().map(v => +v.toFixed(2)), camera.fov],
      screenOf(r, c) { const [x, z] = cellXZ(r, c), v = grp.localToWorld(new THREE.Vector3(x, hAt(x, z), z)).project(camera), b = el.getBoundingClientRect(); return [b.left + (v.x + 1) / 2 * b.width, b.top + (1 - v.y) / 2 * b.height]; },
      cellAt, draws: () => { let k = 0; grp.traverse(o => { if (o.isMesh || o.isSprite) k++; }); return k; } },
    destroy() { alive = false; removeEventListener('keydown', onKey); el.removeEventListener('pointerdown', onDown);
      if (ac) { const a = ac; ac = null; try { a.close().catch(() => {}); } catch (e) {} }
      // our set stays up while the host eases the camera back out, then goes (never touch the world canvas)
      const gone = () => { grp.removeFromParent(); for (const d of disposables) { try { d.dispose(); } catch (e) {} } disposables.length = 0; };
      if (dead) { gone(); return; } dead = true; const H = globalThis.__kufaGames; if (!H || !H.busy || H.api !== api) gone(); else { const iv = setInterval(() => { if (!H.busy || H.api !== api) { clearInterval(iv); gone(); } }, 150); } },
  };
  return api;
}
