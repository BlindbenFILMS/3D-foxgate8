// 8 GATES · KUFA — CARAVAN PACKER (job at Ghazi's caravan hiring board, layout spot kufaCaravanBoard). Built for the world (no own page).
// A kneeling camel with two saddle bags. Goods wait on a rug in front, each with a WEIGHT (1–4). Tap LEFT BAG or RIGHT BAG (or a bag in 3D)
// to load the highlighted item. Keep both sides even: a difference over 4 makes the camel wobble, 6 and it stands up and spills (round lost).
// Fragile pottery must be the LAST thing on its side, or it cracks (penalty). 3 rounds × 45 s; round 3: "Ghazi wants it even" (difference 0 = bonus).
// Score per round = items × 10 + balance bonus + seconds left − cracked pottery. Story names, numbers and lines: DRAFT for Ben.
// createCaravanPacker(host) — host = { container, renderer, onState, active(), bd: { grp, ... } } (worlds/kufa-games.js, kind 'direct').
// The world renders us: tick(dt) only updates. Our set lives in host.bd.grp (metres from the spot: +x east, +z south).
import * as THREE from '../../../vendor/three/three.module.js';

let BEST = 0;   // best total this session (memory only)

// ---------- tuning (DRAFT) ----------
const TIME = 45, WOBBLE = 5, SPILL = 6, PER_ITEM = 10, CRACK = 15, EVEN_BONUS = 30, NEAR_BONUS = 15, GHAZI_BONUS = 50;
const ROUNDS = [
  { n: 6, types: ['crate', 'sack', 'carpet', 'jar'], maxW: 3, pots: [], goal: '' },
  { n: 8, types: ['crate', 'sack', 'carpet', 'jar'], maxW: 4, pots: [6], goal: '' },
  { n: 10, types: ['crate', 'sack', 'carpet', 'jar'], maxW: 4, pots: [7, 9], goal: 'even' },
];
const TYPES = {
  crate: { name: 'CRATE', w: [3, 4] }, sack: { name: 'SPICE SACK', w: [1, 2] }, carpet: { name: 'CARPET', w: [2, 3] },
  jar: { name: 'WATER JAR', w: [2, 3] }, pottery: { name: 'POTTERY', w: [1, 1] },
};
const SIDE_NAME = { L: 'LEFT', R: 'RIGHT' };
const BAG_COL = { L: '#2f7fd0', R: '#ffd23a' };

// ---------- small mesh kit: unit geometries + merged vertex-colour parts with a black back-face outline ----------
const GEO = { box: new THREE.BoxGeometry(1, 1, 1), sph: new THREE.SphereGeometry(0.5, 14, 10), cyl: new THREE.CylinderGeometry(0.5, 0.5, 1, 14), tcyl: new THREE.CylinderGeometry(0.4, 0.5, 1, 14) };
const M4 = (x, y, z, sx, sy, sz, rx = 0, ry = 0, rz = 0) => new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)), new THREE.Vector3(sx, sy, sz));
const P = (g, c, x, y, z, sx, sy, sz, rx, ry, rz) => ({ g, c, x, y, z, sx, sy, sz, rx, ry, rz });
function merged(parts, outline) {
  const gs = parts.map(p => { const g = GEO[p.g].toNonIndexed(); const t = outline ? 0.07 : 0; g.applyMatrix4(M4(p.x, p.y, p.z, p.sx + t, p.sy + t, p.sz + t, p.rx, p.ry, p.rz)); return [g, new THREE.Color(p.c)]; });
  const n = gs.reduce((s, [g]) => s + g.attributes.position.count, 0), pos = new Float32Array(n * 3), nor = new Float32Array(n * 3), col = new Float32Array(n * 3);
  let o = 0; for (const [g, c] of gs) { const k = g.attributes.position.count; pos.set(g.attributes.position.array, o * 3); nor.set(g.attributes.normal.array, o * 3); for (let i = 0; i < k; i++) { col[(o + i) * 3] = c.r; col[(o + i) * 3 + 1] = c.g; col[(o + i) * 3 + 2] = c.b; } o += k; g.dispose(); }
  const G = new THREE.BufferGeometry(); G.setAttribute('position', new THREE.BufferAttribute(pos, 3)); G.setAttribute('normal', new THREE.BufferAttribute(nor, 3)); G.setAttribute('color', new THREE.BufferAttribute(col, 3)); G.computeBoundingSphere(); return G;
}
let GRAD = null;
const gradTex = () => { if (GRAD) return GRAD; const d = new Uint8Array([90, 170, 255]); GRAD = new THREE.DataTexture(d, 3, 1, THREE.RedFormat); GRAD.minFilter = GRAD.magFilter = THREE.NearestFilter; GRAD.needsUpdate = true; return GRAD; };
const INK = new THREE.MeshBasicMaterial({ color: '#141210', side: THREE.BackSide });
function toon(parts, mat) {   // → Group(mesh + outline); returns { g, mesh, mat }
  const g = new THREE.Group(), m = mat || new THREE.MeshToonMaterial({ vertexColors: true, gradientMap: gradTex() });
  const mesh = new THREE.Mesh(merged(parts, false), m), ol = new THREE.Mesh(merged(parts, true), INK); g.add(ol, mesh); return { g, mesh, mat: m };
}
function textTex(lines, { w = 256, h = 128, bg = '#ffd23a', fg = '#000', rim = '#000', font = 900 } = {}) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d');
  x.fillStyle = rim; x.fillRect(0, 0, w, h); x.fillStyle = bg; x.fillRect(10, 10, w - 20, h - 20); x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle';
  const lh = (h - 24) / lines.length; lines.forEach((t, i) => { let fs = Math.floor(lh * 0.92); x.font = font + ' ' + fs + 'px Archivo, Arial, sans-serif'; while (x.measureText(t).width > w - 30 && fs > 10) { fs -= 2; x.font = font + ' ' + fs + 'px Archivo, Arial, sans-serif'; } x.fillText(t, w / 2, 12 + lh * (i + 0.55)); });
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
const sprite = (tex, sx, sy) => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true })); s.scale.set(sx, sy, 1); s.renderOrder = 10; return s; };

// ---------- models ----------
const TAN = '#c99a5b', TAND = '#a87a42', TANL = '#e2c08a';
function camelParts() {
  return [
    P('sph', TAN, 0, 1.15, 0.15, 1.5, 1.15, 2.7), P('sph', TAN, 0, 1.9, 0.3, 1.05, 0.95, 1.25),                       // body + hump
    P('box', '#ec3013', 0, 1.62, 0.25, 1.62, 0.12, 1.15), P('box', '#ec3013', 0.8, 1.3, 0.25, 0.08, 0.6, 1.15), P('box', '#ec3013', -0.8, 1.3, 0.25, 0.08, 0.6, 1.15),   // saddle blanket
    P('box', '#ffd23a', 0.84, 1.02, 0.25, 0.06, 0.1, 1.17), P('box', '#ffd23a', -0.84, 1.02, 0.25, 0.06, 0.1, 1.17),
    P('cyl', TAN, 0, 1.5, -1.45, 0.62, 1.15, 0.62, -1.0), P('cyl', TAN, 0, 2.3, -1.88, 0.52, 1.0, 0.52, 0.25),                  // neck
    P('sph', TAN, 0, 2.88, -2.05, 0.6, 0.55, 0.85), P('sph', TANL, 0, 2.78, -2.42, 0.48, 0.42, 0.5),                            // head + snout
    P('box', TAND, 0.22, 3.18, -1.9, 0.1, 0.22, 0.1), P('box', TAND, -0.22, 3.18, -1.9, 0.1, 0.22, 0.1),                         // ears
    P('sph', '#1a1410', 0.25, 2.98, -2.22, 0.12, 0.14, 0.12), P('sph', '#1a1410', -0.25, 2.98, -2.22, 0.12, 0.14, 0.12),          // eyes
    P('cyl', TAND, 0, 1.25, 1.5, 0.12, 0.6, 0.12, 0.4),                                                                         // tail
    // saddle bags (panniers): +x = LEFT on screen (the camera looks south, +z)
    P('box', BAG_COL.L, 1.2, 1.05, 0.2, 0.6, 0.8, 1.35), P('box', '#1b4f86', 1.2, 1.47, 0.2, 0.64, 0.08, 1.39), P('box', '#3a2a1a', 0.96, 1.62, 0.2, 0.42, 0.08, 0.16),
    P('box', BAG_COL.R, -1.2, 1.05, 0.2, 0.6, 0.8, 1.35), P('box', '#b8860b', -1.2, 1.47, 0.2, 0.64, 0.08, 1.39), P('box', '#3a2a1a', -0.96, 1.62, 0.2, 0.42, 0.08, 0.16),
  ];
}
const foldedLegs = () => [P('cyl', TAND, 0.5, 0.22, -0.85, 0.38, 0.95, 0.38, Math.PI / 2), P('cyl', TAND, -0.5, 0.22, -0.85, 0.38, 0.95, 0.38, Math.PI / 2),
  P('cyl', TAND, 0.62, 0.28, 0.95, 0.44, 1.0, 0.44, Math.PI / 2), P('cyl', TAND, -0.62, 0.28, 0.95, 0.44, 1.0, 0.44, Math.PI / 2),
  P('sph', '#7a5a32', 0.5, 0.2, -1.38, 0.4, 0.3, 0.4), P('sph', '#7a5a32', -0.5, 0.2, -1.38, 0.4, 0.3, 0.4)];
const standLegs = () => [[0.5, -0.85], [-0.5, -0.85], [0.6, 0.95], [-0.6, 0.95]].map(([x, z]) => P('cyl', TAND, x, 0.75, z, 0.32, 1.5, 0.32));
function itemParts(type, col) {
  if (type === 'crate') return [P('box', '#a8743c', 0, 0.3, 0, 0.66, 0.6, 0.66), P('box', '#6b4422', 0, 0.1, 0, 0.7, 0.08, 0.7), P('box', '#6b4422', 0, 0.5, 0, 0.7, 0.08, 0.7), P('box', '#6b4422', 0, 0.3, -0.34, 0.08, 0.6, 0.04)];
  if (type === 'sack') return [P('sph', col, 0, 0.3, 0, 0.62, 0.62, 0.56), P('cyl', '#6b4a2c', 0, 0.62, 0, 0.18, 0.12, 0.18), P('sph', col, 0, 0.72, 0, 0.26, 0.16, 0.26)];
  if (type === 'carpet') return [P('cyl', col, 0, 0.22, 0, 0.44, 1.0, 0.44, 0, 0, Math.PI / 2), P('cyl', '#ffd23a', 0.3, 0.22, 0, 0.47, 0.1, 0.47, 0, 0, Math.PI / 2), P('cyl', '#ffd23a', -0.3, 0.22, 0, 0.47, 0.1, 0.47, 0, 0, Math.PI / 2), P('cyl', '#f3f2f2', 0.51, 0.22, 0, 0.3, 0.04, 0.3, 0, 0, Math.PI / 2)];
  if (type === 'jar') return [P('sph', '#c8693a', 0, 0.32, 0, 0.52, 0.62, 0.52), P('cyl', '#c8693a', 0, 0.68, 0, 0.26, 0.2, 0.26), P('cyl', '#a8552c', 0, 0.8, 0, 0.36, 0.06, 0.36), P('cyl', '#38bdf8', 0, 0.83, 0, 0.24, 0.02, 0.24)];
  return [P('tcyl', '#f1e6cc', 0, 0.1, 0, 0.62, 0.2, 0.62), P('tcyl', '#2f6fb0', 0, 0.27, 0, 0.54, 0.16, 0.54), P('tcyl', '#f1e6cc', 0, 0.42, 0, 0.46, 0.15, 0.46), P('cyl', '#2f6fb0', 0, 0.53, 0, 0.3, 0.06, 0.3)];   // pottery stack
}
const ITEM_H = { crate: 0.6, sack: 0.78, carpet: 0.46, jar: 0.84, pottery: 0.56 };
const SACK_COLS = ['#e8a33a', '#c8452a', '#5aa05a', '#d9c23a'], CARPET_COLS = ['#b8322a', '#2f5fa8', '#7a3a8a'];

// ---------- round generator: random goods, re-rolled until a clean plan exists (no spill, no crack; round 3 ends even) ----------
function solvable(ws, pots, even) {
  const n = ws.length;
  for (let m = 0; m < 1 << n; m++) { let L = 0, R = 0, ok = true; const potOn = { L: false, R: false };
    for (let i = 0; i < n && ok; i++) { const s = (m >> i) & 1 ? 'L' : 'R'; if (potOn[s]) ok = false; if (s === 'L') L += ws[i]; else R += ws[i]; if (Math.abs(L - R) > 3) ok = false; if (pots.includes(i)) potOn[s] = true; }
    if (ok && (!even || L === R)) return true; }
  return false;
}
function makeRound(ri) {
  const D = ROUNDS[ri];
  for (let tries = 0; tries < 400; tries++) {
    const items = []; for (let i = 0; i < D.n; i++) { const pot = D.pots.includes(i), type = pot ? 'pottery' : D.types[Math.floor(Math.random() * D.types.length)], T = TYPES[type];
      let w = T.w[0] + Math.floor(Math.random() * (T.w[1] - T.w[0] + 1)); w = Math.min(w, D.maxW); items.push({ type, w, fragile: pot }); }
    if (ri > 0 && !items.some(it => it.w >= 4)) continue;   // later rounds always bring a heavy crate
    if (solvable(items.map(it => it.w), D.pots, D.goal === 'even')) return items;
  }
  return Array.from({ length: D.n }, (_, i) => ({ type: D.pots.includes(i) ? 'pottery' : 'sack', w: D.pots.includes(i) ? 1 : 2, fragile: D.pots.includes(i) }));
}

// ---------- sound (one AudioContext, made on the first tap) ----------
function makeAudio() {
  let ac = null;
  const ctx = () => { if (ac) return ac; try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { ac = null; } return ac; };
  const tone = (f, d, { type = 'sine', vol = 0.18, pan = 0, at = 0, f2 = 0 } = {}) => { const a = ac; if (!a) return; try {
    const t0 = a.currentTime + at, o = a.createOscillator(), g = a.createGain(); o.type = type; o.frequency.setValueAtTime(f, t0); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t0 + d);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol, t0 + 0.015); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    let node = o.connect(g); if (a.createStereoPanner) { const p = a.createStereoPanner(); p.pan.value = pan; node = node.connect(p); } node.connect(a.destination); o.start(t0); o.stop(t0 + d + 0.05); } catch (e) {} };
  const noise = (d, { vol = 0.2, pan = 0, at = 0, hp = 1500 } = {}) => { const a = ac; if (!a) return; try {
    const n = Math.floor(a.sampleRate * d), b = a.createBuffer(1, n, a.sampleRate), ch = b.getChannelData(0); for (let i = 0; i < n; i++) ch[i] = (Math.random() * 2 - 1) * (1 - i / n);
    const s = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain(); s.buffer = b; f.type = 'highpass'; f.frequency.value = hp; g.gain.value = vol;
    let node = s.connect(f).connect(g); if (a.createStereoPanner) { const p = a.createStereoPanner(); p.pan.value = pan; node = node.connect(p); } node.connect(a.destination); s.start(a.currentTime + at); } catch (e) {} };
  return {
    unlock() { const a = ctx(); if (a && a.state === 'suspended') a.resume().catch(() => {}); },
    side(s) { const pan = s === 'L' ? -0.85 : 0.85; if (s === 'L') { tone(330, 0.16, { pan, type: 'triangle' }); tone(440, 0.22, { pan, type: 'triangle', at: 0.1 }); } else { tone(660, 0.16, { pan, type: 'triangle' }); tone(880, 0.22, { pan, type: 'triangle', at: 0.1 }); } },
    thud(s) { tone(140, 0.18, { pan: s === 'L' ? -0.6 : 0.6, type: 'sine', vol: 0.25, f2: 70 }); },
    warn(s) { const pan = s === 'L' ? -0.7 : s === 'R' ? 0.7 : 0; for (let i = 0; i < 3; i++) tone(220, 0.12, { pan, type: 'square', vol: 0.09, at: i * 0.17 }); },
    lean(diff) { const a = Math.abs(diff); if (a >= 3) tone(300 - a * 20, 0.12, { pan: diff > 0 ? -0.5 : 0.5, type: 'sawtooth', vol: 0.05, at: 0.32 }); },
    even() { tone(784, 0.12, { vol: 0.12, at: 0.3 }); },
    crack(s) { noise(0.18, { vol: 0.35, pan: s === 'L' ? -0.7 : 0.7, hp: 2500 }); tone(1200, 0.08, { type: 'square', vol: 0.06, f2: 500 }); },
    spill() { tone(400, 0.9, { type: 'sawtooth', vol: 0.12, f2: 90 }); noise(0.5, { vol: 0.25, at: 0.4, hp: 600 }); },
    tick() { tone(1000, 0.04, { type: 'square', vol: 0.04 }); },
    good() { [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.22, { vol: 0.12, at: i * 0.1 })); },
    bad() { [392, 330, 262].forEach((f, i) => tone(f, 0.28, { vol: 0.12, type: 'triangle', at: i * 0.14 })); },
    start() { tone(523, 0.12, { vol: 0.12 }); tone(784, 0.2, { vol: 0.12, at: 0.12 }); },
    close() { try { ac && ac.close && ac.close(); } catch (e) {} ac = null; },
  };
}

// the set: the hiring board stands at the spot itself (x ±1, z 0); our rug + camel sit just south of it, clear of the stall at (+6, -4) and Ghazi at (+6, 0)
const CZ = 9, YAW = 0.35, RUGZ = 5.2;   // camel centre (metres south of the spot), turned a little so the hump and the side read; rug centre
function buildSet(parent, idleGoods) {
  const root = new THREE.Group(); root.name = 'caravanPacker'; parent.add(root);
  const deco = [P('box', '#e6b45a', 0, 0.02, RUGZ, 5.9, 0.04, 3.1), P('box', '#9b2a1e', 0, 0.04, RUGZ, 5.5, 0.04, 2.7), P('box', '#ffd23a', 0, 0.065, RUGZ, 4.6, 0.02, 0.1), P('box', '#ffd23a', 0, 0.065, RUGZ - 0.9, 4.6, 0.02, 0.06), P('box', '#ffd23a', 0, 0.065, RUGZ + 0.9, 4.6, 0.02, 0.06),
    P('box', '#d9c29a', 0, 0.015, CZ + 0.2, 4.6, 0.03, 4.4),   // trampled sand under the camel
    P('cyl', '#6b4a2c', 3.4, 0.6, CZ - 0.6, 0.16, 1.2, 0.16), P('cyl', '#3a2a1a', 3.4, 1.15, CZ - 0.6, 0.3, 0.1, 0.3),   // tether post
    P('box', '#a8743c', -3.5, 0.35, CZ + 1.2, 0.7, 0.7, 0.7), P('box', '#a8743c', -3.4, 1.0, CZ + 1.3, 0.55, 0.55, 0.55), P('sph', '#c8693a', -3.4, 0.35, CZ - 0.3, 0.6, 0.7, 0.6)];   // spare goods
  if (idleGoods) {   // a few goods waiting on the rug (one merged mesh) for the walking view
    const at = (parts, x, z, sc = 1) => parts.map(p => ({ ...p, x: x + p.x * sc, y: 0.07 + p.y * sc, z: z + p.z * sc, sx: p.sx * sc, sy: p.sy * sc, sz: p.sz * sc }));
    deco.push(...at(itemParts('crate'), 1.6, RUGZ - 0.4), ...at(itemParts('sack', '#e8a33a'), 0.5, RUGZ + 0.3), ...at(itemParts('carpet', '#2f5fa8'), -0.7, RUGZ - 0.3), ...at(itemParts('jar'), -1.8, RUGZ + 0.4), ...at(itemParts('pottery'), 0.2, RUGZ - 0.7, 0.9));
  }
  root.add(toon(deco).g);
  const camel = new THREE.Group(); camel.position.set(0, 0, CZ); camel.rotation.y = YAW; root.add(camel);
  const lift = new THREE.Group(); camel.add(lift);
  lift.add(toon(camelParts()).g);
  const legsF = toon(foldedLegs()).g; lift.add(legsF);
  const legsS = toon(standLegs()).g; legsS.visible = false; camel.add(legsS);
  return { root, camel, lift, legsF, legsS };
}
// KUFA WORLD idle set (entry idle: 'buildCaravanPackerSet'): the static camel + rug shown while walking; the host hides it while the game plays
export function buildCaravanPackerSet(_THREE, spotGroup) { const S = buildSet(spotGroup, true); S.root.name = 'caravanPackerIdle'; return S.root; }

export function createCaravanPacker(host) {
  const { renderer, onState = () => {} } = host, grp = host.bd.grp;
  const audio = makeAudio();
  const { root, camel, lift, legsF, legsS } = buildSet(grp, false);
  // invisible hit boxes over each bag (+ its stack)
  const hitMat = new THREE.MeshBasicMaterial({ visible: false }), hits = {};
  for (const s of ['L', 'R']) { const h = new THREE.Mesh(GEO.box, hitMat); h.scale.set(1.4, 3.2, 2.0); h.position.set((s === 'L' ? 1 : -1) * 1.35, 1.8, 0.2); h.userData.side = s; lift.add(h); hits[s] = h; }
  // bag labels (LEFT 7 / RIGHT 5) above each side
  const bagLbl = {}; for (const s of ['L', 'R']) { const sp = sprite(textTex([SIDE_NAME[s], '0'], { w: 256, h: 192, bg: BAG_COL[s], fg: s === 'L' ? '#fff' : '#000' }), 1.25, 0.94); sp.position.set((s === 'L' ? 1 : -1) * 2.35, 3.55, CZ); root.add(sp); bagLbl[s] = { sp, txt: '' }; }
  const setBagLbl = (s, w) => { const t = String(w); if (bagLbl[s].txt === t) return; bagLbl[s].txt = t; const m = bagLbl[s].sp.material; m.map && m.map.dispose(); m.map = textTex([SIDE_NAME[s], t], { w: 256, h: 192, bg: BAG_COL[s], fg: s === 'L' ? '#fff' : '#000' }); m.needsUpdate = true; };
  // next-item ring
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.07, 8, 28), new THREE.MeshBasicMaterial({ color: '#ffd23a', toneMapped: false })); ring.rotation.x = -Math.PI / 2; ring.visible = false; root.add(ring);

  const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 400); root.add(camera);
  const safe = { top: 0, bottom: 0, left: 0, right: 0 };

  // ---------- state ----------
  let phase = 'start', ri = 0, items = [], idx = 0, time = TIME, sideW = { L: 0, R: 0 }, stacks = { L: [], R: [] }, colH = { L: [0, 0], R: [0, 0] };
  let roundRows = [], roundLog = [], total = 0, card = null, live = 'Caravan Packer. Tap PLAY.', flash = null, cracked = 0, spillT = -1, endT = -1, warnT = 0, lastSec = -1, t = 0, lastNow = 0, alive = true, camInit = false;
  const flights = [], tumble = [];
  const diff = () => sideW.L - sideW.R;
  function clearItems() { for (const it of items) { it.g.removeFromParent(); it.lbl.removeFromParent(); it.mesh.geometry.dispose(); it.ol.geometry.dispose(); it.mat.dispose(); it.lbl.material.map.dispose(); it.lbl.material.dispose(); } items = []; flights.length = 0; tumble.length = 0; }
  function buildRound() {
    clearItems(); const list = makeRound(ri), n = list.length, perRow = n > 6 ? 5 : n, rows = Math.ceil(n / perRow);
    items = list.map((d, i) => { const col = d.type === 'sack' ? SACK_COLS[i % SACK_COLS.length] : CARPET_COLS[i % CARPET_COLS.length], sc = 0.85 + d.w * 0.07;
      const T = toon(itemParts(d.type, col)), g = T.g; g.scale.setScalar(sc);
      const r = Math.floor(i / perRow), c = i % perRow, inRow = Math.min(perRow, n - r * perRow);
      const x = ((inRow - 1) / 2 - c) * 1.05, z = RUGZ - (rows - 1) * 0.62 + r * 1.24;   // queue order: screen-left → right, front row first
      g.position.set(x, 0.07, z); g.rotation.y = (Math.random() - 0.5) * 0.5; root.add(g);
      const lbl = sprite(textTex([String(d.w)], { w: 128, h: 128, bg: d.fragile ? '#ec3013' : '#ffd23a', fg: d.fragile ? '#fff' : '#000' }), 0.5, 0.5); lbl.position.set(x, 0.07 + ITEM_H[d.type] * sc + 0.38, z); root.add(lbl);
      return { ...d, name: TYPES[d.type].name, g, mesh: T.mesh, ol: T.g.children[0], mat: T.mat, lbl, home: g.position.clone(), sc, side: null, cracked: false }; });
    idx = 0; time = TIME; sideW = { L: 0, R: 0 }; stacks = { L: [], R: [] }; colH = { L: [0, 0], R: [0, 0] }; cracked = 0; spillT = -1; endT = -1; warnT = 0; lastSec = -1;
    camel.rotation.set(0, YAW, 0); lift.position.set(0, 0, 0); legsF.visible = true; legsS.visible = false; setBagLbl('L', 0); setBagLbl('R', 0);
  }
  buildRound();   // the pile is on the rug from the start (the start card shows the set)

  const itemTxt = it => it ? it.name + ' · ' + it.w : '';
  function emit() {
    const it = items[idx], nx = items[idx + 1], d = diff(), a = Math.abs(d);
    const lean = a === 0 ? 'EVEN' : 'LEANS ' + (d > 0 ? 'LEFT' : 'RIGHT') + ' BY ' + a;
    const level = a >= SPILL ? 'spill' : a >= WOBBLE ? 'wobble' : a >= 3 ? 'lean' : 'ok';
    onState({ phase, round: ri + 1, rounds: ROUNDS.length, time: Math.max(0, Math.ceil(time)), left: items.length - idx, n: items.length, score: total, L: sideW.L, R: sideW.R, diff: d, lean, level,
      next: it && phase === 'play' && spillT < 0 ? { name: it.name, w: it.w, fragile: it.fragile } : null, then: nx && phase === 'play' && spillT < 0 ? { name: nx.name, w: nx.w, fragile: nx.fragile } : null,
      potTop: { L: !!(stacks.L.length && stacks.L[stacks.L.length - 1].fragile && !stacks.L[stacks.L.length - 1].cracked), R: !!(stacks.R.length && stacks.R[stacks.R.length - 1].fragile && !stacks.R[stacks.R.length - 1].cracked) },
      goal: ROUNDS[ri].goal, card, best: BEST, live, flash });
  }
  const say = (txt, f) => { live = txt; if (f) flash = { txt: f.txt || txt, col: f.col || '#ffd23a', until: t + (f.dur || 1.4) }; };

  function load(s) {
    if (phase !== 'play' || idx >= items.length || spillT >= 0) return false; audio.unlock();
    const it = items[idx++], st = stacks[s], top = st[st.length - 1];
    audio.side(s);
    if (top && top.fragile && !top.cracked) { top.cracked = true; cracked++; top.mat.color.set('#6d6458'); audio.crack(s); say('CRACK! The pottery on the ' + SIDE_NAME[s] + ' broke. Minus ' + CRACK + '.', { txt: 'CRACK! −' + CRACK, col: '#ff6a4d' }); }
    it.side = s; st.push(it); sideW[s] += it.w; setBagLbl(s, sideW[s]);
    // fly: into the lift group, onto the lower of the two columns on that side
    const col = colH[s][0] <= colH[s][1] ? 0 : 1, k = 0.62, h = ITEM_H[it.type] * it.sc * k;
    const to = new THREE.Vector3((s === 'L' ? 1 : -1) * 1.2, 1.52 + colH[s][col], 0.2 + (col ? 0.33 : -0.33)); colH[s][col] += h;
    root.updateMatrixWorld(true); const from = lift.worldToLocal(it.g.getWorldPosition(new THREE.Vector3())); lift.add(it.g); it.g.position.copy(from);
    it.lbl.visible = false; flights.push({ it, from, to, k, t: 0, s, r0: it.g.rotation.y });
    const d = diff(), a = Math.abs(d);
    if (a >= SPILL) { spillT = 0; audio.warn(d > 0 ? 'L' : 'R'); say('TOO HEAVY ON THE ' + (d > 0 ? 'LEFT' : 'RIGHT') + '! The camel stands up and spills!', { txt: 'SPILL!', col: '#ff6a4d', dur: 2 }); }
    else if (a >= WOBBLE) { audio.warn(d > 0 ? 'L' : 'R'); warnT = 1.6; say('WOBBLE! ' + (d > 0 ? 'LEFT' : 'RIGHT') + ' is ' + a + ' heavier. Load the other side.', { txt: 'WOBBLE!', col: '#ff9a3a' }); }
    else { audio.lean(d); if (a === 0) audio.even(); if (!flash || flash.until < t) say(it.name + ' in the ' + SIDE_NAME[s] + ' bag. ' + (a === 0 ? 'Even.' : 'Leans ' + (d > 0 ? 'left' : 'right') + ' by ' + a + '.')); }
    if (idx >= items.length && spillT < 0) endT = 0.8;
    emit(); return true;
  }

  function finishRound(why) {
    phase = 'round'; ring.visible = false; const n = stacks.L.length + stacks.R.length, d = Math.abs(diff()), all = idx >= items.length, D = ROUNDS[ri];
    const rows = []; let sc = 0;
    if (why === 'spill') { rows.push(['SPILLED · ROUND LOST', 0]); }
    else {
      rows.push([n + ' ITEMS × ' + PER_ITEM, n * PER_ITEM]); sc += n * PER_ITEM;
      if (all) { const b = d === 0 ? EVEN_BONUS : d <= 2 ? NEAR_BONUS : 0; rows.push([d === 0 ? 'PERFECT BALANCE' : 'BALANCE · OFF BY ' + d, b]); sc += b;
        const tl = Math.max(0, Math.ceil(time)); rows.push(['TIME LEFT · ' + tl + ' S', tl]); sc += tl;
        if (D.goal === 'even') { const g = d === 0 ? GHAZI_BONUS : 0; rows.push(['GHAZI WANTS IT EVEN', g]); sc += g; } }
      else rows.push(['TIME UP · ' + (items.length - idx) + ' LEFT ON THE RUG', 0]);
      if (cracked) { rows.push([cracked + ' CRACKED POTTERY', -CRACK * cracked]); sc -= CRACK * cracked; }
    }
    sc = Math.max(0, sc); total += sc; roundLog.push({ round: ri + 1, score: sc, why });
    const last = ri >= ROUNDS.length - 1, nd = ROUNDS[ri + 1];
    if (last) { const isBest = total > BEST; if (isBest) BEST = total;
      phase = 'results'; card = { kind: 'results', title: 'CARAVAN READY', total, best: BEST, isBest, rows: roundLog.map(r => ['ROUND ' + r.round + (r.why === 'spill' ? ' · SPILLED' : r.why === 'time' ? ' · TIME UP' : ''), r.score]), last: rows,
        line: total >= 300 ? 'Ghazi: "That camel will walk straight to Meru. Hired!" (DRAFT)' : total >= 150 ? 'Ghazi: "Good hands. A little more balance next time." (DRAFT)' : 'Ghazi: "The camel forgives you. Barely. Try again." (DRAFT)' };
      if (why === 'spill') audio.bad(); else audio.good(); say('Results. Total score ' + total + '. Best ' + BEST + '.'); }
    else { card = { kind: 'round', title: why === 'spill' ? 'SPILLED!' : why === 'time' ? 'TIME UP' : 'ROUND ' + (ri + 1) + ' LOADED', bad: why === 'spill', rows, score: sc, total,
        next: 'ROUND ' + (ri + 2) + ' · ' + nd.n + ' ITEMS · ' + TIME + ' S' + (nd.pots.length ? ' · POTTERY GOES LAST ON ITS SIDE' : '') + (nd.goal === 'even' ? ' · GHAZI WANTS IT EVEN' : ''), btn: 'START ROUND ' + (ri + 2) };
      if (why === 'spill') audio.bad(); else audio.good(); say(card.title + '. Round score ' + sc + '. Total ' + total + '.'); }
    emit();
  }

  function begin() { phase = 'play'; card = null; flash = null; time = TIME; audio.start(); const D = ROUNDS[ri];
    say('Round ' + (ri + 1) + '. ' + items.length + ' items. ' + (D.goal === 'even' ? 'Ghazi wants it even. ' : '') + 'First: ' + itemTxt(items[0]) + '.', { txt: 'ROUND ' + (ri + 1) + (D.goal === 'even' ? ' · MAKE IT EVEN' : ''), col: '#ffd23a', dur: 1.8 }); emit(); }

  // ---------- input: tap a bag in 3D (only while the world says we own the screen) ----------
  const el = renderer.domElement, ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  const onDown = e => { if (!alive || !host.active || !host.active()) return; audio.unlock(); if (phase !== 'play') return;
    const bb = el.getBoundingClientRect(); ndc.set(((e.clientX - bb.left) / bb.width) * 2 - 1, -((e.clientY - bb.top) / bb.height) * 2 + 1);
    camera.updateMatrixWorld(); root.updateMatrixWorld(true); ray.setFromCamera(ndc, camera); const h = ray.intersectObjects([hits.L, hits.R], false)[0]; if (h) load(h.object.userData.side); };
  el.addEventListener('pointerdown', onDown);
  const onKey = e => { if (!alive || !host.active || !host.active()) return; const k = e.key;
    if (phase === 'play') { if (k === 'ArrowLeft' || k === 'a' || k === 'A') { load('L'); e.preventDefault(); } else if (k === 'ArrowRight' || k === 'd' || k === 'D') { load('R'); e.preventDefault(); } } };
  addEventListener('keydown', onKey);

  // ---------- camera: frames the camel + rug in the free middle of the screen (the panel reports its HUD sizes with setSafe) ----------
  const BOX = []; for (const x of [-2.95, 2.95]) for (const y of [0, 4.05]) for (const z of [3.6, 10.4]) BOX.push(new THREE.Vector3(x, y, z)); const V3 = new THREE.Vector3();
  const camPos = new THREE.Vector3(), camQ = new THREE.Quaternion(), tgt = new THREE.Vector3(), tmpO = new THREE.PerspectiveCamera();   // a camera: lookAt points its -z at the target
  function frame(dt) {
    const W = el.clientWidth || innerWidth, H = el.clientHeight || innerHeight, asp = W / H, fov = 50, tv = Math.tan(fov * Math.PI / 360);
    const top = Math.min(safe.top, H * 0.6), bot = Math.min(safe.bottom, H * 0.6), lf = Math.min(safe.left, W * 0.45), rt = Math.min(safe.right, W * 0.45);
    const fh = Math.max(0.25, (H - top - bot) / H), fw = Math.max(0.25, (W - lf - rt) / W), el0 = 0.62, yc = (bot - top) / H, xc = (lf - rt) / W;
    const x0 = -1 + 2 * lf / W + 0.03, x1 = 1 - 2 * rt / W - 0.03, y0 = -1 + 2 * bot / H + 0.03, y1 = 1 - 2 * top / H - 0.03;
    tgt.set(0, 1.7, 7.2); tmpO.fov = fov; tmpO.aspect = asp; tmpO.updateProjectionMatrix();
    const pose = d => { tmpO.position.set(0, tgt.y + Math.sin(el0) * d, tgt.z - Math.cos(el0) * d); tmpO.up.set(0, 1, 0); tmpO.lookAt(tgt); tmpO.rotateY(Math.atan(xc * tv * asp)); tmpO.rotateX(-Math.atan(yc * tv)); tmpO.updateMatrixWorld(); };
    const fits = () => { for (const c of BOX) { V3.copy(c).project(tmpO); if (V3.z > 1 || V3.x < x0 || V3.x > x1 || V3.y < y0 || V3.y > y1) return false; } return true; };
    let lo = 3, hi = 60; for (let i = 0; i < 18; i++) { const mid = (lo + hi) / 2; pose(mid); if (fits()) hi = mid; else lo = mid; } pose(hi);   // the nearest distance that shows the whole set in the free middle
    const a = camInit ? 1 - Math.exp(-dt * 5) : 1; camInit = true; camPos.lerp(tmpO.position, a); camQ.slerp(tmpO.quaternion, a); if (a === 1) { camPos.copy(tmpO.position); camQ.copy(tmpO.quaternion); }
    camera.position.copy(camPos); camera.quaternion.copy(camQ); camera.fov = fov; camera.aspect = asp; camera.updateProjectionMatrix(); camera.updateMatrixWorld();
  }
  frame(0);

  function tick() {
    if (!alive) return; const now = performance.now(), dt = Math.min(0.25, lastNow ? (now - lastNow) / 1000 : 0.016); lastNow = now; t += dt;
    frame(dt);
    // flights
    for (let i = flights.length - 1; i >= 0; i--) { const f = flights[i]; f.t = Math.min(1, f.t + dt / 0.55); const e = f.t;
      f.it.g.position.lerpVectors(f.from, f.to, e); f.it.g.position.y += Math.sin(Math.PI * e) * 1.3; f.it.g.scale.setScalar(f.it.sc * (1 + (f.k - 1) * e)); f.it.g.rotation.y = f.r0 * (1 - e) + e * 6.283;
      if (f.t >= 1) { f.it.g.rotation.y = 0; flights.splice(i, 1); audio.thud(f.s); } }
    // next item highlight
    const nx = phase === 'play' && spillT < 0 ? items[idx] : null;
    for (let i = 0; i < items.length; i++) { const it = items[i]; if (it.side) continue; const on = it === nx; it.g.position.y = it.home.y + (on ? 0.12 + Math.abs(Math.sin(t * 4)) * 0.18 : 0); it.lbl.scale.setScalar(on ? 0.78 : 0.48); it.lbl.position.y = it.home.y + ITEM_H[it.type] * it.sc + (on ? 0.6 : 0.36); }
    ring.visible = !!nx; if (nx) { ring.position.set(nx.home.x, 0.1, nx.home.z); ring.scale.setScalar(1 + Math.sin(t * 5) * 0.08); }
    // lean + wobble
    const d = diff(), a = Math.abs(d);
    if (spillT < 0) { let rz = -d * 0.045; if (a >= WOBBLE) rz += Math.sin(t * 11) * 0.06; camel.rotation.z += (rz - camel.rotation.z) * Math.min(1, dt * 6); }
    if (phase === 'play' && a >= WOBBLE && spillT < 0) { warnT -= dt; if (warnT <= 0) { warnT = 1.6; audio.warn(d > 0 ? 'L' : 'R'); } }
    // spill: the camel stands up, the load tumbles off
    if (spillT >= 0) { spillT += dt;
      if (spillT > 0.6) { const k = Math.min(1, (spillT - 0.6) / 0.7); legsF.visible = false; legsS.visible = true; legsS.scale.y = Math.max(0.05, k); lift.position.y = k * 0.85; camel.rotation.z += (-Math.sign(d) * 0.3 - camel.rotation.z) * Math.min(1, dt * 4);
        if (!tumble.length && k > 0.3) { audio.spill(); for (const s of ['L', 'R']) for (const it of stacks[s]) { root.updateMatrixWorld(true); const p = root.worldToLocal(it.g.getWorldPosition(new THREE.Vector3())); root.add(it.g); it.g.position.copy(p); tumble.push({ it, v: new THREE.Vector3((s === 'L' ? 1 : -1) * (1.5 + Math.random() * 2), 2 + Math.random() * 2, (Math.random() - 0.5) * 2), w: (Math.random() - 0.5) * 8 }); } } }
      if (spillT > 3.2 && phase === 'play') finishRound('spill'); }
    for (const tb of tumble) { const g = tb.it.g; if (g.position.y > 0.08 || tb.v.y > 0) { tb.v.y -= 9.8 * dt; g.position.addScaledVector(tb.v, dt); g.rotation.z += tb.w * dt; if (g.position.y < 0.08) { g.position.y = 0.08; tb.v.set(0, 0, 0); } } }
    // timer
    if (phase === 'play' && spillT < 0) {
      if (endT >= 0) { endT -= dt; if (endT <= 0 && !flights.length) finishRound('done'); }
      else { time -= dt; const sec = Math.ceil(time); if (sec !== lastSec) { lastSec = sec; if (sec <= 10 && sec > 0) audio.tick(); emit(); } if (time <= 0) { time = 0; finishRound('time'); } }
    }
    if (flash && flash.until < t) { flash = null; emit(); }
  }

  const api = {
    camera,
    tick,
    start() { audio.unlock(); total = 0; roundLog = []; ri = 0; buildRound(); begin(); },
    next() { audio.unlock(); if (phase !== 'round') return; ri++; buildRound(); begin(); },
    again() { api.start(); },
    left() { return load('L'); }, right() { return load('R'); }, load,
    unlock() { audio.unlock(); },
    setSafe(s) { Object.assign(safe, s || {}); },
    get phase() { return phase; }, get state() { return { phase, round: ri + 1, idx, n: items.length, L: sideW.L, R: sideW.R, diff: diff(), time, total, card, items: items.map(i => ({ type: i.type, w: i.w, fragile: i.fragile, side: i.side })) }; },
    destroy() { if (!alive) return; alive = false; el.removeEventListener('pointerdown', onDown); removeEventListener('keydown', onKey);
      clearItems(); root.removeFromParent(); root.traverse(o => { if (o.isMesh && o.geometry && !Object.values(GEO).includes(o.geometry)) o.geometry.dispose(); if (o.material && o.material !== INK && o.material !== hitMat) { o.material.map && o.material.map.dispose && o.material.map.dispose(); o.material.dispose && o.material.dispose(); } });
      audio.close(); },
  };
  emit();
  return api;
}
