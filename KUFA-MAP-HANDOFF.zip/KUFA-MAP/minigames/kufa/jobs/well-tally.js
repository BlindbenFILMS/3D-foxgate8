// 8 GATES · KUFA — WELL TALLY KEEPER (open-air JOB at the layout spot kufaTallyBoard, by the town square). Built for the world only:
// no own page, renderer, lights or loop. The world gives us host = { container, renderer, onState, active(), bd } where bd.grp is a group
// on the ground at the spot (local metres from the spot, +x east, +z south). The world already draws a NOW HIRING board at the spot
// (posts at x ±1, z 0) and a TALLY BOARD sign post at (0, -4): our set stands EAST of them (x 2.4 … 14.2).
// Game: jars come up out of a small well on a rope pulley, hop onto a plank rail and ride past the yellow STAMP ZONE.
// FULL jar (blue to the brim, shimmer) → STAMP (+10, chime). HALF or CRACKED (drips) → let it pass (stamping = mistake −15, buzz).
// Each jar type has its own tone as it enters the zone. End of a shift: Qasim al-Warid's ledger claims more full jars than there were;
// your count exact → CAUGHT HIM +100, off → −10 per jar. 3 shifts, faster and more mixed.
// STORY + NUMBERS ARE DRAFT. createWellTally(host) → { camera, tick(dt), destroy(), start(), stamp(), next(), setSafe(s), debug() }
import * as THREE from '../../../vendor/three/three.module.js';

const SHIFTS = [   // DRAFT tuning
  { n: 12, speed: 1.15, gap: 2.2, mix: [0.62, 0.26, 0.12], name: 'MORNING SHIFT' },
  { n: 15, speed: 1.55, gap: 1.85, mix: [0.52, 0.30, 0.18], name: 'NOON SHIFT · FASTER' },
  { n: 18, speed: 1.95, gap: 1.6, mix: [0.44, 0.33, 0.23], name: 'EVENING SHIFT · FASTEST' }];
const PTS = { good: 10, bad: 15, exact: 100, offPer: 10 };
const TYPE = { full: { word: 'FULL', fill: 1 }, half: { word: 'HALF', fill: 0.45 }, cracked: { word: 'CRACKED', fill: 0.62 } };
const RAM_Y = 2.75, WELL = [3.6, -0.5], RAIL0 = 5.1, RAIL1 = 13.0, DECK = 0.62, ZX = 8.6, ZH = 0.68, JS = 1.2, JAR_H = 1.32 * JS, MAXJ = 10, MAXD = 40;
const JAR_PROFILE = [[0, 0], [0.26, 0], [0.36, 0.08], [0.47, 0.36], [0.5, 0.62], [0.45, 0.92], [0.32, 1.1], [0.25, 1.18], [0.27, 1.27], [0.3, 1.32], [0.25, 1.32], [0.22, 1.2]];
const PAL = { plank: '#c9965a', woodD: '#6b4428', wood: '#9a6a3c', stone: '#cdb48a', stoneD: '#9c8460', yellow: '#ffd23a', red: '#ec3013', iron: '#3a3634', clay: '#c8743a', rope: '#e8d6a8', cloth: '#2b7fc4' };
let BEST = 0;   // best this session (memory only)

// shared kit: toon materials, unit geometries, matrix helper (the world set and the game share the builder below)
function makeKit(THREE) {
  const disposables = [], keep = x => (disposables.push(x), x);
  const grad = keep(new THREE.DataTexture(new Uint8Array([70, 70, 70, 255, 160, 160, 160, 255, 255, 255, 255, 255]), 3, 1)); grad.minFilter = grad.magFilter = THREE.NearestFilter; grad.needsUpdate = true;
  const toon = (color, o = {}) => keep(new THREE.MeshToonMaterial({ color, gradientMap: grad, ...o }));
  const OUT = keep(new THREE.MeshBasicMaterial({ color: '#140c06', side: THREE.BackSide }));
  const U = { box: keep(new THREE.BoxGeometry(1, 1, 1)), cyl: keep(new THREE.CylinderGeometry(0.5, 0.5, 1, 18)), plane: keep(new THREE.PlaneGeometry(1, 1)), disc: keep(new THREE.CircleGeometry(0.5, 20)), sph: keep(new THREE.SphereGeometry(0.5, 10, 8)) };
  const M4 = (x, y, z, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) => new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)), new THREE.Vector3(sx, sy, sz));
  return { disposables, keep, grad, toon, OUT, U, M4 };
}

// the STATIC set (deck, well, rail, trough, gantry, stamping table, tally board back, ledger lectern, dressing jars) into parent
function buildStatic(THREE, K, root) {
  const { keep, toon, OUT, U, M4 } = K;
  // ---------- static set: merged by colour (one draw call per colour) + one merged outline ----------
  const buckets = {}, outl = [];
  const put = (col, geo, x, y, z, sx, sy, sz, rx = 0, ry = 0, rz = 0, line = true) => { (buckets[col] = buckets[col] || []).push([geo, M4(x, y, z, rx, ry, rz, sx, sy, sz)]); if (line) outl.push([geo, M4(x, y, z, rx, ry, rz, sx + 0.08, sy + 0.08, sz + 0.08)]); };
  const B = (col, x, y0, z, w, h, d, ry = 0, line) => put(col, U.box, x, y0 + h / 2, z, w, h, d, 0, ry, 0, line);   // y0 = bottom
  const C = (col, x, y0, z, r, h, line) => put(col, U.cyl, x, y0 + h / 2, z, r * 2, h, r * 2, 0, 0, 0, line);
  const merge = list => { let n = 0; const parts = list.map(([g, m]) => { const q = (g.index ? g.toNonIndexed() : g.clone()); q.applyMatrix4(m); n += q.attributes.position.count; return q; });
    const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3); let o = 0; for (const q of parts) { pos.set(q.attributes.position.array, o * 3); nor.set(q.attributes.normal.array, o * 3); o += q.attributes.position.count; q.dispose(); }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.BufferAttribute(nor, 3)); return keep(g); };
  // floor: a plank deck for the job (x 2.4 … 14.2, z -3.2 … 3.6)
  B(PAL.plank, 8.3, 0, 0.2, 11.8, 0.12, 6.8, 0, false); for (let i = 0; i < 11; i++) B(PAL.wood, 2.9 + i * 1.08, 0.12, 0.2, 0.06, 0.01, 6.8, 0, false);
  // the well: stone ring, posts, crossbeam (the pulley wheel + rope move: built below)
  C(PAL.stone, WELL[0], 0, WELL[1], 1.05, 0.9); C(PAL.stoneD, WELL[0], 0.9, WELL[1], 1.12, 0.14);
  B(PAL.woodD, WELL[0] - 1.2, 0, WELL[1], 0.22, 3.2, 0.22); B(PAL.woodD, WELL[0] + 1.2, 0, WELL[1], 0.22, 3.2, 0.22); B(PAL.woodD, WELL[0], 3.1, WELL[1], 2.7, 0.22, 0.26);
  // plank rail on legs, from the well to the end trough
  const RL = RAIL1 - RAIL0 + 0.6, RC = (RAIL0 + RAIL1) / 2;
  B(PAL.wood, RC, DECK - 0.1, 0, RL, 0.1, 1.05); for (const s of [-1, 1]) B(PAL.woodD, RC, DECK, s * 0.55, RL, 0.12, 0.1);
  for (let x = RAIL0; x <= RAIL1 + 0.01; x += 1.6) for (const s of [-1, 1]) B(PAL.woodD, x, 0.12, s * 0.42, 0.14, DECK - 0.22, 0.14, 0, false);
  // end trough (jars go down into it) + a stack of jars by it
  B(PAL.woodD, 13.85, 0.12, 0, 1.3, 0.55, 1.4);
  // stamp gantry: yellow posts mark the STAMP ZONE, a beam and an arm hold the stamp ram over the rail
  for (const s of [-1, 1]) B(PAL.yellow, ZX + s * (ZH + 0.18), 0.12, -0.78, 0.2, 3.3, 0.2);
  B(PAL.yellow, ZX, 3.3, -0.78, ZH * 2 + 0.6, 0.22, 0.26); B(PAL.iron, ZX, 3.1, -0.4, 0.2, 0.2, 0.9);
  // stamping table in front of you (low, so it never hides the jars)
  B(PAL.wood, ZX, 0.62, 2.0, 3.4, 0.14, 1.0); for (const sx of [-1, 1]) for (const sz of [-1, 1]) B(PAL.woodD, ZX + sx * 1.5, 0.12, 2.0 + sz * 0.38, 0.12, 0.5, 0.12, 0, false);
  B(PAL.red, ZX - 1.0, 0.76, 2.0, 0.5, 0.08, 0.36); B('#1f6b33', ZX - 1.0, 0.84, 2.0, 0.36, 0.02, 0.24, 0, false); B('#efe3c4', ZX + 0.9, 0.76, 2.0, 0.8, 0.1, 0.55); B(PAL.cloth, ZX + 0.9, 0.86, 2.0, 0.82, 0.02, 0.1, 0, false);
  // tally board crowns the gantry (its face is a canvas, below)
  B(PAL.woodD, ZX, 3.5, -0.84, 3.9, 2.0, 0.12);
  // Qasim's ledger lectern (east end)
  B(PAL.woodD, 12.2, 0.12, -1.9, 0.5, 1.1, 0.5); put(PAL.wood, U.box, 12.2, 1.32, -1.85, 1.3, 0.12, 1.0, -0.5, 0, 0);
  // water jars stacked by the well (dressing)
  for (const [x, z] of [[2.9, 1.6], [3.7, 2.1], [2.8, 2.6]]) { C(PAL.clay, x, 0.12, z, 0.34, 0.75); C('#2a1a10', x, 0.87, z, 0.2, 0.04, false); }
  for (const [col, list] of Object.entries(buckets)) root.add(new THREE.Mesh(merge(list), toon(col)));
  root.add(new THREE.Mesh(merge(outl), OUT));
  { const w = new THREE.Mesh(U.disc, toon('#1d5f9c')); w.rotation.x = -Math.PI / 2; w.scale.setScalar(1.85); w.position.set(WELL[0], 0.8, WELL[1]); root.add(w); }
}

// WORLD (walk mode): the job's set stands at its spot while you walk (host: entry.idle). Hidden while the game plays (the game builds its own).
export function buildWellTallySet(THREE, spotGroup) {
  const K = makeKit(THREE), { toon, U, OUT } = K, g = new THREE.Group(); g.name = 'wellTallyIdle'; buildStatic(THREE, K, g);
  const wheel = new THREE.Mesh(K.keep(new THREE.CylinderGeometry(0.42, 0.42, 0.16, 16)), toon('#9a6a3c')); wheel.rotation.x = Math.PI / 2; wheel.position.set(WELL[0], 2.8, WELL[1]); g.add(wheel);
  const rope = new THREE.Mesh(U.box, toon('#e8d6a8')); rope.scale.set(0.05, 1.2, 0.05); rope.position.set(WELL[0] + 0.42, 2.2, WELL[1]); g.add(rope);
  const head = new THREE.Mesh(U.box, toon('#ec3013')); head.scale.set(0.8, 0.3, 0.8); head.position.set(ZX, RAM_Y + 0.15, 0); g.add(head);
  const strip = new THREE.Mesh(U.plane, K.keep(new THREE.MeshBasicMaterial({ color: '#ffd23a', toneMapped: false }))); strip.rotation.x = -Math.PI / 2; strip.scale.set(ZH * 2, 1, 1); strip.position.set(ZX, DECK + 0.006, 0); g.add(strip);
  // the tally board face: the job's name (big words)
  const c = document.createElement('canvas'); c.width = 1024; c.height = 512; const x = c.getContext('2d'), F = 'Archivo, "Arial Black", Arial, sans-serif';
  x.fillStyle = '#201e1d'; x.fillRect(0, 0, 1024, 512); x.fillStyle = '#ec3013'; x.fillRect(0, 0, 1024, 110); x.fillStyle = '#fff'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = '900 64px ' + F; x.fillText('WATER BANK · TALLY', 512, 58);
  x.fillStyle = '#ffd23a'; x.font = '900 104px ' + F; x.fillText('WELL TALLY', 512, 210); x.fillText('KEEPER', 512, 320); x.fillStyle = '#f3f2f2'; x.font = '800 46px ' + F; x.fillText('COUNT THE FULL JARS', 512, 440);
  const t = K.keep(new THREE.CanvasTexture(c)); t.colorSpace = THREE.SRGBColorSpace; const face = new THREE.Mesh(U.plane, K.keep(new THREE.MeshBasicMaterial({ map: t, toneMapped: false }))); face.scale.set(3.7, 1.85, 1); face.position.set(ZX, 4.5, -0.77); g.add(face);
  // a few jars waiting on the rail (one full: blue to the brim)
  const lathe = K.keep(new THREE.LatheGeometry(JAR_PROFILE.map(([r, y]) => new THREE.Vector2(r, y)), 16)), clay = toon('#c8743a', { side: THREE.DoubleSide });
  for (const [jx, full] of [[5.6, true], [7.1, false], [11.4, true]]) { const j = new THREE.Group(); j.position.set(jx, DECK, 0); j.scale.setScalar(JS); g.add(j);
    j.add(new THREE.Mesh(lathe, clay)); const o = new THREE.Mesh(lathe, OUT); o.scale.set(1.06, 1.03, 1.06); j.add(o);
    const top = new THREE.Mesh(U.disc, toon(full ? '#39b8ff' : '#2a1a10')); top.rotation.x = -Math.PI / 2; top.scale.setScalar(full ? 0.56 : 0.44); top.position.y = full ? 1.3 : 1.16; j.add(top); }
  g.userData.dispose = () => { for (const d of K.disposables) { try { d.dispose(); } catch (e) {} } };
  spotGroup.add(g); return g;
}

export function createWellTally(host) {
  const { renderer, onState = () => {}, active = () => true, bd } = host;
  const el = renderer.domElement, root = new THREE.Group(); root.name = 'wellTally'; bd.grp.add(root);
  const K = makeKit(THREE), { disposables, keep, grad, toon, OUT, U, M4 } = K;
  buildStatic(THREE, K, root);

  // moving set pieces
  const wheel = new THREE.Mesh(keep(new THREE.CylinderGeometry(0.42, 0.42, 0.16, 16)), toon(PAL.wood)); wheel.rotation.x = Math.PI / 2; wheel.position.set(WELL[0], 2.8, WELL[1]); root.add(wheel);
  const spokes = new THREE.Mesh(U.box, toon(PAL.woodD)); spokes.scale.set(0.84, 0.1, 0.2); wheel.add(spokes); spokes.position.y = 0.1;
  const rope = new THREE.Mesh(U.box, toon(PAL.rope)); rope.scale.set(0.05, 1, 0.05); root.add(rope);
  const ram = new THREE.Group(); ram.position.set(ZX, RAM_Y, 0); root.add(ram);
  { const rod = new THREE.Mesh(U.cyl, toon(PAL.iron)); rod.scale.set(0.12, 0.8, 0.12); rod.position.y = 0.55; ram.add(rod);
    const head = new THREE.Mesh(U.box, toon(PAL.red)); head.scale.set(0.8, 0.3, 0.8); head.position.y = 0.15; ram.add(head);
    const ink = new THREE.Mesh(U.box, toon('#22c55e')); ink.scale.set(0.66, 0.04, 0.66); ink.position.y = -0.01; ram.add(ink); }
  const zoneMat = keep(new THREE.MeshBasicMaterial({ color: '#ffd23a', transparent: true, opacity: 0.7, toneMapped: false }));
  const zoneStrip = new THREE.Mesh(U.plane, zoneMat); zoneStrip.rotation.x = -Math.PI / 2; zoneStrip.scale.set(ZH * 2, 1.0, 1); zoneStrip.position.set(ZX, DECK + 0.006, 0); root.add(zoneStrip);
  const zoneFloor = new THREE.Mesh(U.plane, zoneMat); zoneFloor.rotation.x = -Math.PI / 2; zoneFloor.scale.set(ZH * 2, 1.5, 1); zoneFloor.position.set(ZX, 0.13, 1.0); root.add(zoneFloor);

  // canvas faces: the tally board + Qasim's ledger page
  const mkCanvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const t = keep(new THREE.CanvasTexture(c)); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return { c, g: c.getContext('2d'), t }; };
  const FONT = 'Archivo, "Arial Black", Arial, sans-serif';
  const tally = mkCanvas(1024, 512), ledgerC = mkCanvas(512, 400);
  { const m = new THREE.Mesh(U.plane, keep(new THREE.MeshBasicMaterial({ map: tally.t, toneMapped: false }))); m.scale.set(3.7, 1.85, 1); m.position.set(ZX, 4.5, -0.77); root.add(m); }
  { const m = new THREE.Mesh(U.plane, keep(new THREE.MeshBasicMaterial({ map: ledgerC.t, toneMapped: false }))); m.scale.set(1.2, 0.94, 1); m.position.set(12.2, 1.45, -1.79); m.rotation.set(-0.5, 0, 0); root.add(m); }
  const drawTally = () => { const { g, c, t } = tally; g.fillStyle = '#201e1d'; g.fillRect(0, 0, c.width, c.height); g.fillStyle = '#ec3013'; g.fillRect(0, 0, c.width, 92);
    g.fillStyle = '#fff'; g.font = '900 52px ' + FONT; g.textBaseline = 'middle'; g.textAlign = 'left'; g.fillText('WATER BANK · TALLY', 30, 48); g.textAlign = 'right'; g.fillText('SHIFT ' + (S.shift + 1) + '/3', c.width - 30, 48);
    g.textAlign = 'left'; g.fillStyle = '#ffd23a'; g.font = '900 46px ' + FONT; g.fillText('YOUR COUNT', 34, 150);
    g.fillStyle = '#f3f2f2'; g.font = '900 280px ' + FONT; g.fillText(String(S.count), 30, 340);
    // tally marks in groups of five
    g.strokeStyle = '#f3f2f2'; g.lineWidth = 16; g.lineCap = 'square'; const n = Math.min(S.count, 30);
    for (let i = 0; i < n; i++) { const grp = Math.floor(i / 5), k = i % 5, gx = 470 + (grp % 3) * 180, gy = 140 + Math.floor(grp / 3) * 170;
      g.beginPath(); if (k < 4) { g.moveTo(gx + k * 34, gy); g.lineTo(gx + k * 34, gy + 130); } else { g.moveTo(gx - 16, gy + 110); g.lineTo(gx + 120, gy + 20); } g.stroke(); }
    g.fillStyle = '#8a847e'; g.font = '800 34px ' + FONT; g.fillText('STAMP ONLY FULL JARS', 34, 470); t.needsUpdate = true; };
  const drawLedger = () => { const { g, c, t } = ledgerC, L = S.ledger; g.fillStyle = '#efe3c4'; g.fillRect(0, 0, c.width, c.height); g.strokeStyle = '#6b4428'; g.lineWidth = 14; g.strokeRect(7, 7, c.width - 14, c.height - 14);
    g.fillStyle = '#201e1d'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = '900 40px ' + FONT; g.fillText('QASIM AL-WARID', 256, 60); g.font = '800 30px ' + FONT; g.fillStyle = '#6b4428'; g.fillText('WATER BROKER · LEDGER', 256, 105);
    g.fillStyle = '#201e1d'; g.font = '900 34px ' + FONT; g.fillText('FULL JARS', 256, 170); g.font = '900 150px ' + FONT; g.fillStyle = L ? '#ec3013' : '#201e1d'; g.fillText(L ? String(L.claim) : '?', 256, 280);
    g.font = '800 30px ' + FONT; g.fillStyle = '#201e1d'; g.fillText(L ? (L.exact ? 'CAUGHT! REAL COUNT ' + L.truth : 'REAL COUNT ' + L.truth) : '(DRAFT)', 256, 360); t.needsUpdate = true; };

  // ---------- jars: instanced parts ----------
  const lathe = keep(new THREE.LatheGeometry(JAR_PROFILE.map(([r, y]) => new THREE.Vector2(r, y)), 16));
  const IM = (geo, mat, n = MAXJ) => { const m = new THREE.InstancedMesh(geo, mat, n); m.count = n; m.frustumCulled = false; const z = new THREE.Matrix4().makeScale(0, 0, 0); for (let i = 0; i < n; i++) m.setMatrixAt(i, z); root.add(m); return m; };
  const tickTex = mkCanvas(128, 128), xTex = mkCanvas(128, 128);
  for (const [T, bg, mark] of [[tickTex, '#22c55e', 'tick'], [xTex, '#ec3013', 'x']]) { const g = T.g; g.fillStyle = '#fff'; g.beginPath(); g.arc(64, 64, 62, 0, 7); g.fill(); g.fillStyle = bg; g.beginPath(); g.arc(64, 64, 54, 0, 7); g.fill(); g.strokeStyle = '#fff'; g.lineWidth = 16; g.lineCap = 'round'; g.lineJoin = 'round'; g.beginPath(); if (mark === 'tick') { g.moveTo(34, 66); g.lineTo(56, 88); g.lineTo(96, 40); } else { g.moveTo(40, 40); g.lineTo(88, 88); g.moveTo(88, 40); g.lineTo(40, 88); } g.stroke(); T.t.needsUpdate = true; }
  const crackTex = mkCanvas(128, 256); { const g = crackTex.g; g.clearRect(0, 0, 128, 256); g.strokeStyle = '#140c06'; g.lineWidth = 12; g.lineJoin = 'miter'; g.beginPath(); g.moveTo(70, 6); g.lineTo(40, 70); g.lineTo(84, 110); g.lineTo(36, 180); g.lineTo(70, 250); g.moveTo(84, 110); g.lineTo(118, 140); g.stroke(); crackTex.t.needsUpdate = true; }
  const P = {
    body: IM(lathe, toon('#ffffff', { side: THREE.DoubleSide })), out: IM(lathe, OUT),
    frame: IM(U.box, toon('#f3f2f2')), win: IM(U.box, toon('#14202b')), fill: IM(U.box, keep(new THREE.MeshBasicMaterial({ color: '#2fb2ff', toneMapped: false }))),
    top: IM(U.disc, toon('#ffffff', { side: THREE.DoubleSide })), dome: IM(U.sph, keep(new THREE.MeshBasicMaterial({ color: '#5cc8ff', toneMapped: false }))),
    ring: IM(keep(new THREE.TorusGeometry(0.34, 0.035, 6, 20)), keep(new THREE.MeshBasicMaterial({ color: '#ffffff', toneMapped: false }))),
    crack: IM(U.plane, keep(new THREE.MeshBasicMaterial({ map: crackTex.t, transparent: true, depthWrite: false }))),
    tick: IM(U.plane, keep(new THREE.MeshBasicMaterial({ map: tickTex.t, transparent: true, toneMapped: false }))), x: IM(U.plane, keep(new THREE.MeshBasicMaterial({ map: xTex.t, transparent: true, toneMapped: false }))),
    drip: IM(U.sph, keep(new THREE.MeshBasicMaterial({ color: '#2fb2ff', toneMapped: false })), MAXD), puddle: IM(U.disc, keep(new THREE.MeshBasicMaterial({ color: '#2fb2ff', transparent: true, opacity: 0.75, toneMapped: false })), MAXD) };
  const clayCols = ['#c8743a', '#bf6a33', '#cf7d42', '#b9663a'].map(c => new THREE.Color(c)), BLUE = new THREE.Color('#39b8ff'), DARK = new THREE.Color('#2a1a10');
  for (let i = 0; i < MAXJ; i++) P.body.setColorAt(i, clayCols[i % 4]); P.body.instanceColor.needsUpdate = true; for (let i = 0; i < MAXJ; i++) P.top.setColorAt(i, DARK); P.top.instanceColor.needsUpdate = true;
  const ZERO = new THREE.Matrix4().makeScale(0, 0, 0);

  // ---------- camera (child of our group; the host copies its world pose + fov) ----------
  const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 400); root.add(camera);
  let safe = { top: 0, bottom: 0, left: 0, right: 0 }, camInit = false, camYaw = 0;
  const cT = new THREE.Vector3(), cP = new THREE.Vector3(), tmpV = new THREE.Vector3(), upV = new THREE.Vector3(0, 1, 0), camPos = new THREE.Vector3(), camLook = new THREE.Vector3();
  function placeCamera(dt) {
    const W = el.clientWidth || innerWidth, H = el.clientHeight || innerHeight, aspect = W / H, port = aspect < 1, vt = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
    const sx0 = Math.min(0.6, safe.left / W), sx1 = 1 - Math.min(0.6, safe.right / W), sy0 = Math.min(0.5, safe.top / H), sy1 = 1 - Math.min(0.6, safe.bottom / H);
    const fx = Math.max(0.3, sx1 - sx0), fy = Math.max(0.3, sy1 - sy0);
    const yaw = port ? 0.3 : 0.1, el2 = port ? 0.36 : 0.32, hw = port ? 3.4 : 4.7, hh = port ? 2.9 : 2.75;
    cT.set(port ? ZX - 1.0 : ZX - 0.6, port ? 2.4 : 2.35, -0.4);
    const d = Math.max(hw / (vt * aspect * fx), hh / (vt * fy));
    const dir = tmpV.set(Math.sin(yaw) * Math.cos(el2), Math.sin(el2), Math.cos(yaw) * Math.cos(el2));
    const f = dir.clone().negate(), r = new THREE.Vector3().crossVectors(f, upV).normalize(), u = new THREE.Vector3().crossVectors(r, f);
    const cx = sx0 + sx1 - 1, cy = 1 - (sy0 + sy1), shift = r.multiplyScalar(-cx * vt * aspect * d).add(u.multiplyScalar(-cy * vt * d));
    cP.copy(cT).addScaledVector(dir, d).add(shift); const look = cT.clone().add(shift);
    const k = camInit ? 1 - Math.exp(-dt * 4) : 1; camInit = true; camPos.lerp(cP, k); camLook.lerp(look, k); camYaw += (yaw - camYaw) * k;
    camera.aspect = aspect; camera.position.copy(camPos); root.updateMatrixWorld(); camera.lookAt(root.localToWorld(camLook.clone())); camera.updateProjectionMatrix(); camera.updateMatrixWorld(); }

  // ---------- sound (one AudioContext, made on the first tap) ----------
  let AC = null;
  const ensureAudio = () => { if (AC) { if (AC.state === 'suspended') AC.resume().catch(() => {}); return; } try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { AC = null; } };
  const tone = (freq, dur, { type = 'sine', vol = 0.18, at = 0, slide = 0, vib = 0 } = {}) => { if (!AC) return; try { const t0 = AC.currentTime + at, o = AC.createOscillator(), g = AC.createGain(); o.type = type; o.frequency.setValueAtTime(freq, t0); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t0 + dur);
      if (vib) { const l = AC.createOscillator(), lg = AC.createGain(); l.frequency.value = vib; lg.gain.value = freq * 0.12; l.connect(lg); lg.connect(o.frequency); l.start(t0); l.stop(t0 + dur); }
      g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur); o.connect(g); g.connect(AC.destination); o.start(t0); o.stop(t0 + dur + 0.02); } catch (e) {} };
  const SND = {
    full: () => { tone(1046, 0.16, { type: 'sine', vol: 0.2 }); tone(1568, 0.22, { type: 'sine', vol: 0.16, at: 0.1 }); },          // bright ting-ting
    half: () => { tone(392, 0.09, { type: 'triangle', vol: 0.26 }); tone(392, 0.09, { type: 'triangle', vol: 0.26, at: 0.15 }); },    // hollow tok-tok
    cracked: () => { tone(150, 0.38, { type: 'sawtooth', vol: 0.12, vib: 28 }); },                                                 // low rattle
    good: () => { [784, 988, 1175].forEach((f, i) => tone(f, 0.18, { type: 'triangle', vol: 0.2, at: i * 0.06 })); },
    bad: () => { tone(110, 0.4, { type: 'square', vol: 0.12 }); tone(104, 0.4, { type: 'square', vol: 0.1 }); },
    empty: () => tone(90, 0.12, { type: 'sine', vol: 0.3, slide: -30 }),
    missed: () => tone(330, 0.3, { type: 'triangle', vol: 0.12, slide: -120 }),
    go: () => { tone(523, 0.12, { type: 'triangle', vol: 0.18 }); tone(784, 0.2, { type: 'triangle', vol: 0.18, at: 0.14 }); },
    caught: () => { [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.22, { type: 'triangle', vol: 0.2, at: i * 0.11 })); },
    off: () => { [392, 330, 262].forEach((f, i) => tone(f, 0.25, { type: 'triangle', vol: 0.18, at: i * 0.16 })); } };

  // ---------- state ----------
  const S = { phase: 'intro', shift: 0, count: 0, good: 0, bad: 0, missed: 0, score: 0, shiftScore: 0, queue: [], spawnT: 0, total: 0, truth: 0, ledger: null, history: [], flash: null, t: 0, lastEmit: 0, rope: 0, ramT: -1, ramTo: 1.95 };
  const jars = [], drips = []; let jarId = 0, alive = true, testN = 0, testK = 1;
  const freeSlot = () => { for (let i = 0; i < MAXJ; i++) if (!jars.some(j => j.slot === i)) return i; return -1; };
  const flash = (txt, col = '#ffd23a', secs = 1.4) => { S.flash = { txt, col, until: S.t + secs, id: (S.flash ? S.flash.id : 0) + 1 }; };
  const liveTxt = () => S.flash ? S.flash.txt : '';
  const inZone = j => j.state === 'ride' && Math.abs(j.x - ZX) < ZH;
  function emit() { S.lastEmit = S.t; const sh = SHIFTS[S.shift];
    onState({ phase: S.phase, shift: S.shift + 1, shifts: SHIFTS.length, shiftName: sh.name, count: S.count, score: S.score, good: S.good, bad: S.bad, best: BEST,
      jarsLeft: S.queue.length + jars.filter(j => j.state === 'lift' || j.state === 'hop' || (j.state === 'ride' && j.x < ZX + ZH)).length, jarsTotal: sh.n,
      zone: jars.some(inZone), flash: S.flash && S.flash.until > S.t ? { txt: S.flash.txt, col: S.flash.col, id: S.flash.id } : null,
      ledger: S.ledger, history: S.history.slice(), live: liveTxt() }); }

  function beginShift(i) { S.shift = i; const sh = testN ? { ...SHIFTS[i], n: testN } : SHIFTS[i], nF = Math.round(sh.n * sh.mix[0]), nC = Math.max(1, Math.round(sh.n * sh.mix[2])), nH = sh.n - nF - nC;
    const q = [...Array(nF).fill('full'), ...Array(nH).fill('half'), ...Array(nC).fill('cracked')]; for (let k = q.length - 1; k > 0; k--) { const r = Math.floor(Math.random() * (k + 1)); [q[k], q[r]] = [q[r], q[k]]; }
    if (q[0] !== 'full') { const k = q.indexOf('full'); [q[0], q[k]] = [q[k], q[0]]; }   // the first jar of a shift is a full one
    S.queue = q; S.truth = nF; S.count = 0; S.good = 0; S.bad = 0; S.missed = 0; S.shiftScore = 0; S.ledger = null; S.spawnT = 1.8; S.phase = 'play';
    flash('SHIFT ' + (i + 1) + ' OF 3 · GO!', '#ffd23a', 1.8); SND.go(); drawTally(); drawLedger(); emit(); }
  function endShift() { const yours = S.count, truth = S.truth, claim = truth + 2 + Math.floor(Math.random() * 3) + S.shift, exact = yours === truth, delta = yours - truth;   // DRAFT: Qasim always claims 2–6 more
    const pen = exact ? 0 : Math.abs(delta) * PTS.offPer, bonus = exact ? PTS.exact : -pen; S.score += bonus; S.shiftScore += bonus;
    S.ledger = { shift: S.shift + 1, claim, truth, yours, exact, delta, bonus, good: S.good, bad: S.bad, missed: S.missed, shiftScore: S.shiftScore, last: S.shift === SHIFTS.length - 1,
      head: exact ? 'CAUGHT HIM!' : 'YOUR COUNT IS OFF', msg: exact ? 'Qasim claimed ' + claim + ', the real count is ' + truth + '.' : 'You counted ' + yours + ', the real count is ' + truth + ' (' + (delta > 0 ? delta + ' too many' : -delta + ' too few') + '). Qasim claimed ' + claim + ' and walks off.' };
    S.history.push({ shift: S.shift + 1, exact, yours, truth, claim, score: S.shiftScore, good: S.good, bad: S.bad });
    S.phase = 'ledger'; (exact ? SND.caught : SND.off)(); flash(exact ? 'CAUGHT HIM! +' + PTS.exact : 'COUNT OFF · ' + bonus, exact ? '#22c55e' : '#ff9a8a', 2.5); drawLedger(); emit(); }
  function finish() { S.phase = 'results'; BEST = Math.max(BEST, S.score); S.ledger = null; emit(); }

  function spawn() { const slot = freeSlot(); if (slot < 0) { S.spawnT = 0.2; return; } const type = S.queue.shift();
    jars.push({ id: ++jarId, slot, type, state: 'lift', t: 0, x: WELL[0], y: -1.4, z: WELL[1], s: 1, fill: TYPE[type].fill, stamped: null, cued: false, passed: false, dripT: 0.2, wob: Math.random() * 6 }); }
  function stamp(target) { if (!alive) return; ensureAudio(); if (S.phase !== 'play') return; if (S.ramT >= 0 && S.ramT < 0.12) return;
    let j = target && inZone(target) && !target.stamped ? target : null;
    if (!j) { let bestD = 9; for (const q of jars) if (inZone(q) && !q.stamped && Math.abs(q.x - ZX) < bestD) { bestD = Math.abs(q.x - ZX); j = q; } }
    S.ramT = 0; S.ramTo = j ? DECK + JAR_H + 0.02 : DECK + 0.7;
    if (!j) { if (target) { flash('WAIT FOR THE YELLOW ZONE', '#cfcac2', 1.0); } else flash('NO JAR IN THE ZONE', '#cfcac2', 0.9); SND.empty(); emit(); return; }
    S.count++;
    if (j.type === 'full') { j.stamped = 'good'; S.good++; S.score += PTS.good; S.shiftScore += PTS.good; SND.good(); flash('FULL · +' + PTS.good, '#22c55e', 1.0); }
    else { j.stamped = 'bad'; S.bad++; S.score -= PTS.bad; S.shiftScore -= PTS.bad; SND.bad(); flash((j.type === 'half' ? 'HALF JAR!' : 'CRACKED JAR!') + ' −' + PTS.bad, '#ff6a52', 1.3); }
    drawTally(); emit(); }

  // ---------- input ----------
  const proj = new THREE.Vector3();
  const onDown = e => { if (!alive || !active()) return; ensureAudio(); if (S.phase !== 'play' || (e.button && e.button > 0)) return;
    const r = el.getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top; let best = null, bestD = 1e9;
    for (const j of jars) { if (j.state !== 'ride') continue; root.localToWorld(proj.set(j.x, j.y + JAR_H / 2, j.z)); proj.project(camera); const sx = (proj.x + 1) / 2 * r.width, sy = (1 - proj.y) / 2 * r.height;
      root.localToWorld(proj.set(j.x, j.y + JAR_H, j.z)); proj.project(camera); const rad = Math.max(48, Math.abs((1 - proj.y) / 2 * r.height - sy) * 1.25), dd = Math.hypot(px - sx, py - sy); if (dd < rad && dd < bestD) { bestD = dd; best = j; } }
    if (best) stamp(best); };
  const onKey = e => { if (!alive || !active() || S.phase !== 'play') return; if (e.key === ' ' || e.key === 'Enter' || e.key.toLowerCase() === 's') { if (e.target && /BUTTON|INPUT/.test(e.target.tagName) && e.key !== 's') return; e.preventDefault(); stamp(); } };
  el.addEventListener('pointerdown', onDown); addEventListener('keydown', onKey);

  // ---------- per-frame ----------
  const mtx = new THREE.Matrix4(), base = new THREE.Matrix4(), part = new THREE.Matrix4();
  const setPart = (im, i, m) => { mtx.multiplyMatrices(base, m); im.setMatrixAt(i, mtx); };
  const PM = { frame: M4(0, 0.66, 0.47, 0, 0, 0, 0.24, 0.86, 0.06), win: M4(0, 0.66, 0.5, 0, 0, 0, 0.15, 0.76, 0.03), crack: M4(-0.22, 0.6, 0.5, 0, -0.35, 0, 0.32, 0.64, 1), mark: M4(0.0, 1.0, 0.43, -0.45, 0, 0, 0.5, 0.5, 1), ring: M4(0, 1.36, 0, Math.PI / 2, 0, 0, 1, 1, 1) };
  function drawJars() { const used = new Set();
    for (const j of jars) { const i = j.slot; used.add(i); const wob = j.state === 'ride' ? Math.sin(S.t * 7 + j.wob) * 0.035 : 0;
      base.compose(proj.set(j.x, j.y, j.z), new THREE.Quaternion().setFromEuler(new THREE.Euler(0, camYaw, wob)), tmpV.set(j.s * JS, j.s * JS, j.s * JS));
      P.body.setMatrixAt(i, base); mtx.copy(base).multiply(part.makeScale(1.06, 1.03, 1.06)); P.out.setMatrixAt(i, mtx);
      setPart(P.frame, i, PM.frame); setPart(P.win, i, PM.win);
      const fl = Math.max(0.02, j.fill); setPart(P.fill, i, part.compose(tmpV.set(0, 0.29 + 0.37 * fl, 0.53), new THREE.Quaternion(), new THREE.Vector3(0.13, 0.74 * fl, 0.03)));
      const full = j.type === 'full'; P.top.setColorAt(i, full ? BLUE : DARK);
      setPart(P.top, i, part.compose(tmpV.set(0, full ? 1.3 : 1.16, 0), new THREE.Quaternion().setFromEuler(new THREE.Euler(-Math.PI / 2, 0, 0)), new THREE.Vector3(full ? 0.56 : 0.44, full ? 0.56 : 0.44, 1)));
      if (full) { setPart(P.dome, i, part.compose(tmpV.set(0, 1.31, 0), new THREE.Quaternion(), new THREE.Vector3(0.5, 0.16, 0.5))); const pu = 1 + 0.25 * Math.sin(S.t * 6 + j.wob); setPart(P.ring, i, mtx.copy(PM.ring).multiply(part.makeScale(pu, pu, pu))); }
      else { P.dome.setMatrixAt(i, ZERO); P.ring.setMatrixAt(i, ZERO); }
      if (j.type === 'cracked') setPart(P.crack, i, PM.crack); else P.crack.setMatrixAt(i, ZERO);
      if (j.stamped === 'good') { setPart(P.tick, i, PM.mark); P.x.setMatrixAt(i, ZERO); } else if (j.stamped === 'bad') { setPart(P.x, i, PM.mark); P.tick.setMatrixAt(i, ZERO); } else { P.tick.setMatrixAt(i, ZERO); P.x.setMatrixAt(i, ZERO); } }
    for (let i = 0; i < MAXJ; i++) if (!used.has(i)) for (const k of ['body', 'out', 'frame', 'win', 'fill', 'top', 'dome', 'ring', 'crack', 'tick', 'x']) P[k].setMatrixAt(i, ZERO);
    for (const k of ['body', 'out', 'frame', 'win', 'fill', 'top', 'dome', 'ring', 'crack', 'tick', 'x']) P[k].instanceMatrix.needsUpdate = true; P.top.instanceColor.needsUpdate = true;
    for (let i = 0; i < MAXD; i++) { const d = drips[i]; if (!d) { P.drip.setMatrixAt(i, ZERO); P.puddle.setMatrixAt(i, ZERO); continue; }
      if (d.y > DECK + 0.02) { P.drip.setMatrixAt(i, M4(d.x, d.y, d.z, 0, 0, 0, 0.1, 0.16, 0.1)); P.puddle.setMatrixAt(i, ZERO); }
      else { P.drip.setMatrixAt(i, ZERO); const s = 0.28 * Math.min(1, d.life * 2); P.puddle.setMatrixAt(i, M4(d.x, DECK + 0.01, d.z, -Math.PI / 2, 0, 0, s, s, 1)); } }
    P.drip.instanceMatrix.needsUpdate = P.puddle.instanceMatrix.needsUpdate = true; }

  function update(dt) { S.t += dt; const sh = SHIFTS[S.shift];
    if (S.phase === 'play') { S.spawnT -= dt; if (S.queue.length && S.spawnT <= 0) { spawn(); S.spawnT += sh.gap / sh.speed * (0.85 + Math.random() * 0.3); }
      if (!S.queue.length && !jars.length) endShift(); }
    let lifting = false;
    for (const j of jars) { j.t += dt;
      if (j.state === 'lift') { lifting = true; const u = Math.min(1, j.t / 0.75); j.y = -1.4 + 2.35 * (1 - Math.pow(1 - u, 2)); if (u >= 1) { j.state = 'hop'; j.t = 0; } }
      else if (j.state === 'hop') { const u = Math.min(1, j.t / 0.45); j.x = WELL[0] + (RAIL0 - WELL[0]) * u; j.z = WELL[1] * (1 - u); j.y = 0.95 + (DECK - 0.95) * u + Math.sin(Math.PI * u) * 0.5; if (u >= 1) { j.state = 'ride'; j.t = 0; j.x = RAIL0; j.z = 0; j.y = DECK; } }
      else if (j.state === 'ride') { j.x += sh.speed * dt;
        if (!j.cued && j.x > ZX - ZH) { j.cued = true; SND[j.type](); }
        if (!j.passed && j.x > ZX + ZH) { j.passed = true; if (j.type === 'full' && !j.stamped) { S.missed++; SND.missed(); flash('A FULL JAR GOT PAST', '#ffb35a', 1.0); } emit(); }
        if (j.x >= RAIL1) { j.state = 'drop'; j.t = 0; } }
      else if (j.state === 'drop') { const u = Math.min(1, j.t / 0.5); j.x = RAIL1 + 0.85 * u; j.y = DECK - u * 0.9; j.s = 1 - 0.6 * u; if (u >= 1) j.state = 'gone'; }
      if (j.type === 'cracked' && (j.state === 'ride' || j.state === 'hop')) { j.dripT -= dt; j.fill = Math.max(0.3, j.fill - dt * 0.02); if (j.dripT <= 0) { j.dripT = 0.22; const k = drips.findIndex(d => !d); const nd = { x: j.x + (-0.22 * Math.cos(camYaw) + 0.5 * Math.sin(camYaw)) * JS, y: j.y + 0.62 * JS, z: j.z + (0.5 * Math.cos(camYaw) + 0.22 * Math.sin(camYaw)) * JS, vy: 0, life: 1.6 }; if (k >= 0) drips[k] = nd; else if (drips.length < MAXD) drips.push(nd); } } }
    for (let k = jars.length - 1; k >= 0; k--) if (jars[k].state === 'gone') jars.splice(k, 1);
    for (let k = 0; k < drips.length; k++) { const d = drips[k]; if (!d) continue; if (d.y > DECK + 0.02) { d.vy -= 9 * dt * 0.35; d.y = Math.max(DECK + 0.01, d.y + d.vy * dt); } else { d.life -= dt; if (d.life <= 0) drips[k] = null; } }
    // pulley + rope follow the lifting jar
    const lj = jars.find(j => j.state === 'lift'); wheel.rotation.y += (lifting ? 6 : 0.4) * dt;
    const ropeBot = lj ? lj.y + JAR_H + 0.05 : 1.6 + Math.sin(S.t * 1.3) * 0.05, ropeTop = 2.8; rope.scale.y = Math.max(0.05, ropeTop - ropeBot); rope.position.set(WELL[0] + 0.42, (ropeTop + ropeBot) / 2, WELL[1]);
    // stamp ram
    if (S.ramT >= 0) { S.ramT += dt; const u = S.ramT / 0.36, down = u < 0.4 ? u / 0.4 : Math.max(0, 1 - (u - 0.4) / 0.6); ram.position.y = RAM_Y + (S.ramTo - RAM_Y) * Math.sin(down * Math.PI / 2); if (u >= 1) { S.ramT = -1; ram.position.y = RAM_Y; } }
    const z = jars.some(inZone); zoneMat.color.set(z ? '#fff27a' : '#ffd23a'); zoneMat.opacity = z ? 0.95 : 0.6 + 0.12 * Math.sin(S.t * 3);
    if (S.flash && S.flash.until <= S.t && S.flash.shown !== false) { S.flash.shown = false; emit(); }
    if (S.phase === 'play' && S.t - S.lastEmit > 0.25) emit(); }

  drawTally(); drawLedger(); drawJars(); emit();
  const api = {
    camera,
    tick(dt) { if (!alive) return; dt = Math.min(0.25, dt || 0.016); update(dt * testK); placeCamera(dt); drawJars(); },
    start() { ensureAudio(); S.score = 0; S.history = []; beginShift(0); },
    stamp() { stamp(null); },
    next() { ensureAudio(); if (S.phase !== 'ledger') return; if (S.shift < SHIFTS.length - 1) beginShift(S.shift + 1); else finish(); },
    setSafe(s) { safe = { top: s.top || 0, bottom: s.bottom || 0, left: s.left || 0, right: s.right || 0 }; },
    testShort(n, k = 1) { testN = n | 0; testK = k; },   // tests only: n jars per shift, game clock × k
    debug() { return { phase: S.phase, shift: S.shift, count: S.count, truth: S.truth, score: S.score, queue: S.queue.length, jars: jars.map(j => { const r = el.getBoundingClientRect(); root.localToWorld(proj.set(j.x, j.y + JAR_H / 2, j.z)); proj.project(camera); return { id: j.id, type: j.type, state: j.state, x: +j.x.toFixed(2), zone: inZone(j), stamped: j.stamped, sx: Math.round(r.left + (proj.x + 1) / 2 * r.width), sy: Math.round(r.top + (1 - proj.y) / 2 * r.height) }; }) }; },
    destroy() { if (!alive) return; alive = false; el.removeEventListener('pointerdown', onDown); removeEventListener('keydown', onKey); root.removeFromParent();
      for (const x of disposables) { try { x.dispose(); } catch (e) {} } for (const m of Object.values(P)) { try { m.dispose(); } catch (e) {} }
      try { AC && AC.state !== 'closed' && AC.close(); } catch (e) {} AC = null; } };
  return api;
}
