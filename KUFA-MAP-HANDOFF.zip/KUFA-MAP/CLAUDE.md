# 8 GATES — WORLD LAYOUT CHAT (kit rules for Claude)

This project builds ONE world's CITY LAYOUT for Ben's game 8 GATES (fox characters, 11 worlds, a 3D rebuild of his 2D game). The main game lives in Ben's Meru project; your file is merged there later.

## TEST AVATAR: ONLY ONE, AS SIMPLE AS POSSIBLE (Ben)
Make no characters. The only walker is the simple test fox already in Layout Viewer.dc.html (WALK IT): about 10 boxes, loads instantly. Do not add fox-kit, cast, NPC models or animations; NPCs are just spots on the map. Avatars + story are added back in the main project.

## The Map Workshop (Ben moves things himself)
`Map Workshop.dc.html` is Ben's editor. It saves to localStorage `<world>.layoutDraft`. When Ben says he changed the map: read that key (in his preview, e.g. eval_js_user_view `localStorage.getItem('gaya.layoutDraft')`), write it into `layout/<world>.layout.json` with meta.version +1, then tell him to tap RELOAD FROM FILE. Never overwrite his draft without asking.

## EACH WORLD LOOKS LIKE ITSELF
Every layout has a "look" (sky, fog, light, grass, water) and a "terrain" (hills, cuts) block: PARALLEL_WORLDS.md section 8 + worlds/<world>.plan.md. Keep the town grid flat; hills and gorges go round it.

## EVERY WORLD HAS
PARALLEL_WORLDS.md section 7 = the buildings + places every world needs (castle, barracks, police, fire, news, tavern, item shop, armory, galactic post office, farm, restaurant, sport, specialty shop, special weapons, relic shop, bank, car rental, player home, hospital, 3+ houses, a cave, 4+ battle areas, wild areas with monsters / creatures / robots, a relic to find, a special vehicle). The workshop checklist + the checker show what is missing. Buildings on a GRID, easy to find; paths LARGE and easy.

## Your one job
Lay the world out with Ben in `Map Workshop.dc.html` and write `layout/<world>.layout.json` in the format of PARALLEL_WORLDS.md section 2 and keep `Layout Viewer.dc.html` passing (open it, pick the world, it re-checks every 3 s). Look at `kit/example.meru.layout.json` (Meru 2) for scale and density.

## TOP PRIORITIES (Ben)
1. MOBILE FIRST: check everything at 390x844 + 844x390 before desktop (IN_WORLD_GAMES.md "MOBILE FIRST").
2. REUSE OUR BUILT INTERIORS: for every game + job, bring in as much of its existing room from the repo as possible, fitted into its building, then make it PLAYABLE IN THAT ROOM (IN_WORLD_GAMES.md "REUSE THE INTERIORS").

## The phases (Ben, s345) — PARALLEL_WORLDS.md section 9
1. LAYOUT with Ben in the Map Workshop.
2. EXTERIORS first: every building's real outside, a BIG ROOF SIGN + a DOOR SIGN at the avatar's eye level, walk-in doors that work like Meru 2 (sliding doors, cutaway, camera held inside, X-ray fox; quick fade only for the castle keep, cave, tower lobbies, battle maps). Then STOP: Ben walks the town.
3. INTERIORS one building at a time with DELUXE polish, REUSING the room from that building's game / job in the repo wherever one exists (INTERIOR RULES in IN_WORLD_GAMES.md). Ben walks each.
4. JOBS + GAMES inside their places, in the order of `worlds/<world>.plan.md`, the Meru Claw Crane way (IN_WORLD_GAMES.md). Game code from GitHub BlindbenFILMS/3D-foxgate8 (copy ONLY that game's files).
5. Hand back (layout JSON + files + HANDOFF notes). AVATARS + STORY are added in the main project.

## Do NOT
- Build avatars (beyond the one test fox), story, quests, dialogue trees, enemies, battles, the real save or HUD. They stay in the main project.
- Edit anything in `kit/`, `vendor/`, `Layout Viewer.dc.html`, `Map Workshop.dc.html`. If the viewer or checker needs a change, write it down for Ben to take back.
- Rename or drop a bracketed room name from the 2D file.

## Source of truth
`uploads/surface_<world>.html` = the 2D world. Its `var SCENE = { … }` list holds every room name. Building positions, walk maps and NPC keys come from it. The design brief section (if attached) is for look and mood.

## Minigames (places only)
Every game for this world is listed in GitHub BlindbenFILMS/3D-foxgate8, file `3D-GAMES/GAMES_INDEX.md` (see PARALLEL_WORLDS.md section 6). Read it, give each of this world's games a `kind: game` spot or a building `games` entry. Never copy game code here.

## Rules (from Ben, decided)
- MOBILE FIRST: test WALK IT at PHONE 390×844 and 844×390 (button top-right in WALK IT).
- ONE connected outdoor map. The 2D path screens become ZONES on it; keep each zone's bracketed name.
- Lay it out from the 2D map data (walk maps, building positions).
- Paths always lined with lamps, lanterns or trees so the player sees where the path is.
- Off-path wild areas next to battle gates; creatures live there and never come onto the path.
- Every door: a clear 12 × 8 m apron and a short spur path to a main path. Open line from the door.
- A unique space dock pad (every world except Earth).
- Phone budget: about 40 building shells, 400 props, 150 lamps.
- The STORY: the robots of the Machine Fleet are hacked victims, never villains. Battle places are not "robot graveyards".
- Any UI: Modernist (Archivo, 2px rules, red accent #ec3013, flush-left, no rounded corners), menus dark ground #201e1d with light ink #f3f2f2.
- Naming + ids: PARALLEL_WORLDS.md section 3. Every key starts with the world id, except 2D NPC keys (`"from2d": true`).

## How to work
Passes: 1) zones + roads + paths, 2) buildings + doors, 3) spots + dock + gates + wild, 4) props + lining + polish. After each pass: viewer FAIL = 0, screenshot the map, tell Ben in short plain words (he has low vision: look at things for him). Ask one round of questions before pass 1.
Hand-back: `meta.version` +1, checker passes, then give Ben `layout/<world>.layout.json` to download.
Keep `LAYOUT_NOTES.md` updated each session: what is done, what Ben decided, what is next.


## EVERY WORLD (Ben, s348)
- Every building: a BIG ROOF SIGN + an EYE-LEVEL DOOR SIGN beside the door (big, high contrast), and its own UNIQUE outside ("outside" note in the layout).
- Every world: a ROYAL HELIPAD + ROYAL TELEPORT PAD at the CASTLE (telepad → that world's space dock) + at least ONE MORE HELIPAD on the map.
