# LUXOR — WORLD PLAN (the volcano, the ring and the zoo)
From WORLD_GAMES_PLAN.md (main project, s345). Repo = GitHub BlindbenFILMS/3D-foxgate8. Build each game IN THE WORLD with IN_WORLD_GAMES.md (the Meru Claw Crane recipe).

## PHASE 1 · LAYOUT (Map Workshop)
Every building below needs its place on the map (a building with "games": [page path], or a spot kind "game"). Plus the EVERY WORLD HAS list (PARALLEL_WORLDS.md section 7).

## PHASE 2 · EXTERIORS (then Ben walks it)
Every building: own shape + roof in this world's look, a BIG ROOF SIGN + a DOOR SIGN at eye level beside the door, walk-in doors like Meru 2 (PARALLEL_WORLDS.md section 9).

## PHASE 3 · INTERIORS, one by one, DELUXE (Ben walks each)
REUSE the room each game / job below already has in the repo (its shop, kitchen, hall, court, cabinet), fitted into its building, so phase 4 plays right there. MOBILE FIRST: 390x844 + 844x390 every time.

## PHASE 4 · JOBS + GAMES IN THE WORLD, in this order (one per pass, Ben tests each on the phone)
1. TAVERN GAME: Foosball — `3D-GAMES/g/tavern-games/FoosMain.dc.html`
2. RESTAURANT: Foxy Deli — `3D-GAMES/Luxor Deli.dc.html`
3. SPORT: Foxy Boxing — `3D-GAMES/Luxor Boxing.dc.html`
4. SPECIALTY SHOP: Hessa's Menagerie (the zoo) — `3D-GAMES/g/luxor-zoo/Main.dc.html`
5. Luxor Bike Shop — `3D-GAMES/g/luxor-bike-shop/Main.dc.html`
6. Moto School + Volcano Run — `3D-GAMES/Luxor Moto.dc.html`
7. Basketball — `3D-GAMES/g/basketball/Main.dc.html`
8. Dodgeball — `3D-GAMES/g/dodgeball/Dodgeball.dc.html`

## NOT BUILT YET (ideas for later, after the list above)
- Bike pit crew
- Basalt forge / blacksmith

## SPECIAL VEHICLES
- Motorcycle — `3D-GAMES/Vehicle Workshop.dc.html?v=moto` (models in engine/vehicle-kit.js + engine/vehicle-fun.js): a spot kind "vehicle" where you get it; ride it on the map's roads / open ground
- Robot Spider — `3D-GAMES/Vehicle Workshop.dc.html?v=spider` (models in engine/vehicle-kit.js + engine/vehicle-fun.js): a spot kind "vehicle" where you get it; ride it on the map's roads / open ground

## STAYS IN THE MAIN PROJECT
Avatars, story, quests, dialogue, the real save, enemies + battles. Use stand-ins (the test fox, box keepers) and mark lines DRAFT.
