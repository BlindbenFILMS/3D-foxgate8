// TREASURE DIG — open-air JOB at the layout spot kufaTreasureDig (the east dunes, x 330 z 140). kind 'direct' + panel, built NEW for the world:
// minigames/kufa/jobs/treasure-dig.js builds its roped dig patch in the spot group (local metres from the spot; the patch lies just SOUTH of it,
// z 0..17, so the world's spot label floats behind it). Its HUD is "Treasure Dig Play.dc.html". PLAY shows within 7 m of the spot or anywhere inside the rope.
export default { kind: 'direct', spot: true, panel: 'Treasure Dig Play', label: 'TREASURE DIG', sub: 'THE DUNES · HOT OR COLD', src: '../../minigames/kufa/jobs/treasure-dig.js',
  near: (R, lx, lz) => Math.hypot(lx, lz) < 7 || (Math.abs(lx) < 8.3 && lz > 0 && lz < 16.8),
  idle: 'buildTreasureDigSet',   // the host builds the static patch at world load (shows while walking, hidden while the game plays)
  create: (m, R, host) => m.createTreasureDig(host) };
