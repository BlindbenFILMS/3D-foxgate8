// THE CREAMERY soft-serve shift (Phase 4, game 2). kind 'stage': createStage runs in WORLD MODE; the HUD is the game's own page → "Creamery Play.dc.html".
export default { kind: 'stage', panel: 'Creamery Play', label: 'THE CREAMERY', sub: 'SOFT SERVE SHIFT · JAMIL IS HIRING', src: '../../minigames/kufa/creamery/creamery-shift.js',
  near: (R, lx, lz) => lz > -3.2 && lz < 4.8 && Math.abs(lx) < 5.6,
  create: (m, opts) => m.createCreameryShift(opts) };
