// BACKGAMMON in the Tavern parlour (Phase 4, game 1). kind 'direct': the game module has opts.world; its play UI is drawn by Kufa World.dc.html.
export default { kind: 'direct', label: 'BACKGAMMON', sub: 'THE PARLOUR · VS PIP, HOPE OR NOBLE', src: '../../minigames/kufa/backgammon/backgammon-club.js',
  near: (R, lx, lz) => R.parlorAt && Math.hypot(lx - R.parlorAt[0], lz - R.parlorAt[1]) < 3.4,
  async create(m, R, host) { return m.createBackgammonClub({ container: host.container, onState: host.onState, opts: { world: { renderer: host.renderer, parent: R.parlor.group, room: R.parlor, active: () => host.active() } } }); } };
