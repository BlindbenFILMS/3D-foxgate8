// kufaTallyBoard — WELL TALLY KEEPER, an open-air JOB at its layout spot (by the town square). kind 'direct' + panel "Tally Keeper Play".
// jobs/well-tally.js builds its own small set (well + pulley, plank rail, stamp gantry, tally board, Qasim's ledger) EAST of the world's
// NOW HIRING board (spot local x 2.4 … 14.2), inside the spot group. PLAY shows within ~6 m of the spot or anywhere on the set.
export default { kind: 'direct', spot: true, panel: 'Tally Keeper Play', label: 'WELL TALLY KEEPER', sub: 'THE TALLY BOARD · COUNT THE JARS', src: '../../minigames/kufa/jobs/well-tally.js',
  idle: 'buildWellTallySet',   // the set stands at the spot while you walk; the host hides it while the game (which builds its own) plays
  near: (R, lx, lz) => Math.hypot(lx, lz) < 6 || (lx > 2 && lx < 14.5 && lz > -3.5 && lz < 4.5),
  async create(m, R, host) { return m.createWellTally(host); } };
