// FOX FARM in the field behind the farmhouse (Phase 4). kind 'direct' + panel: farm.js has opts.world; its HUD is the panel "Fox Farm Play.dc.html".
// The playable farm goes into a Group at the field centre (building-local (0, -(D/2 + 22))); +z of that group = toward the house (the player side).
// The farmhouse stays (hideRoom: false). The game drives its own private camera (api.camera, world space); the host eases to it.
import * as THREE from '../../vendor/three/three.module.js';
import { save } from '../../minigames/kufa/engine/save.js';
// the farm's stats (best, level, xp, stars.*) live under 'farmField.' so they never collide with other games; gold is the shared purse
const farmSave = { stat: (k, d) => save.stat('farmField.' + k, d), setStat: (k, v) => save.setStat('farmField.' + k, v), addGold: n => save.addGold(n) };
const fieldZ = R => (R && R.field ? R.field[1] : -33);
export default { kind: 'direct', panel: 'Fox Farm Play', label: 'FOX FARM', sub: 'THE FIELD · PLANT, WATER, PICK', src: '../../minigames/kufa/farm/farm.js', hideRoom: false,
  // the field (40 x 28 m behind the house), down to the back wall of the house
  near: (R, lx, lz) => Math.abs(lx) < 20 && lz > fieldZ(R) - 16 && lz < fieldZ(R) + 16,
  async create(m, R, host) {
    const bd = host.bd, grp = new THREE.Group();
    grp.position.set(0, 0.03, -(bd.D / 2 + 22)); grp.name = 'foxFarmField'; bd.grp.add(grp);   // just above the field surface (y 0.02)
    // the layout's "FOX FARM PLOTS · GAME" floor label floats over the middle of the field: step it aside while the farm plays
    let root = bd.grp; while (root.parent) root = root.parent;
    grp.updateWorldMatrix(true, false); const c = new THREE.Vector3().setFromMatrixPosition(grp.matrixWorld), p = new THREE.Vector3(), hidden = [];
    root.traverse(o => { if (o.isSprite && o.visible && !grp.getObjectById(o.id)) { o.getWorldPosition(p); if (Math.hypot(p.x - c.x, p.z - c.z) < 16 && p.y < 8) { o.visible = false; hidden.push(o); } } });
    let api;
    try { api = await m.createFarm({ container: host.container, onState: host.onState, opts: { mode: 'cpu', world: { renderer: host.renderer, parent: grp }, save: farmSave } }); }
    catch (e) { grp.removeFromParent(); hidden.forEach(o => o.visible = true); throw e; }
    const destroy = api.destroy;
    api.destroy = () => { try { destroy(); } finally { grp.removeFromParent(); hidden.forEach(o => o.visible = true); } };
    return api;
  } };
