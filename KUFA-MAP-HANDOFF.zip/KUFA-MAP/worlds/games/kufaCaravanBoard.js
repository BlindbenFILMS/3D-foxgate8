// CARAVAN PACKER at Ghazi's caravan hiring board (open-air job, layout spot kufaCaravanBoard). kind 'direct' + panel "Caravan Packer Play".
// The game builds its own small set (rug of goods + kneeling camel) 3–11 m south of the board, inside the spot group.
export default { kind: 'direct', spot: true, panel: 'Caravan Packer Play', label: 'CARAVAN PACKER', sub: 'GHAZI\'S CARAVAN · LOAD THE CAMEL', src: '../../minigames/kufa/jobs/caravan-packer.js', idle: 'buildCaravanPackerSet',   /* the static set shows while walking; hidden while the game plays */
  near: (R, lx, lz) => Math.hypot(lx, lz - 1) < 6,
  async create(m, R, host) { return m.createCaravanPacker(host); } };
