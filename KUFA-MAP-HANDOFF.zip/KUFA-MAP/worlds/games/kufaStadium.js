// THE CISTERN CUP 3-a-side soccer (Phase 4). kind 'stage': createStage runs in WORLD MODE; the game builds its own pitch, boards, stands (N, E, W) and crowd at the bowl centre,
// its open side (+z) faces the bowl's south gate. HUD = the game's own page → "Cistern Cup Play.dc.html".
export default { kind: 'stage', panel: 'Cistern Cup Play', label: 'THE CISTERN CUP', sub: '3-A-SIDE · LESSONS WITH MASTER FARUQ', src: '../../minigames/kufa/soccer/soccer-cup.js',
  near: (R, lx, lz) => Math.abs(lx) < 30 && Math.abs(lz) < 18,   // not in the gate tunnel
  origin: [0, 0], rotY: 0,
  create: (m, opts) => m.createSoccer(opts) };
