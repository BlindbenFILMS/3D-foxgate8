// RAFIQ'S SPY SHOP (Phase 4). kind 'stage': createStage runs in WORLD MODE; the HUD is the game's own page → "Spy Shop Play.dc.html".
// The world builds the same room (buildSpyShop) at building-local (0, +2.2), so the game's scene group sits there too. The game's own walk mode → BACK to the world.
export default { kind: 'stage', panel: 'Spy Shop Play', label: "RAFIQ'S SPY SHOP", sub: 'QUIET TRADE · RAFIQ IS HIRING', src: '../../minigames/kufa/spyshop/spy-shop.js',
  origin: [0, 2.2],
  near: (R, lx, lz) => lz > -2 && lz < 6.3 && Math.abs(lx) < 5,
  create: (m, opts) => m.createSpyShop(opts) };
