// UMMI'S CAMEL PEN (Phase 4). kind 'stage': createStage runs in WORLD MODE; the HUD is the game's own page → "Camel Pen Play.dc.html".
// The world builds this yard turned a quarter (kufa-rooms.js FIT: rot PI/2, origin [0.95, 0]), so the game's own copy is placed the same way.
export default { kind: 'stage', panel: 'Camel Pen Play', label: "UMMI'S CAMEL PEN", sub: 'CAMEL CARE · UMMI REYHAN IS HIRING', src: '../../minigames/kufa/camel-pen/camel-pen.js',
  origin: [0.95, 0], rotY: Math.PI / 2,
  near: (R, lx, lz) => Math.abs(lx) < 7 && Math.abs(lz) < 9.5,
  create: (m, opts) => m.createCamelPen(opts) };
