// DOMINOES CLUB in the Bazaar club (Phase 4). kind 'direct' + panel: dominoes-club.js has opts.world (its own renderer/loop switched off);
// its HUD is the game's own page, reused as "Dominoes Play.dc.html". The game builds its own 7.2 x 7.2 parlour at the building centre
// (building-local origin) inside the club group; the host hides the world's copy while it runs.
export default { kind: 'direct', panel: 'Dominoes Play', label: 'DOMINOES', sub: 'THE CLUB · VS PIP, HOPE OR NOBLE', src: '../../minigames/kufa/dominoes/dominoes-club.js',
  near: (R, lx, lz) => Math.abs(lx) < 3.4 && Math.abs(lz) < 3.4,
  async create(m, R, host) { return m.createDominoesClub({ container: host.container, onState: host.onState, opts: { world: { renderer: host.renderer, parent: host.bd.grp, active: () => host.active() } } }); } };
