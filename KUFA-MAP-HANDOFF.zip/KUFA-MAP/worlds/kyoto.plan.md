# KYOTO — WORLD PLAN (the red-lacquer quarter of Gaya)
From WORLD_GAMES_PLAN.md (main project, s345). Repo = GitHub BlindbenFILMS/3D-foxgate8. Build each game IN THE WORLD with IN_WORLD_GAMES.md (the Meru Claw Crane recipe).

## PHASE 1 · LAYOUT (Map Workshop)
Every building below needs its place on the map (a building with "games": [page path], or a spot kind "game"). Plus the EVERY WORLD HAS list (PARALLEL_WORLDS.md section 7).

## PHASE 2 · EXTERIORS (then Ben walks it)
Every building: own shape + roof in this world's look, a BIG ROOF SIGN + a DOOR SIGN at eye level beside the door, walk-in doors like Meru 2 (PARALLEL_WORLDS.md section 9).

## PHASE 3 · INTERIORS, one by one, DELUXE (Ben walks each)
REUSE the room each game / job below already has in the repo (its shop, kitchen, hall, court, cabinet), fitted into its building, so phase 4 plays right there. MOBILE FIRST: 390x844 + 844x390 every time.

## PHASE 4 · JOBS + GAMES IN THE WORLD, in this order (one per pass, Ben tests each on the phone)
1. TAVERN GAME: Liar's Dice in the sake house — `3D-GAMES/g/liars-dice/liars-dice.dc.html`
2. RESTAURANT: Foxy Maki + Foxy Gyoza — `3D-GAMES/g/foxy-maki/Main.dc.html` · `3D-GAMES/g/foxy-gyoza/Foxy Gyoza.dc.html`
3. SPORT: Sumo Streak + Sword Duel — `3D-GAMES/Kyoto Sumo Hall.dc.html` · `3D-GAMES/Kyoto Sword Duel.dc.html`
4. SPECIALTY SHOP: Tea ceremony house — NOT BUILT YET
5. Archery on the Mountain Road — `3D-GAMES/g/8-gates-archery/Archery.dc.html`
6. Go Club — `3D-GAMES/g/go-club/go-club.dc.html`
7. Fox Gate Pachinko parlour — `3D-GAMES/g/fox-gate-pachinko/Main.dc.html`
8. Capsule Corner — `3D-GAMES/Capsule Corner.dc.html`
9. Kyoto Theatre (The Fox Wife) — `3D-GAMES/Kyoto Theatre.dc.html`

## NOT BUILT YET (ideas for later, after the list above)
- Tea ceremony
- Noh Stage

## SPECIAL VEHICLES
- Dragon Hatchling — `3D-GAMES/Vehicle Workshop.dc.html?v=dragon` (models in engine/vehicle-kit.js + engine/vehicle-fun.js): a spot kind "vehicle" where you get it; ride it on the map's roads / open ground

## STAYS IN THE MAIN PROJECT
Avatars, story, quests, dialogue, the real save, enemies + battles. Use stand-ins (the test fox, box keepers) and mark lines DRAFT.
