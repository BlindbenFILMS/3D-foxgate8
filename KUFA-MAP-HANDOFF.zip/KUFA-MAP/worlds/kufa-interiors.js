// 8 GATES · KUFA — PHASE 3 INTERIORS for the buildings that have NO game room in the repo and NO 2D room (new places: bank, post, watch,
// fire, news, infirmary, your home, the houses, special weapons, the relic shop, car rental, the ostrich stable).
// Each one is dressed from its layout note + the Kufa look (sandstone, brass, canvas, lanterns). Building-local metres, +z toward the door,
// the walkway from the door to the place of action stays clear. Keepers are coloured box-fox stand-ins (DRAFT names: roles only) until the merge.
// DRESS[key](T, ctx, bd) → { root, walk, cams, keepers }   (registered as rooms by worlds/kufa-rooms.js)
const kit = (T, ctx) => { const { M, toon } = ctx, g = new T.Group(); ctx.scene.add(g); const solids = [];
  const mt = m => typeof m === 'string' ? toon(m) : m;
  const B = (w, h, d, mat, x, y, z, solid = false, ry = 0) => { const o = M(new T.BoxGeometry(w, h, d), mt(mat), x, y + h / 2, z, g, 0.02); o.rotation.y = ry; if (solid) { const a = Math.abs(Math.cos(ry)), b = Math.abs(Math.sin(ry)), hw = (w * a + d * b) / 2, hd = (w * b + d * a) / 2; solids.push([x - hw, x + hw, z - hd, z + hd]); } return o; };
  const C = (r, h, mat, x, y, z, seg = 12, solid = false) => { const o = M(new T.CylinderGeometry(r, r, h, seg), mt(mat), x, y + h / 2, z, g, 0.02, r); if (solid) solids.push([x - r, x + r, z - r, z + r]); return o; };
  const S = (r, mat, x, y, z) => M(new T.SphereGeometry(r, 10, 8), mt(mat), x, y, z, g, 0.015, r);
  const glow = (w, h, d, col, x, y, z) => { const o = new T.Mesh(new T.BoxGeometry(w, h, d), new T.MeshBasicMaterial({ color: col })); o.position.set(x, y, z); g.add(o); return o; };
  const flat = (w, d, col, x, z, y = 0.1, ry = 0) => { const o = new T.Mesh(new T.PlaneGeometry(w, d), new T.MeshToonMaterial({ color: col })); o.rotation.x = -Math.PI / 2; o.rotation.z = ry; o.position.set(x, y, z); g.add(o); return o; };
  const plate = (lines, w, h, x, y, z, ry = 0) => { const c = document.createElement('canvas'); c.width = 512; c.height = Math.round(512 * h / w); const q = c.getContext('2d'); q.fillStyle = '#201e1d'; q.fillRect(0, 0, c.width, c.height); q.strokeStyle = '#e6b45a'; q.lineWidth = 10; q.strokeRect(5, 5, c.width - 10, c.height - 10); q.fillStyle = '#fbf3e0'; q.textBaseline = 'middle'; lines.forEach((l, i) => { q.font = `900 ${i ? 30 : 46}px Archivo, Arial`; q.fillText(l, 24, (i + 0.7) * c.height / (lines.length + 0.4)); }); const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; const o = new T.Mesh(new T.PlaneGeometry(w, h), new T.MeshBasicMaterial({ map: t })); o.position.set(x, y, z); o.rotation.y = ry; g.add(o); return o; };
  const lamp = (x, z, y) => { M(new T.CylinderGeometry(0.02, 0.02, 1.0, 4), mt('#201e1d'), x, y + 0.5, z, g, 0); glow(0.42, 0.5, 0.42, '#ffcf7a', x, y - 0.25, z); };
  const light = (bd, k = 1) => { const L = new T.PointLight(0xffe0a8, 1.3 * k, Math.max(bd.W, bd.D) * 1.4, 1.2); L.position.set(0, bd.ceil - 1.5, 0); g.add(L); };
  const rug = (w, d, a, b, x, z) => { flat(w + 0.4, d + 0.4, b, x, z, 0.095); flat(w, d, a, x, z, 0.1); };
  const walk = bd => (x, z) => (Math.abs(x) < bd.W / 2 - 0.75 && Math.abs(z) < bd.D / 2 - 0.75) || (z > 0 && Math.abs(x - bd.lx) < 2) ? !solids.some(s => x > s[0] - 0.3 && x < s[1] + 0.3 && z > s[2] - 0.3 && z < s[3] + 0.3) : false;
  return { g, B, C, S, glow, flat, plate, lamp, light, rug, solids, walk };
};
const done = (k, bd, keepers = []) => ({ root: k.g, walk: k.walk(bd), cams: null, keepers });
const lamps = (k, bd, n = 4) => { for (let i = 0; i < n; i++) { const a = (i + 0.5) / n; k.lamp(-bd.W / 2 + bd.W * a, (i % 2 ? -1 : 1) * bd.D / 5, bd.ceil); } k.light(bd); };
const wood = '#6b4a2c', woodL = '#9a7444', brass = '#e6b45a', ink = '#201e1d', cream = '#f2e6c8', red = '#c42d3c', teal = '#2f9a8f', stone = '#d8c39a', steel = '#9aa1a6';

export const DRESS = {
  // THE WATER BANK: teller counter behind brass bars, a round vault door, water jars on the tally wall
  kufaBank(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D, zc = -D / 2 + 7;
    k.rug(4, D / 2, '#1f4e8c', brass, 0, D / 4 - 1); k.B(W - 6, 1.15, 1.2, '#5a3a24', 0, 0, zc, true); k.B(W - 5.6, 0.12, 1.4, brass, 0, 1.15, zc);
    for (let x = -W / 2 + 3.6; x < W / 2 - 3; x += 0.5) k.B(0.06, 1.6, 0.06, brass, x, 1.27, zc);
    for (const x of [-W / 4, 0, W / 4]) { k.plate(['TELLER'], 1.8, 0.5, x, 3.2, zc + 0.05); }
    const vx = W / 2 - 4, vz = -D / 2 + 0.7; const vd = k.C(2.2, 0.5, steel, vx, 0.3, vz, 24); vd.rotation.x = Math.PI / 2; vd.position.y = 2.5; for (let i = 0; i < 6; i++) { const s = k.B(0.15, 1.8, 0.15, brass, vx, 1.6, vz + 0.35); s.rotation.z = i * Math.PI / 6; s.position.y = 2.5; }
    k.plate(['VAULT'], 2, 0.5, vx, 5.1, vz + 0.4);
    for (let i = 0; i < 7; i++) { const x = -W / 2 + 1.5 + i * 1.3; k.S(0.42, '#c2602d', x, 0.55, -D / 2 + 1.2); k.C(0.18, 0.3, '#c2602d', x, 0.9, -D / 2 + 1.2); }
    k.plate(['THE WATER BANK', 'WATER IS THE LAW · EVERY DROP COUNTED'], 6, 1.2, -W / 4, 4.6, -D / 2 + 0.45);
    for (const s of [-1, 1]) { k.B(2.4, 0.5, 0.8, woodL, s * (W / 2 - 2), 0, D / 4, true); }
    lamps(k, bd); return done(k, bd, [{ name: 'TELLER (DRAFT)', at: [-W / 4, zc - 1.2], face: 0, col: '#3a6ea5' }]); },
  // GALACTIC POST OFFICE · MERU EMBASSY: parcel counter, a wall of pigeonholes, a galactic map, mail sacks, the Meru flag
  kufaPost(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D, zc = -D / 2 + 6;
    k.rug(3.6, D / 2, red, brass, 0, D / 4 - 1); k.B(W - 8, 1.1, 1.2, woodL, 0, 0, zc, true); k.B(W - 7.6, 0.12, 1.4, '#7a4a2c', 0, 1.1, zc);
    for (let r = 0; r < 5; r++) for (let c = 0; c < 10; c++) { k.B(0.9, 0.6, 0.5, wood, -4.5 + c * 1.0, 0.6 + r * 0.66, -D / 2 + 0.6); if ((r * 3 + c) % 4) k.B(0.6, 0.12, 0.3, cream, -4.5 + c * 1.0, 0.75 + r * 0.66, -D / 2 + 0.75); }
    const map = k.glow(5, 2.6, 0.1, '#1b2350', W / 2 - 3.5, 3.4, -D / 2 + 0.5); for (let i = 0; i < 9; i++) k.glow(0.16, 0.16, 0.05, ['#ffd23a', '#7fe3ff', '#ec3013'][i % 3], W / 2 - 5.5 + (i * 0.47) % 4, 2.4 + (i * 0.73) % 2, -D / 2 + 0.58); k.plate(['THE NINE SYSTEMS'], 3, 0.5, W / 2 - 3.5, 5.0, -D / 2 + 0.56);
    for (let i = 0; i < 5; i++) k.S(0.55, i % 2 ? '#c9a46a' : '#a8864a', -W / 2 + 1.8 + (i % 3) * 1.1, 0.5, D / 2 - 3 - Math.floor(i / 3) * 1.1);
    k.C(0.06, 5, ink, -W / 2 + 1, 0, -D / 2 + 1); k.B(0.05, 1.2, 1.8, '#7a5ab8', -W / 2 + 1, 4, -D / 2 + 1.95);
    k.plate(['GALACTIC POST', 'PARCELS · LETTERS · THE MERU EMBASSY'], 6, 1.2, -W / 5, 4.8, -D / 2 + 1.0);
    lamps(k, bd); return done(k, bd, [{ name: 'POSTMASTER (DRAFT)', at: [0, zc - 1.2], face: 0, col: '#7a5ab8' }]); },
  // WATCH HOUSE (police): duty desk, a barred cell, wanted board, lockers, the blue lamp
  kufaWatchHouse(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D;
    k.rug(3.2, D / 2, '#1f3a5f', brass, 0, D / 4 - 1); k.B(5, 1.1, 1.4, wood, -2, 0, -2, true); k.B(5.2, 0.1, 1.6, '#3a6ea5', -2, 1.1, -2);
    const cx = W / 2 - 4.5, cz = -D / 2 + 4; k.flat(7, 6, '#9a8a7a', cx, cz, 0.1); for (let i = 0; i <= 14; i++) k.B(0.08, 3.2, 0.08, steel, cx - 3.5 + i * 0.5, 0, cz + 3, i % 7 !== 3 || i < 7); k.B(7.1, 0.12, 0.12, steel, cx, 3.2, cz + 3); k.B(2, 0.5, 0.9, '#6b6050', cx + 1.5, 0, cz - 1.5, true);
    k.solids.push([cx - 3.6, cx - 0.2, cz + 2.9, cz + 3.1], [cx + 0.6, cx + 3.6, cz + 2.9, cz + 3.1]);
    k.B(3.6, 2.4, 0.1, cream, -W / 2 + 3, 1.4, -D / 2 + 0.5); for (let i = 0; i < 6; i++) k.B(0.9, 1.0, 0.04, '#e8dcc0', -W / 2 + 1.7 + (i % 3) * 1.25, 1.6 + Math.floor(i / 3) * 1.15, -D / 2 + 0.56); k.plate(['WANTED'], 2, 0.45, -W / 2 + 3, 4.1, -D / 2 + 0.58);
    for (let i = 0; i < 6; i++) k.B(0.75, 2.2, 0.6, i % 2 ? '#5a6a7a' : '#4a5a6a', -W / 2 + 0.7, 0, -2 + i * 0.8, true);
    k.glow(0.6, 0.4, 0.3, '#3a8aff', -2, 2.1, -2); k.plate(['THE WATCH', 'MASTER FARUQ\'S WATCH · KUFA'], 5, 1.0, 2, 4.6, -D / 2 + 0.45);
    lamps(k, bd); return done(k, bd, [{ name: 'WATCH OFFICER (DRAFT)', at: [-2, -3.4], face: 0, col: '#3a6ea5' }]); },
  // SAND & FIRE BRIGADE: the sand-rescue buggy in the bay, hose reels, sand buckets, the brass pole, helmets
  kufaFireStation(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D, bx = bd.lx > 0 ? -W / 4 : W / 4;
    k.flat(8, D - 4, '#8a8278', bx, -1, 0.1); for (let i = 0; i < 6; i++) k.flat(0.3, 2, '#ffd23a', bx - 3.6 + (i % 2) * 7.2, -D / 2 + 3 + Math.floor(i / 2) * 5, 0.11);
    k.B(3, 1.2, 5, red, bx, 0.6, -1, true); k.B(2.6, 1.0, 2.2, '#333', bx, 1.8, -0.2); for (const [a, b] of [[-1.5, -2], [1.5, -2], [-1.5, 1.4], [1.5, 1.4]]) { const w = k.C(0.65, 0.5, ink, bx + a, 0.65, -1 + b, 12); w.rotation.z = Math.PI / 2; w.position.y = 0.65; } k.glow(1.2, 0.25, 0.5, '#3a8aff', bx, 2.95, -0.2);
    for (let i = 0; i < 3; i++) { const r = k.C(0.7, 0.4, red, -bx * 0.9, 2.2, -D / 2 + 2 + i * 3, 16); r.rotation.x = Math.PI / 2; r.position.y = 2.2; }
    for (let i = 0; i < 8; i++) { k.C(0.25, 0.45, red, W / 2 - 1.2, 0, -D / 2 + 1.5 + i * 0.7); k.C(0.22, 0.05, '#e2c995', W / 2 - 1.2, 0.45, -D / 2 + 1.5 + i * 0.7); }
    k.C(0.06, bd.ceil, brass, -bx * 0.5, 0, D / 4); for (let i = 0; i < 5; i++) k.S(0.28, ['#ffd23a', red][i % 2], -W / 2 + 1.5 + i * 0.8, 2.0, -D / 2 + 0.6);
    k.plate(['SAND & FIRE BRIGADE', 'DUNE RESCUE · STANDPIPE FIRES'], 6, 1.2, -bx * 0.5, 4.6, -D / 2 + 0.45);
    lamps(k, bd); return done(k, bd, [{ name: 'FIRE CHIEF (DRAFT)', at: [bx + 2.6, 2.5], face: 0, col: '#c42d3c' }]); },
  // THE KUFA CRIER (news): presenter desk + microphone, a printing press, stacks of papers, the ticker screen
  kufaCrier(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D;
    k.flat(8, 6, '#1f3a5f', 0, -D / 2 + 4.5); k.B(5, 1.0, 1.4, ink, 0, 0, -D / 2 + 4, true); k.B(5.2, 0.08, 1.6, brass, 0, 1.0, -D / 2 + 4); k.C(0.05, 0.6, steel, 0.6, 1.08, -D / 2 + 4.2); k.S(0.12, ink, 0.6, 1.75, -D / 2 + 4.2);
    k.glow(7, 2.2, 0.1, '#ffd23a', 0, 3.6, -D / 2 + 0.5); k.plate(['THE KUFA CRIER', 'NINE WELLS ON THE WEST ROAD · THE COUNT DOES NOT ADD UP'], 6.6, 1.6, 0, 3.6, -D / 2 + 0.58);
    const px = -W / 2 + 4; k.B(3.2, 1.4, 2.2, '#3a3a40', px, 0, 3, true); const roll = k.C(0.5, 2.4, steel, px, 1.6, 3, 16); roll.rotation.z = Math.PI / 2; roll.position.y = 1.9;
    for (let i = 0; i < 6; i++) k.B(0.8, 0.3 + (i % 3) * 0.25, 0.6, cream, W / 2 - 2 - (i % 3) * 1.0, 0, 2 + Math.floor(i / 3) * 1.0, true);
    for (const x of [-4.5, 4.5]) { k.B(1.6, 0.8, 1.0, woodL, x, 0, 0, true); k.C(0.2, 0.5, ink, x, 0.8, 0.2); }
    lamps(k, bd); return done(k, bd, [{ name: 'THE CRIER (DRAFT)', at: [0, -D / 2 + 2.8], face: 0, col: '#ffd23a' }]); },
  // OASIS INFIRMARY: reception, beds with curtains, a medicine wall, the courtyard palm in a big pot
  kufaHospital(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D;
    k.rug(3.4, D / 2.2, '#cfe6f5', '#3a6ea5', 0, D / 4 - 1); k.B(5, 1.1, 1.2, '#eef4f8', -W / 4, 0, 2, true); k.B(5.2, 0.1, 1.4, '#3a6ea5', -W / 4, 1.1, 2); k.plate(['RECEPTION'], 2.4, 0.5, -W / 4, 2.8, 1.4);
    for (let i = 0; i < 5; i++) { const x = -W / 2 + 3 + i * (W - 6) / 4, z = -D / 2 + 3; k.B(1.6, 0.6, 2.6, '#e8eef2', x, 0, z, true); k.B(1.5, 0.15, 2.4, '#f8fbfc', x, 0.6, z); k.B(1.1, 0.2, 0.6, '#ffffff', x, 0.75, z - 0.85); k.B(0.05, 2.6, 2.8, i % 2 ? '#bfe0f0' : '#d8ecf6', x + 1.1, 0, z); }
    for (let r = 0; r < 4; r++) for (let c = 0; c < 6; c++) k.B(0.32, 0.4, 0.3, ['#ffffff', '#c42d3c', '#3a6ea5', '#2f9a8f'][(r + c) % 4], W / 2 - 0.7, 0.9 + r * 0.6, -3 + c * 0.6);
    k.C(0.9, 0.9, '#c2602d', W / 4, 0, 3, 14, true); for (let i = 0; i < 6; i++) k.S(0.55, '#4f7a2e', W / 4 + Math.cos(i) * 0.6, 2.4 + (i % 2) * 0.4, 3 + Math.sin(i) * 0.6); k.C(0.15, 2.2, '#8a6a44', W / 4, 0.9, 3);
    k.plate(['OASIS INFIRMARY', 'BEDS · MEDICINE · MEDEVAC PAD OUTSIDE'], 6, 1.2, 0, 5.4, -D / 2 + 0.45);
    lamps(k, bd, 5); return done(k, bd, [{ name: 'DOCTOR (DRAFT)', at: [-W / 4, 0.9], face: 0, col: '#f4f1ec' }]); },
  // COURTYARD HOUSE (your home): a fountain courtyard in the middle, cushions + low table, the bed alcove, a storage chest, plants
  kufaHome(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D;
    k.flat(8, 7, '#e2c995', 0, -1); k.C(1.3, 0.6, stone, 0, 0, -1, 18, true); k.C(1.05, 0.05, '#3aa7a0', 0, 0.6, -1, 18); k.C(0.12, 1.2, brass, 0, 0.6, -1); for (let i = 0; i < 4; i++) { k.B(0.8, 0.8, 0.8, '#c2602d', (i % 2 ? 1 : -1) * 3.4, 0, -1 + (i < 2 ? -2.6 : 2.6)); k.S(0.6, '#4f7a2e', (i % 2 ? 1 : -1) * 3.4, 1.3, -1 + (i < 2 ? -2.6 : 2.6)); }
    const lx = -W / 2 + 4; k.rug(4, 3, red, brass, lx, 3); k.B(1.6, 0.4, 1.0, wood, lx, 0, 3, true); for (let i = 0; i < 4; i++) k.B(0.9, 0.3, 0.9, [teal, red, brass, cream][i], lx + Math.cos(i * 1.57) * 1.6, 0, 3 + Math.sin(i * 1.57) * 1.2);
    const bx = W / 2 - 3.5, bz = -D / 2 + 3; k.B(3, 0.6, 2.2, wood, bx, 0, bz, true); k.B(2.8, 0.25, 2.0, cream, bx, 0.6, bz); k.B(2.8, 0.2, 0.6, teal, bx, 0.85, bz - 0.6); k.B(0.12, 3.2, 2.4, woodL, bx - 1.6, 0, bz);
    k.B(1.6, 0.9, 0.9, '#7a4a2c', -W / 2 + 1.5, 0, -D / 2 + 1.5, true); k.B(1.65, 0.1, 0.95, brass, -W / 2 + 1.5, 0.9, -D / 2 + 1.5);
    k.plate(['YOUR HOME', 'REST · STORE · CHANGE OUTFIT'], 4.6, 1.0, 0, 4.0, -D / 2 + 0.45);
    lamps(k, bd); return done(k, bd); },
  // BRASS & BLADE (special weapons: the 8 extra ranged + melee): racks on both walls, a glass counter, a target range at the back
  kufaWeapons(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D, zc = -D / 2 + 9;
    k.rug(3, D / 2, '#3a2a1a', brass, 0, D / 4 - 1); k.B(W - 8, 1.1, 1.2, '#2a2a2e', 0, 0, zc, true); k.glow(W - 8.4, 0.05, 1.0, '#7fe3ff', 0, 1.12, zc);
    const names = ['SAND BOW', 'DUNE SLING', 'BRASS PISTOL', 'SHOCK SPEAR', 'SCIMITAR', 'TWIN DAGGERS', 'WAR FAN', 'STORM CHAKRAM'];
    names.forEach((n, i) => { const s = i < 4 ? -1 : 1, z = -D / 2 + 2.5 + (i % 4) * 3.2, x = s * (W / 2 - 0.8); k.B(0.3, 2.6, 2.4, wood, x, 0.4, z, true); k.B(0.12, 2.0, 0.12, i % 2 ? brass : steel, x - s * 0.25, 0.7, z, false); k.plate([n], 2.2, 0.45, x - s * 0.3, 3.4, z, s > 0 ? -Math.PI / 2 : Math.PI / 2); });
    for (let i = 0; i < 3; i++) { const t = k.C(0.8 - i * 0.25, 0.1, [red, cream, red][i], 0, 2, -D / 2 + 0.5, 20); t.rotation.x = Math.PI / 2; t.position.set(0, 2.2, -D / 2 + 0.5 + i * 0.02); }
    k.plate(['BRASS & BLADE', 'THE EIGHT SPECIAL WEAPONS'], 5, 1.0, 0, 4.4, zc - 0.7);
    lamps(k, bd); return done(k, bd, [{ name: 'BLADESMITH (DRAFT)', at: [3, zc - 1.2], face: 0, col: '#8a6a3a' }]); },
  // THE BRASS ASTROLABE (the famous relic to BUY): glass cases, THE ASTROLABE on its pedestal under a star ceiling
  kufaRelicShop(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D;
    k.rug(4, D - 6, '#1b2350', brass, 0, 0); const pz = -D / 2 + 6; k.C(1.0, 1.2, stone, 0, 0, pz, 16, true); const ring = k.C(1.2, 0.08, brass, 0, 2.6, pz, 32); ring.rotation.x = Math.PI / 2; ring.position.y = 2.6; const r2 = k.C(0.9, 0.08, brass, 0, 2.6, pz, 32); r2.rotation.z = Math.PI / 2; r2.position.y = 2.6; k.S(0.25, '#ffd23a', 0, 2.6, pz); k.glow(0.1, 0.1, 0.1, '#ffffff', 0, 3.9, pz);
    k.plate(['THE BRASS ASTROLABE', 'THE FAMOUS RELIC OF KUFA · ASK THE PRICE'], 6, 1.2, 0, 4.6, -D / 2 + 0.45);
    for (const s of [-1, 1]) for (let i = 0; i < 3; i++) { const x = s * (W / 2 - 2.5), z = -D / 2 + 4 + i * 5; k.B(1.6, 1.0, 1.2, '#3a2a1a', x, 0, z, true); const gl = k.B(1.5, 0.8, 1.1, new T.MeshToonMaterial({ color: '#bfe6ea', transparent: true, opacity: 0.35 }), x, 1.0, z); k.S(0.2, [brass, '#7fe3ff', red][i], x, 1.3, z); }
    for (let i = 0; i < 40; i++) k.glow(0.08, 0.08, 0.08, '#ffe7a3', ((i * 7.3) % W) - W / 2, bd.ceil - 0.15, ((i * 4.1) % D) - D / 2);
    lamps(k, bd, 2); return done(k, bd, [{ name: 'RELIC DEALER (DRAFT)', at: [2.6, pz + 1.2], face: 0, col: '#b8893a' }]); },
  // DUNE RIDES (car rental): a buggy on the floor with its hood up, tool wall, tyres, the rental counter
  kufaWagonHire(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D;
    k.flat(10, D - 4, '#7a7570', 0, -1, 0.1); k.B(2.8, 1.0, 4.6, '#e8c35a', -3, 0.6, -2, true); k.B(2.4, 0.9, 1.8, ink, -3, 1.6, -2.6); for (const [a, b] of [[-1.4, -1.6], [1.4, -1.6], [-1.4, 1.6], [1.4, 1.6]]) { const w = k.C(0.6, 0.5, ink, -3 + a, 0.6, -2 + b, 12); w.rotation.z = Math.PI / 2; w.position.y = 0.6; }
    k.B(W - 4, 2.8, 0.15, '#5a4a3a', 0, 0.8, -D / 2 + 0.6); for (let i = 0; i < 12; i++) k.B(0.1, 0.8, 0.06, steel, -W / 2 + 3 + i * 1.6, 2.0, -D / 2 + 0.75);
    for (let i = 0; i < 4; i++) k.C(0.6, 0.35, ink, W / 2 - 2, 0.35 * i, -D / 2 + 3, 12);
    k.B(4, 1.1, 1.2, woodL, W / 4, 0, 3, true); k.plate(['DUNE RIDES', 'BUGGIES · CAMEL CART · BY THE DAY'], 5, 1.0, W / 4, 3.6, 2.4);
    lamps(k, bd); return done(k, bd, [{ name: 'RENTALS (DRAFT)', at: [W / 4, 1.8], face: 0, col: '#e8c35a' }]); },
  // OSTRICH STABLE: stalls with hay and box ostriches, a water trough, saddles on the wall
  kufaOstrichStable(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D;
    k.flat(W - 2, D - 2, '#cfae74', 0, 0, 0.1); for (let i = 0; i < 5; i++) { const x = -W / 2 + 3.5 + i * (W - 7) / 4, z = -D / 2 + 3.5; k.B(0.15, 1.4, 4, wood, x - 2.6, 0, z, true); k.flat(4, 3.5, '#e0c35e', x, z, 0.12);
      const o = new T.Group(); o.position.set(x, 0, z); k.g.add(o); const body = ctx.M(new T.SphereGeometry(0.75, 10, 8), ctx.toon(ink), 0, 1.6, 0, o, 0.02, 0.75); body.scale.set(1, 0.8, 1.3); ctx.M(new T.CylinderGeometry(0.1, 0.12, 1.2, 6), ctx.toon('#f0c8b8'), 0, 2.4, 0.6, o, 0.01, 0.1); ctx.M(new T.SphereGeometry(0.22, 8, 6), ctx.toon('#f0c8b8'), 0, 3.05, 0.7, o, 0.01, 0.22); for (const s of [-0.25, 0.25]) ctx.M(new T.CylinderGeometry(0.06, 0.06, 1.1, 6), ctx.toon('#f0c8b8'), s, 0.55, 0, o, 0.01, 0.06); ctx.M(new T.SphereGeometry(0.5, 8, 6), ctx.toon(cream), 0, 1.8, -0.8, o, 0.01, 0.5); }
    k.B(W - 8, 0.6, 0.9, stone, 0, 0, 2, true); k.flat(W - 8.4, 0.6, '#3aa7a0', 0, 2, 0.62);
    for (let i = 0; i < 4; i++) k.B(1.0, 0.5, 0.4, '#7a3a1a', -W / 2 + 2 + i * 1.6, 2.2, D / 2 - 0.6);
    k.plate(['OSTRICH STABLE', 'RENT A RIDE · OUT ON THE DUNES'], 5, 1.0, 0, 4.0, -D / 2 + 0.45);
    lamps(k, bd); return done(k, bd, [{ name: 'STABLE HAND (DRAFT)', at: [3, 4], face: 0, col: '#b08a5a' }]); },
};
// the 4 houses: same kit, each its own colours (from their door colours)
const house = col => function (T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D;
  k.rug(3.2, 2.4, col, cream, 0, 0); k.B(1.4, 0.45, 1.0, wood, 0, 0, 0, true); k.B(2.6, 0.5, 1.9, wood, W / 2 - 2, 0, -D / 2 + 2, true); k.B(2.4, 0.2, 1.8, cream, W / 2 - 2, 0.5, -D / 2 + 2); k.B(2.4, 0.2, 0.5, col, W / 2 - 2, 0.7, -D / 2 + 1.4);
  k.B(2.2, 2.2, 0.5, woodL, -W / 2 + 1.6, 0, -D / 2 + 0.6, true); for (let i = 0; i < 6; i++) k.C(0.15, 0.3, ['#c2602d', brass, teal][i % 3], -W / 2 + 0.9 + (i % 3) * 0.6, 0.6 + Math.floor(i / 3) * 0.8, -D / 2 + 0.6);
  for (let i = 0; i < 3; i++) k.B(0.8, 0.3, 0.8, [col, cream, brass][i], -1.7 + i * 1.7, 0, 1.6);
  lamps(k, bd, 2); return done(k, bd); };
DRESS.kufaHouse1 = house('#2f6d9a'); DRESS.kufaHouse2 = house('#3f8a4a'); DRESS.kufaHouse3 = house(red); DRESS.kufaHouse4 = house('#e8c35a');
