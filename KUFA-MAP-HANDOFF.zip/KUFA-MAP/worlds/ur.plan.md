# UR — WORLD PLAN (the old college and the pyramids)
From WORLD_GAMES_PLAN.md (main project, s345). Repo = GitHub BlindbenFILMS/3D-foxgate8. Build each game IN THE WORLD with IN_WORLD_GAMES.md (the Meru Claw Crane recipe).

## PHASE 1 · LAYOUT (Map Workshop)
Every building below needs its place on the map (a building with "games": [page path], or a spot kind "game"). Plus the EVERY WORLD HAS list (PARALLEL_WORLDS.md section 7).

## PHASE 2 · EXTERIORS (then Ben walks it)
Every building: own shape + roof in this world's look, a BIG ROOF SIGN + a DOOR SIGN at eye level beside the door, walk-in doors like Meru 2 (PARALLEL_WORLDS.md section 9).

## PHASE 3 · INTERIORS, one by one, DELUXE (Ben walks each)
REUSE the room each game / job below already has in the repo (its shop, kitchen, hall, court, cabinet), fitted into its building, so phase 4 plays right there. MOBILE FIRST: 390x844 + 844x390 every time.

## PHASE 4 · JOBS + GAMES IN THE WORLD, in this order (one per pass, Ben tests each on the phone)
1. TAVERN GAME: Cribbage in the college pub — `3D-GAMES/g/cribbage/cribbage.dc.html`
2. RESTAURANT: Ur Espresso + Ur Grounds — `3D-GAMES/g/ur-espresso/Main.dc.html` · `3D-GAMES/g/ur-grounds/Main.dc.html`
3. SPORT: Track and Field + Cricket Nets — `3D-GAMES/g/track-and-field/TrackField.dc.html` · `3D-GAMES/Cricket Nets.dc.html`
4. SPECIALTY SHOP: Ur Laboratory — `3D-GAMES/g/ur-lab/Main.dc.html`
5. Ur Pyramid Dig — `3D-GAMES/g/ur-dig/Main.dc.html`
6. Electrician Job — `3D-GAMES/g/electrician-job/ElectricianJob.dc.html`

## NOT BUILT YET (ideas for later, after the list above)
- Tablet scribe
- Brick kiln
- College archivist
- Glyph Lock

## SPECIAL VEHICLES
- Hoverboard — `3D-GAMES/Vehicle Workshop.dc.html?v=hover` (models in engine/vehicle-kit.js + engine/vehicle-fun.js): a spot kind "vehicle" where you get it; ride it on the map's roads / open ground
- Wrecking Crane — `3D-GAMES/Vehicle Workshop.dc.html?v=crane` (models in engine/vehicle-kit.js + engine/vehicle-fun.js): a spot kind "vehicle" where you get it; ride it on the map's roads / open ground

## STAYS IN THE MAIN PROJECT
Avatars, story, quests, dialogue, the real save, enemies + battles. Use stand-ins (the test fox, box keepers) and mark lines DRAFT.
