// 8 GATES · KUFA — SPECIAL VEHICLES you ride on the map (plan: "ride it on the map's roads / open ground").
// OSTRICH (spot kufaOstrich, by the Ostrich Stable) and KANGAROO BOOTS (spot kufaKroo, booth on the Stadium Path).
// The models are the Vehicle Workshop's own (engine/vehicle-fun.js funKit → make('ostrich') / make('kroo'), copied unchanged
// into minigames/kufa/engine/). The riding here is a SIMPLE map version: no load screen, the world keeps running.
//   RIDE (E) at the spot → stick / WASD steers (faster than walking, Shift = sprint) · JUMP (Space): the ostrich flaps to glide,
//   the boots chain bounds (each bound in a row goes higher, up to 5) · GET OFF (E) anywhere outside. Rides do not go indoors.
//   Walk 120 m away from a ride you left and it goes home to its spot.
// The full Workshop behaviour (PECK, DUST KICK, STOMP, DROP-KICK…) needs the main project's controller + cast: at the merge use
// the Workshop's funKit update/press/pose with the real fox.
// createRides(THREE, { world, L, scene }) → { near(pos), mount(key), dismount(pos), riding, spec, jump(), update(dt, pose), list }
import { funKit } from '../minigames/kufa/engine/vehicle-fun.js';

export function createRides(THREE, { world, L, scene }) {
  const grad = new THREE.DataTexture(new Uint8Array([90, 90, 90, 255, 165, 165, 165, 255, 230, 230, 230, 255, 255, 255, 255, 255]), 4, 1, THREE.RGBAFormat); grad.minFilter = grad.magFilter = THREE.NearestFilter; grad.needsUpdate = true;
  const mats = {}, toon = c => mats[c] || (mats[c] = new THREE.MeshToonMaterial({ color: c, gradientMap: grad }));
  const M = (geo, mat, x, y, z, parent) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; if (parent) parent.add(m); return m; };
  const glowTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d'), r = g.createRadialGradient(32, 32, 0, 32, 32, 32); r.addColorStop(0, 'rgba(255,255,255,1)'); r.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = r; g.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
  const FK = funKit({ THREE, M, toon, grad, glowTex, scene });
  // the test fox is 2.6 m to the ear tips, so the rides are scaled up to fit it (seat = where the fox's hips go, feet = where it stands)
  const DEF = {
    kufaOstrich: { kind: 'ostrich', label: 'OSTRICH', scale: 1.7, max: 16, seatY: 2.55 - 0.9, legs: 'astride' },
    kufaKroo: { kind: 'kroo', label: 'KANGAROO BOOTS', scale: 1.6, max: 11, seatY: 0.62 * 1.6, legs: 'stand' },
  };
  const list = [];
  for (const s of L.spots || []) { const d = DEF[s.key]; if (!d || !s.at) continue;
    let at = [s.at[0], s.at[1]]; const inR = world.roomAt(at[0], at[1], 0.2);   // a spot inside a walled building (the Ostrich Stable) → the ride waits outside its door
    if (inR && !inR.open) { const dr = world.doors.find(q => q.bd === inR.bd); if (dr) { const ox = dr.out[0] - dr.at[0], oz = dr.out[1] - dr.at[1], n = Math.hypot(ox, oz) || 1; const ux = ox / n, uz = oz / n, clear = (x, z) => !world.roomAt(x, z, 1) && !world.solids.some(f => x > f[0] - 3 && x < f[1] + 3 && z > f[2] - 3 && z < f[3] + 3);
        at = [dr.out[0] + ux * 5, dr.out[1] + uz * 5]; search: for (const k of [5, 7, 9, 11, 14]) for (const l of [3.5, -3.5, 0, 6, -6]) { const x = dr.out[0] + ux * k + uz * l, z = dr.out[1] + uz * k - ux * l; if (clear(x, z)) { at = [x, z]; break search; } } } }   // first clear patch in front of the door, beside the apron
    const g = FK.make(d.kind); g.scale.setScalar(d.scale); scene.add(g); const V = g.userData.V;
    const r = { key: s.key, ...d, g, V, home: at, x: at[0], z: at[1], yaw: 0, y: 0, vy: 0, air: false, ph: 0, chain: 0, sp: 0, glide: false };
    r.y = world.groundY(r.x, r.z); place(r); list.push(r); }
  function place(r) { r.g.position.set(r.x, r.y + 0.12, r.z); r.g.rotation.y = r.yaw; }
  let cur = null;
  const self = {
    list, get riding() { return cur && cur.key; }, get spec() { return cur; },
    near(p) { if (cur) return null; for (const r of list) if (Math.hypot(p.x - r.x, p.z - r.z) < 3.6) return { key: r.key, label: r.label }; return null; },
    mount(key) { const r = list.find(q => q.key === key); if (!r) return null; cur = r; r.chain = 0; r.vy = 0; r.air = false; return { pos: [r.x, r.z], face: r.yaw }; },
    dismount(pose) { if (!cur) return null; const r = cur; cur = null; r.air = false; r.y = world.groundY(r.x, r.z); place(r); const sx = Math.cos(r.yaw), sz = -Math.sin(r.yaw); return [r.x + sx * 2.4, r.z + sz * 2.4]; },   // step off to the right side
    jump() { const r = cur; if (!r) return; if (r.kind === 'ostrich') { if (!r.air) { r.vy = 9; r.air = true; } r.glide = true; }   // keep holding = FLAP-GLIDE on the way down
      else if (!r.air) { r.vy = 6 + Math.min(5, r.chain) * 1.6 + 3; r.air = true; } },
    jumpUp() { if (cur) cur.glide = false; },
    // pose = { x, z, face, speed, gy } from the walk step while riding; returns the fox offset { y, tilt }
    update(dt, pose) { const t = performance.now() / 1000;
      for (const r of list) { if (r === cur) continue; // idle: the ostrich pecks about, the boots stand; far from you → home
        if (pose && Math.hypot(pose.x - r.x, pose.z - r.z) > 120 && Math.hypot(r.x - r.home[0], r.z - r.home[1]) > 1) { r.x = r.home[0]; r.z = r.home[1]; r.yaw = 0; r.y = world.groundY(r.x, r.z); place(r); }
        if (r.kind === 'ostrich' && r.V.neck) r.V.neck.rotation.x = Math.max(0, Math.sin(t * 0.9 + r.x)) * 0.5; }
      if (!cur || !pose) return null; const r = cur, V = r.V; r.x = pose.x; r.z = pose.z; r.yaw = pose.face; const gy = pose.gy, mv = pose.speed > 0.3;
      if (r.kind === 'kroo' && mv && !r.air) { r.vy = 4.2 + Math.min(5, r.chain) * 0.9; r.air = true; r.chain = Math.min(5, r.chain + 1); }   // hold the stick = bound; each bound in a row goes higher
      if (!mv && !r.air) r.chain = 0;
      if (r.air) { r.vy -= (r.glide && r.vy < 0 ? 6 : 22) * dt; if (r.glide && r.vy < -2.2) r.vy = -2.2; r.y += r.vy * dt; if (r.y <= gy) { r.y = gy; r.air = false; r.vy = 0; } } else r.y = gy;
      r.ph += dt * (mv ? 3 + pose.speed * 0.9 : 0);
      if (r.kind === 'ostrich') { const a = mv && !r.air ? Math.sin(r.ph) * 0.75 : r.air ? -0.5 : 0; if (V.olegs) { V.olegs[0].rotation.x = a; V.olegs[1].rotation.x = r.air ? -0.5 : -a; }
        if (V.neck) V.neck.rotation.x = mv ? 0.25 + Math.sin(r.ph * 2) * 0.08 : 0; if (V.wings) V.wings.forEach((w, i) => w.rotation.z = (i ? -1 : 1) * (r.air ? (r.glide ? 1.1 : 0.4 + Math.sin(t * 22) * 0.5) : 0.05));
        if (V.obody) V.obody.position.y = 1.15 + (mv && !r.air ? Math.abs(Math.sin(r.ph)) * 0.06 : 0); }
      else if (V.blades) { const comp = r.air ? 1 : 0.82; V.blades.forEach(b => b.scale.y = comp); }
      place(r);
      const bob = r.kind === 'ostrich' && mv && !r.air ? Math.abs(Math.sin(r.ph)) * 0.1 : 0;
      return { y: r.y + 0.12 + r.seatY * (r.kind === 'kroo' && !r.air ? 0.82 : 1) + bob, legs: r.legs, air: r.air, max: r.max, label: r.label, chain: r.chain };
    },
  };
  return self;
}
