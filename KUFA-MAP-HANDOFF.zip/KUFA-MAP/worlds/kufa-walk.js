// 8 GATES · KUFA — PHASE 2 EXTERIORS (world chat, s349). Builds the walkable desert town from layout/kufa.layout.json.
// buildKufa(THREE, L, C, { touch }) → { group, solids, doors, rooms, signs, update(dt, t, fox, cam), roomAt(x, z), heightAt(x, z), groundY(x, z), setNight(on), labels }
// C = kit/layout-check.js (inWater, onWay, onCliff, zoneAt, faceVec, forestTrees, polyD). Metres; x east, z south, y up.
// PHONE BUDGET: static parts are merged into a few vertex-coloured meshes (one draw call each); palms are instanced.
// Every building: its own shell (from its "outside" note), BIG ROOF SIGN, EYE-LEVEL DOOR SIGN, walk-in sliding glass doors (Meru 2).
// Interiors are empty rooms with a plaque until PHASE 3 brings in the repo room (layout "fit").

export function buildKufa(THREE, L, C, opt = {}) {
  const touch = !!opt.touch, root = new THREE.Group(), lk = L.look || {}, half = (L.map && L.map.half) || 400;
  const col = new THREE.Color(), tmpM = new THREE.Matrix4(), tmpQ = new THREE.Quaternion(), tmpE = new THREE.Euler(), tmpV = new THREE.Vector3(), tmpS = new THREE.Vector3();
  const grad = (() => { const d = new Uint8Array([90, 90, 90, 255, 165, 165, 165, 255, 220, 220, 220, 255, 255, 255, 255, 255]), t = new THREE.DataTexture(d, 4, 1, THREE.RGBAFormat); t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t; })();
  const VC = new THREE.MeshToonMaterial({ vertexColors: true, gradientMap: grad });
  const VCD = new THREE.MeshToonMaterial({ vertexColors: true, gradientMap: grad, side: THREE.DoubleSide });
  // SURFACE DETAIL (graphics polish): one small shader patch on the two merged materials, so every wall, roof, dune and path gets
  // fine plaster / sand grain, slow wind-blown mottling on open ground and a soft dark band where walls meet the ground (fake AO).
  // World-space noise, no textures, no extra draw calls; it fades out with distance (no shimmer far away on a phone).
  const detail = m => { m.onBeforeCompile = sh => {
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vKWP; varying vec3 vKWN;')
      .replace('#include <project_vertex>', '#include <project_vertex>\n\n#ifdef USE_INSTANCING\nvKWP = (modelMatrix * instanceMatrix * vec4(transformed, 1.0)).xyz; vKWN = normalize(mat3(modelMatrix) * mat3(instanceMatrix) * objectNormal);\n#else\nvKWP = (modelMatrix * vec4(transformed, 1.0)).xyz; vKWN = normalize(mat3(modelMatrix) * objectNormal);\n#endif\n');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>
varying vec3 vKWP; varying vec3 vKWN;
float kH(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float kN(vec3 x) { vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(mix(kH(i), kH(i + vec3(1, 0, 0)), f.x), mix(kH(i + vec3(0, 1, 0)), kH(i + vec3(1, 1, 0)), f.x), f.y),
             mix(mix(kH(i + vec3(0, 0, 1)), kH(i + vec3(1, 0, 1)), f.x), mix(kH(i + vec3(0, 1, 1)), kH(i + vec3(1, 1, 1)), f.x), f.y), f.z); }`)
      .replace('#include <color_fragment>', `#include <color_fragment>
{ float up = clamp(vKWN.y, 0.0, 1.0), wall = 1.0 - abs(vKWN.y), d = length(vKWP - cameraPosition), near = 1.0 - smoothstep(18.0, 80.0, d), mid = 1.0 - smoothstep(60.0, 260.0, d);
  #ifdef KUFA_LITE
  float grain = kN(vKWP * 4.3);
#else
  float grain = kN(vKWP * 3.1) * 0.55 + kN(vKWP * 9.7) * 0.45;
#endif
  float mott = kN(vec3(vKWP.x * 0.045, 0.0, vKWP.z * 0.045)) * 0.6 + kN(vec3(vKWP.x * 0.15, 3.0, vKWP.z * 0.15)) * 0.4;
  float rip = sin(vKWP.x * 0.9 + vKWP.z * 0.42 + kN(vKWP * 0.18) * 7.0) * 0.5 + 0.5;
  float sandy = smoothstep(0.08, 0.2, diffuseColor.r - diffuseColor.b) * up;   // warm, open ground (not the pale paths, not walls)
  float k = 1.0 + (grain - 0.5) * 0.16 * near;
  k *= 1.0 + (mott - 0.5) * 0.24 * up * mid;
  k *= 1.0 + (rip - 0.5) * 0.1 * sandy * near;
  k *= 1.0 - wall * (1.0 - smoothstep(0.0, 1.1, vKWP.y)) * 0.24;   // walls darken at their foot
  { float warm = smoothstep(0.05, 0.16, diffuseColor.r - diffuseColor.b) * step(0.6, wall) * near;   // mud-brick courses on warm plaster walls
    float row = vKWP.y / 0.34, along = (abs(vKWN.x) > abs(vKWN.z) ? vKWP.z : vKWP.x) / 0.78 + step(1.0, mod(floor(row), 2.0)) * 0.5;
    float mortar = max(1.0 - smoothstep(0.0, 0.06, abs(fract(row) - 0.5) - 0.44), 1.0 - smoothstep(0.0, 0.03, abs(fract(along) - 0.5) - 0.47));
    k *= 1.0 - mortar * warm * 0.07 * smoothstep(0.35, 0.7, kN(vec3(vKWP.x * 0.3, vKWP.y * 0.5, vKWP.z * 0.3))); }   // only in patches, where the plaster has worn off
#ifndef KUFA_LITE
  k *= 1.0 + wall * smoothstep(0.55, 1.0, kN(vec3(vKWP.x * 0.5 + vKWP.z * 0.5, vKWP.y * 1.6, 1.0))) * 0.06 * near;   // sun-bleached streaks (not on phones)
#endif
  diffuseColor.rgb *= k; }`);
  }; if (touch) m.defines = { ...(m.defines || {}), KUFA_LITE: '' }; m.customProgramCacheKey = () => 'kufaDetail' + (touch ? 'Lite' : ''); };   // phones: cheaper grain, no streaks
  detail(VC); detail(VCD);
  const GLOW = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });
  const WIN = new THREE.MeshBasicMaterial({ vertexColors: true, color: '#3a4a52', toneMapped: false });
  const GLASS = new THREE.MeshToonMaterial({ color: '#bfe6ea', gradientMap: grad, transparent: true, opacity: 0.38, depthWrite: false });
  const GOLD = new THREE.MeshBasicMaterial({ color: '#e6b45a', toneMapped: false });
  const SHADOW = new THREE.MeshBasicMaterial({ color: '#4a2a12', transparent: true, opacity: 0.2, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  const PAL = { sand: lk.grass || '#dcb878', stone: '#e4cfa6', stoneD: '#c9a874', mud: '#b98a52', brass: '#e6b45a', brassD: '#a8792e', ink: '#201e1d', cream: '#f6ecd6', terra: '#c4563a', red: '#c42d3c', teal: '#2f9a8f', blue: '#2f6d9a', wood: '#9a7444', woodD: '#6b4a2c', palm: '#5f7f2e', palmD: '#4a6a24', trunk: '#8a6a44', glass: '#33424a', white: '#fbf8ef', mint: '#bfe8d6', steel: '#8f969c', path: '#efe0bf', curb: '#8a6236', road: '#7a6650' };

  // ---------- merged vertex-coloured batches ----------
  class Batch {
    constructor() { this.pos = []; this.nor = []; this.col = []; }
    add(geo, c, m) { const g = geo.index ? geo.toNonIndexed() : geo, p = g.attributes.position, n = g.attributes.normal, nm = new THREE.Matrix3().getNormalMatrix(m); col.set(c);
      for (let i = 0; i < p.count; i++) { tmpV.fromBufferAttribute(p, i).applyMatrix4(m); this.pos.push(tmpV.x, tmpV.y, tmpV.z); tmpV.fromBufferAttribute(n, i).applyMatrix3(nm).normalize(); this.nor.push(tmpV.x, tmpV.y, tmpV.z); this.col.push(col.r, col.g, col.b); }
      if (g !== geo) g.dispose(); return this; }
    mesh(mat = VC) { if (!this.pos.length) return null; const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nor, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3)); g.computeBoundingSphere(); const m = new THREE.Mesh(g, mat); m.matrixAutoUpdate = false; return m; }
  }
  const M4 = (x = 0, y = 0, z = 0, ry = 0, rx = 0, rz = 0, sx = 1, sy = 1, sz = 1) => { tmpE.set(rx, ry, rz, 'YXZ'); tmpQ.setFromEuler(tmpE); tmpS.set(sx, sy, sz); return new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), tmpQ, tmpS); };
  const GEO = { box: new THREE.BoxGeometry(1, 1, 1), cyl6: new THREE.CylinderGeometry(0.5, 0.5, 1, 6), cyl12: new THREE.CylinderGeometry(0.5, 0.5, 1, 12), cyl20: new THREE.CylinderGeometry(0.5, 0.5, 1, 20), sph: new THREE.SphereGeometry(0.5, 8, 6), hemi: new THREE.SphereGeometry(0.5, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), cone8: new THREE.ConeGeometry(0.5, 1, 8), cone4: new THREE.ConeGeometry(0.5, 1, 4), torus: new THREE.TorusGeometry(0.5, 0.08, 6, 24), halfTorus: new THREE.TorusGeometry(1, 0.18, 6, 12, Math.PI), plane: new THREE.PlaneGeometry(1, 1), circle: new THREE.CircleGeometry(0.5, 24) };
  const onion = (() => { const pts = []; for (let i = 0; i <= 12; i++) { const t = i / 12, r = t < 0.55 ? 0.5 + Math.sin(t / 0.55 * Math.PI * 0.5) * 0.12 : 0.62 * Math.cos((t - 0.55) / 0.45 * Math.PI * 0.5) ** 1.4; pts.push(new THREE.Vector2(Math.max(0.001, r), t * 1.3)); } return new THREE.LatheGeometry(pts, 16); })();
  // box / cylinder / etc. into a batch, in the batch's own (local) frame
  const K = {
    box: (b, w, h, d, c, x, y, z, ry = 0, rx = 0, rz = 0) => b.add(GEO.box, c, M4(x, y + h / 2, z, ry, rx, rz, w, h, d)),
    boxC: (b, w, h, d, c, x, y, z, ry = 0, rx = 0, rz = 0) => b.add(GEO.box, c, M4(x, y, z, ry, rx, rz, w, h, d)),
    cyl: (b, r, h, c, x, y, z, seg = 12, rx = 0, rz = 0) => b.add(seg <= 6 ? GEO.cyl6 : seg <= 12 ? GEO.cyl12 : GEO.cyl20, c, M4(x, y + h / 2, z, 0, rx, rz, r * 2, h, r * 2)),
    sph: (b, r, c, x, y, z, sy = 1) => b.add(GEO.sph, c, M4(x, y, z, 0, 0, 0, r * 2, r * 2 * sy, r * 2)),
    dome: (b, r, c, x, y, z, sy = 1) => b.add(GEO.hemi, c, M4(x, y, z, 0, 0, 0, r * 2, r * 2 * sy, r * 2)),
    onion: (b, r, c, x, y, z) => b.add(onion, c, M4(x, y, z, 0, 0, 0, r * 2, r * 2, r * 2)),
    cone: (b, r, h, c, x, y, z, seg = 8, ry = 0) => b.add(seg <= 4 ? GEO.cone4 : GEO.cone8, c, M4(x, y + h / 2, z, ry, 0, 0, r * 2, h, r * 2)),
    ring: (b, r, c, x, y, z, flat = true) => b.add(GEO.torus, c, M4(x, y, z, 0, flat ? Math.PI / 2 : 0, 0, r * 2, r * 2, r * 2)),
    arch: (b, w, h, c, x, y, z, ry = 0, t = 0.5) => { const r = w / 2; K.box(b, t, h - r, t, c, x - Math.cos(ry) * r, y, z + Math.sin(ry) * r); K.box(b, t, h - r, t, c, x + Math.cos(ry) * r, y, z - Math.sin(ry) * r); b.add(GEO.halfTorus, c, M4(x, y + h - r, z, ry, 0, 0, r, r, t * 2.6)); },
    disc: (b, r, c, x, y, z) => b.add(GEO.circle, c, M4(x, y, z, 0, -Math.PI / 2, 0, r * 2, r * 2, 1)),
    quad: (b, w, d, c, x, y, z, ry = 0) => b.add(GEO.plane, c, M4(x, y, z, ry, -Math.PI / 2, 0, w, d, 1)),
    // striped canvas awning sloping out from a wall: width w along x, out d along +z, from y top to y-drop
    awning: (b, w, d, drop, x, y, z, cols = [PAL.terra, PAL.cream], n = 0) => { n = n || Math.max(3, Math.round(w / 0.9)); const sw = w / n, len = Math.hypot(d, drop), a = Math.atan2(drop, d);
      for (let i = 0; i < n; i++) b.add(GEO.box, cols[i % cols.length], M4(x - w / 2 + sw * (i + 0.5), y - drop / 2, z + d / 2, 0, a, 0, sw, 0.08, len));
      for (let i = 0; i < n; i++) b.add(GEO.cone4, cols[i % cols.length], M4(x - w / 2 + sw * (i + 0.5), y - drop - 0.18, z + d, Math.PI / 4, Math.PI, 0, sw * 0.7, 0.36, 0.1)); },
  };

  // ---------- terrain ----------
  const T = L.terrain || {};
  const heightAt = (x, z) => { let h = 0; for (const q of T.hills || []) { const d = Math.hypot(x - q.c[0], z - q.c[1]) / q.r; if (d < 1) h += q.cliff ? (d < 0.84 ? q.h : q.h * (0.5 + 0.5 * Math.cos(Math.PI * (d - 0.84) / 0.16))) : q.h * (0.5 + 0.5 * Math.cos(Math.PI * d)); }
    for (const q of T.cuts || []) { const r = q.r, e = 8, dx = Math.max(r[0] - x, 0, x - r[1]), dz = Math.max(r[2] - z, 0, z - r[3]), d = Math.hypot(dx, dz); if (d < e) h -= q.depth * (1 - d / e); } return h; };
  const onWay = (x, z, m = 0) => C.onWay(L, x, z, m);
  const inR = (x, z, r, m = 0) => x > r[0] - m && x < r[1] + m && z > r[2] - m && z < r[3] + m;
  const BLD = (L.buildings || []).filter(b => b.f), APRONS = BLD.filter(b => b.door && b.face).map(b => C.apronRect(b));   // keep every door's 12 x 8 m apron clear: no lamp or palm in front of a door
  const town = (L.zones || []).find(z => z.key === 'kufaTown');
  const groundY = (x, z) => { const h = heightAt(x, z); if (h < 0 && onWay(x, z, 0.5)) return 0; if (BLD.some(b => inR(x, z, b.f, 0.5))) return 0; return h; };
  {
    const GS = 2 * half + 240, seg = touch ? 120 : 180, gg = new THREE.PlaneGeometry(GS, GS, seg, seg); gg.rotateX(-Math.PI / 2);
    const pa = gg.attributes.position, cs = new Float32Array(pa.count * 3), base = new THREE.Color(PAL.sand), crest = new THREE.Color('#f1dcaa'), trough = new THREE.Color('#c99e62'), bed = new THREE.Color('#9c7650'), wild = new THREE.Color('#c98f5e'), packed = new THREE.Color('#d6b787'), c2 = new THREE.Color();
    for (let i = 0; i < pa.count; i++) { const x = pa.getX(i), z = pa.getZ(i), h = heightAt(x, z); pa.setY(i, h); c2.copy(base);
      if (h > 0.2) c2.lerp(crest, Math.min(1, h / 18)); else if (h < -0.2) c2.lerp(bed, Math.min(1, -h / 4));
      const n = Math.sin(x * 0.11) * Math.cos(z * 0.13) + Math.sin(x * 0.031 + z * 0.047); c2.lerp(n > 0 ? crest : trough, Math.min(0.25, Math.abs(n) * 0.12));
      if (town && inR(x, z, town.r)) c2.lerp(packed, 0.55);
      for (const w of L.wild || []) if (w.r && inR(x, z, w.r)) { c2.lerp(wild, 0.45); break; }
      cs[i * 3] = c2.r; cs[i * 3 + 1] = c2.g; cs[i * 3 + 2] = c2.b; }
    gg.setAttribute('color', new THREE.BufferAttribute(cs, 3)); gg.computeVertexNormals(); const gm = new THREE.Mesh(gg, VC); gm.matrixAutoUpdate = false; root.add(gm);
    // map edge: a low dune wall
    const eb = new Batch(); for (const [x, z, w, d] of [[0, -half - 3, 2 * half + 12, 6], [0, half + 3, 2 * half + 12, 6], [-half - 3, 0, 6, 2 * half], [half + 3, 0, 6, 2 * half]]) K.box(eb, w, 3, d, '#d7b57e', x, -0.5, z); root.add(eb.mesh());
  }

  // ---------- static world batch (ground overlays, ways, lining, props, pads) ----------
  const S = new Batch(), SG = new Batch(), SH = new Batch();   // solid · glow · fake long shadows
  const SURF = { stone: '#e2cfa8', tile: '#c9a46a', grass: '#7f9a46', sand: '#ecd5a2', wood: '#9a7444', dirt: '#a8794a', metal: '#b0b6bc' };
  (L.surfaces || []).forEach((s, i) => { if (!s.r) return; const [x0, x1, z0, z1] = s.r; K.quad(S, x1 - x0, z1 - z0, SURF[s.s] || '#d8c39a', (x0 + x1) / 2, 0.02 + i * 0.0006, (z0 + z1) / 2);
    if (s.s === 'tile') { for (let a = 0; a < 8; a++) { const r = Math.min(x1 - x0, z1 - z0) * 0.45; K.box(S, r * 2, 0.02, 0.35, PAL.brass, (x0 + x1) / 2, 0.03, (z0 + z1) / 2, a * Math.PI / 8); } }
    if (s.s === 'dirt' && s.note && /FARM/.test(s.note)) for (let x = x0 + 2; x < x1 - 1; x += 3) K.box(S, 1.2, 0.25, z1 - z0 - 3, '#8a5e36', x, 0, (z0 + z1) / 2); });
  // ways: paths (pale stone, dark curbs: easy to see) + roads (packed dark)
  const WY = 0.06, way = (p, w, c, curb, y) => { for (let i = 0; i < p.length - 1; i++) { const [ax, az] = p[i], [bx, bz] = p[i + 1], len = Math.hypot(bx - ax, bz - az); if (len < 0.05) continue; const ry = Math.atan2(bx - ax, bz - az), mx = (ax + bx) / 2, mz = (az + bz) / 2;
      if (curb) S.add(GEO.plane, curb, M4(mx, y - 0.01, mz, ry, -Math.PI / 2, 0, w + 1.1, len, 1)); S.add(GEO.plane, c, M4(mx, y, mz, ry, -Math.PI / 2, 0, w, len, 1)); }
    for (const [x, z] of p) { if (curb) K.disc(S, (w + 1.1) / 2, curb, x, y - 0.012, z); K.disc(S, w / 2, c, x, y - 0.002, z); } };
  for (const r of L.roads || []) if (r.p) way(r.p, r.w || 10, PAL.road, '#5a4a3a', WY - 0.01);
  for (const p of L.paths || []) if (p.p) way(p.p, p.w || 4, PAL.path, PAL.curb, WY);
  // BRIDGES: wherever a path / road crosses a dip (the dry WADI), a deck with rails at y 0
  for (const p of [...(L.paths || []), ...(L.roads || [])]) { if (!p.p) continue; const w = p.w || 4;
    for (let i = 0; i < p.p.length - 1; i++) { const [ax, az] = p.p[i], [bx, bz] = p.p[i + 1], len = Math.hypot(bx - ax, bz - az), n = Math.ceil(len / 1); let run = null;
      const flush = () => { if (!run) return; const [s0, s1] = run, x0 = ax + (bx - ax) * s0, z0 = az + (bz - az) * s0, x1 = ax + (bx - ax) * s1, z1 = az + (bz - az) * s1, L2 = Math.hypot(x1 - x0, z1 - z0) + 2, ry = Math.atan2(bx - ax, bz - az), mx = (x0 + x1) / 2, mz = (z0 + z1) / 2, cx = Math.cos(ry), cz = -Math.sin(ry);
        K.boxC(S, w + 1.4, 0.5, L2, PAL.wood, mx, -0.2, mz, ry); for (const s of [-1, 1]) { K.boxC(S, 0.3, 1.1, L2, PAL.woodD, mx + cx * s * (w / 2 + 0.55), 0.55, mz + cz * s * (w / 2 + 0.55), ry); for (let k = -L2 / 2; k <= L2 / 2; k += 3) K.box(S, 0.35, 1.3, 0.35, PAL.brassD, mx + cx * s * (w / 2 + 0.55) + Math.sin(ry) * k, 0, mz + cz * s * (w / 2 + 0.55) + Math.cos(ry) * k); }
        for (const s of [-1, 1]) { const px = mx + Math.sin(ry) * s * (L2 / 2 - 1), pz = mz + Math.cos(ry) * s * (L2 / 2 - 1); K.box(S, 0.8, Math.max(1, -heightAt(px, pz)) + 0.2, 0.8, PAL.stoneD, px, heightAt(px, pz) - 0.2, pz); }
        run = null; };
      for (let k = 0; k <= n; k++) { const s = k / n, x = ax + (bx - ax) * s, z = az + (bz - az) * s, dip = heightAt(x, z) < -0.25; if (dip) { if (!run) run = [s, s]; else run[1] = s; } else flush(); } flush(); } }
  const lampPts = [];   // every lamp + lantern: warm light pools on the ground at night
  // path lining: Kufa brass lamps · hanging lanterns on timber posts · palms
  const liningPts = p => { const out = [], pts = p.p || [], e = p.every || 14, off = (p.w || 4) / 2 + 1.4; if (pts.length < 2) return out;
    for (let i = 0; i < pts.length - 1; i++) { const [ax, az] = pts[i], [bx, bz] = pts[i + 1], len = Math.hypot(bx - ax, bz - az); if (len < 0.1) continue; const ux = (bx - ax) / len, uz = (bz - az) / len;
      for (let s = e / 2; s < len; s += e) for (const side of [-1, 1]) { const x = ax + ux * s - uz * off * side, z = az + uz * s + ux * off * side; if (!BLD.some(b => inR(x, z, b.f, 1)) && !APRONS.some(r => inR(x, z, r, 1.5))) out.push([x, z, Math.atan2(ux, uz)]); } } return out; };
  const palmPts = [], palmData = [], ZERO = new THREE.Matrix4().makeScale(0, 0, 0); let palmIM = null, palmHidden = new Set();
  for (const p of L.paths || []) { const pts = liningPts(p);
    for (const [x, z, ry] of pts) { const y = Math.max(0, heightAt(x, z));
      if (p.lining === 'lamps' || p.lining === 'lanterns') lampPts.push([x, y, z, p.lining === 'lamps' ? 1 : 0.8]);
      if (p.lining === 'lamps') { K.cyl(S, 0.16, 0.5, PAL.stoneD, x, y, z, 6); K.cyl(S, 0.09, 3.6, PAL.ink, x, y + 0.5, z, 6); K.box(S, 0.7, 0.12, 0.7, PAL.brassD, x, y + 4.0, z, ry); K.box(SG, 0.5, 0.62, 0.5, '#ffcf7a', x, y + 4.1, z, ry); K.cone(S, 0.48, 0.45, PAL.brass, x, y + 4.72, z, 4, ry + Math.PI / 4); }
      else if (p.lining === 'lanterns') { K.box(S, 0.24, 3.2, 0.24, PAL.woodD, x, y, z); K.box(S, 0.9, 0.16, 0.16, PAL.woodD, x, y + 3.05, z, ry + Math.PI / 2); K.box(SG, 0.42, 0.55, 0.42, '#ffb347', x + Math.cos(ry) * 0.38, y + 2.45, z - Math.sin(ry) * 0.38, ry); K.box(S, 0.5, 0.08, 0.5, PAL.brass, x + Math.cos(ry) * 0.38, y + 2.76, z - Math.sin(ry) * 0.38, ry); }
      else palmPts.push({ x, z, s: 0.9 + ((x * 13.1 + z * 7.7) % 1 + 1) % 1 * 0.3 }); } }
  // props (notes give the Kufa meaning: K crest, standpipe, tally board, caravan gate, souk stalls, milestone, well, gantry, fire ring, obelisk)
  let stallN = 0; const AWN = [[PAL.terra, PAL.cream], [PAL.teal, PAL.cream], [PAL.brass, PAL.red], [PAL.blue, PAL.cream]];
  for (const pr of L.props || []) { if (!pr.at) continue; const [x, z] = pr.at, y = groundY(x, z), note = (pr.note || '').toUpperCase(), ry = { N: Math.PI, S: 0, E: Math.PI / 2, W: -Math.PI / 2 }[pr.face] || 0;
    if (/K CREST/.test(note)) { K.cyl(S, 7.5, 0.25, PAL.stoneD, x, y, z, 20); K.cyl(S, 6.6, 0.3, '#3a6ea5', x, y, z, 20); K.ring(SG, 6.8, '#7fe3ff', x, y + 0.36, z); K.cyl(S, 1.6, 1.2, PAL.stone, x, y, z, 12); K.box(S, 0.7, 4.6, 0.7, PAL.red, x - 0.9, y + 1.2, z); K.box(S, 0.7, 2.6, 0.7, PAL.red, x + 0.2, y + 3.0, z, 0, 0, -0.75); K.box(S, 0.7, 2.6, 0.7, PAL.red, x + 0.2, y + 1.2, z, 0, 0, 0.75); K.ring(S, 2.6, PAL.brass, x, y + 3.6, z, false); }
    else if (/STANDPIPE/.test(note)) { K.cyl(S, 1.4, 0.6, PAL.stoneD, x, y, z, 12); K.cyl(S, 1.15, 0.05, '#3aa7a0', x, y + 0.6, z, 12); K.cyl(S, 0.18, 2.2, PAL.brassD, x, y, z, 8); K.box(S, 0.9, 0.16, 0.16, PAL.brass, x + 0.4, y + 2.1, z); K.cyl(S, 0.05, 1.5, '#7fd0e0', x + 0.8, y + 0.6, z, 6); }
    else if (/WATER JARS/.test(note)) { for (const [a, b] of [[0, 0], [0.9, 0.4], [-0.6, 0.7]]) { K.sph(S, 0.45, PAL.terra, x + a, y + 0.5, z + b, 1.2); K.cyl(S, 0.2, 0.3, PAL.terra, x + a, y + 0.95, z + b, 8); } }
    else if (/TALLY BOARD/.test(note)) { K.box(S, 0.3, 3.4, 0.3, PAL.woodD, x - 1.9, y, z); K.box(S, 0.3, 3.4, 0.3, PAL.woodD, x + 1.9, y, z); K.box(S, 4.4, 2.2, 0.2, PAL.ink, x, y + 1.2, z); for (let i = 0; i < 9; i++) K.box(SG, 0.28, 0.9, 0.04, i < 5 ? '#7fe3ff' : '#ec3013', x - 1.6 + i * 0.4, y + 1.8, z + 0.12); }
    else if (/CARAVAN GATE/.test(note)) { K.arch(S, 13, 10, PAL.stone, x, y, z, Math.PI / 2, 1.4); K.box(S, 1.8, 1.2, 15.5, PAL.stoneD, x, y + 9.8, z); K.awning(S, 3, 1.2, 0.5, x, y + 7, z + 0.8, [PAL.red, PAL.brass]); }
    else if (/MILESTONE/.test(note)) { K.box(S, 1.1, 2.4, 0.7, PAL.stoneD, x, y, z); K.box(S, 1.2, 0.3, 0.8, PAL.ink, x, y + 2.0, z); }
    else if (/WELL/.test(note)) { K.cyl(S, 2.2, 1.1, PAL.stoneD, x, y, z, 16); K.cyl(S, 1.8, 0.05, '#1f3a4a', x, y + 1.05, z, 16); K.box(S, 0.3, 3.4, 0.3, PAL.woodD, x - 2, y, z); K.box(S, 0.3, 3.4, 0.3, PAL.woodD, x + 2, y, z); K.box(S, 4.4, 0.3, 0.3, PAL.woodD, x, y + 3.3, z); K.cyl(S, 1.3, 2.4, PAL.steel, x + 4, y, z, 12); }
    else if (/GANTRY/.test(note)) { for (const s of [-1, 1]) K.box(S, 0.6, 11, 0.6, '#5a5f66', x + s * 7, y, z); K.box(S, 15, 0.8, 0.8, '#5a5f66', x, y + 10.6, z); K.box(SG, 13, 0.25, 0.25, '#ec3013', x, y + 10.2, z); }
    else if (/RED BAND/.test(note)) { for (let i = 0; i < 6; i++) K.quad(S, 3, 2, i % 2 ? PAL.white : '#c42d3c', x - 7.5 + i * 3, y + 0.04, z); }
    else if (/FIRE RING/.test(note)) { for (let a = 0; a < 10; a++) K.sph(S, 0.35, PAL.stoneD, x + Math.cos(a * 0.628) * 1.4, y + 0.2, z + Math.sin(a * 0.628) * 1.4); K.cone(SG, 0.8, 1.4, '#ff9a3a', x, y, z, 8); }
    else if (/OBELISK/.test(note)) { K.box(S, 1.6, 0.6, 1.6, PAL.stoneD, x, y, z); K.box(S, 1.1, 7.5, 1.1, '#cbb28a', x, y + 0.6, z, 0.2, 0, 0.12); K.cone(S, 0.8, 1.2, PAL.brass, x + 0.7, y + 8, z, 4); }
    else if (/SHELTER/.test(note)) { for (const [a, b] of [[-2, -1.5], [2, -1.5], [-2, 1.5], [2, 1.5]]) K.box(S, 0.2, 2.6, 0.2, PAL.woodD, x + a, y, z + b); K.box(S, 5, 0.12, 3.6, PAL.cream, x, y + 2.6, z); }
    else if (/SIGNPOST/.test(note)) { K.box(S, 0.3, 3.2, 0.3, PAL.woodD, x, y, z); }
    else if (pr.k === 'stall') { const c = AWN[stallN++ % AWN.length]; K.box(S, 3, 1, 1.4, PAL.wood, x, y, z); for (const a of [-1.4, 1.4]) K.box(S, 0.14, 2.6, 0.14, PAL.woodD, x + a, y, z - 0.9); K.awning(S, 3.4, 1.8, 0.6, x, y + 2.7, z - 0.9, c); K.sph(S, 0.3, PAL.terra, x - 0.8, y + 1.3, z); K.box(S, 0.6, 0.4, 0.5, '#e8c35a', x + 0.6, y + 1.0, z); }
    else if (pr.k === 'bench') { K.box(S, 2, 0.12, 0.6, PAL.wood, x, y + 0.45, z, ry); K.box(S, 1.8, 0.45, 0.4, PAL.stoneD, x, y, z, ry); }
    else if (pr.k === 'planter') { K.box(S, 1.6, 0.8, 1.6, PAL.terra, x, y, z); palmPts.push({ x, z, s: 0.7 }); }
    else if (pr.k === 'barrel') K.cyl(S, 0.45, 1.1, PAL.woodD, x, y, z, 10);
    else if (pr.k === 'crate') { K.box(S, 3.4, 1.4, 1.8, PAL.wood, x, y + 0.6, z); for (const a of [-1.2, 1.2]) K.cyl(S, 0.6, 0.25, PAL.woodD, x + a, y + 0.6, z + 0.95, 10, Math.PI / 2); K.box(S, 3, 0.9, 1.5, PAL.cream, x, y + 2.0, z); }
    else if (pr.k === 'rock') { K.sph(S, 1.1, '#b8946a', x, y + 0.5, z, 0.8); K.sph(S, 0.7, '#a8845a', x + 0.9, y + 0.3, z + 0.4, 0.8); }
    else if (pr.k === 'fence') { for (let i = -3; i <= 3; i++) K.box(S, 0.2, 2.2, 0.2, PAL.woodD, x + i * 1.6, y, z); K.box(S, 9.8, 0.2, 0.12, PAL.wood, x, y + 1.7, z); }
    else if (pr.k === 'lamp') { lampPts.push([x, y, z, 1]); K.cyl(S, 0.1, 3.6, PAL.ink, x, y, z, 6); K.box(SG, 0.5, 0.6, 0.5, '#ffcf7a', x, y + 3.6, z); }
    else if (pr.k === 'statue') K.box(S, 1.2, 3.6, 1.2, PAL.stoneD, x, y, z);
    else if (pr.k === 'fountain') K.cyl(S, 3, 0.9, PAL.stoneD, x, y, z, 16);
    else if (pr.k === 'tree') palmPts.push({ x, z, s: 1 });
    else if (pr.k === 'sign') { K.box(S, 0.25, 3, 0.25, PAL.woodD, x, y, z); K.box(S, 2, 1.2, 0.15, PAL.ink, x, y + 2, z); } }

  // ---------- water: the OASIS lake (turquoise, pale shore ring, reeds), the skiff + dive buoy ----------
  const waterMeshes = [], waterFX = [];
  for (const w of L.water || []) if (w.e) { const [cx, cz, rx, rz] = w.e;
    const shore = new THREE.Mesh(GEO.circle, new THREE.MeshToonMaterial({ color: '#ead6a6', gradientMap: grad })); shore.rotation.x = -Math.PI / 2; shore.scale.set((rx + 4) * 2, (rz + 4) * 2, 1); shore.position.set(cx, 0.015, cz); root.add(shore);
    const deep = new THREE.Mesh(new THREE.CircleGeometry(0.5, 48), new THREE.MeshToonMaterial({ color: lk.water || '#3aa7a0', gradientMap: grad })); deep.rotation.x = -Math.PI / 2; deep.scale.set(rx * 2, rz * 2, 1); deep.position.set(cx, 0.04, cz); root.add(deep); waterMeshes.push(deep);
    const mid = new THREE.Mesh(new THREE.CircleGeometry(0.5, 48), new THREE.MeshBasicMaterial({ color: '#2a8a88', transparent: true, opacity: 0.55, depthWrite: false })); mid.rotation.x = -Math.PI / 2; mid.scale.set(rx * 1.3, rz * 1.3, 1); mid.position.set(cx, 0.05, cz); root.add(mid);
    { const tex = waterGlint(); tex.repeat.set(rx / 5, rz / 5); const gl = new THREE.Mesh(new THREE.CircleGeometry(0.5, 48), new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));   // drifting sun glints on the water
      gl.rotation.x = -Math.PI / 2; gl.scale.set(rx * 2 - 1, rz * 2 - 1, 1); gl.position.set(cx, 0.06, cz); root.add(gl); waterFX.push(gl); }
    for (let a = 0; a < 70; a++) { const t = a / 70 * Math.PI * 2 + Math.sin(a) * 0.05, x = cx + Math.cos(t) * (rx + 0.6), z = cz + Math.sin(t) * (rz + 0.6); if (onWay(x, z, 2)) continue; K.cone(S, 0.25, 1.6 + (a % 3) * 0.4, '#6f8a3a', x, 0, z, 4); } }
  // the dive buoy at the lake centre (Station 9 lies under the lake)
  for (const w of L.water || []) if (w.e) { const [cx, cz] = w.e; K.cyl(S, 1.2, 0.8, '#c42d3c', cx, -0.2, cz, 12); K.cyl(S, 0.15, 2.6, PAL.ink, cx, 0.6, cz, 6); K.sph(SG, 0.4, '#7fe3ff', cx, 3.3, cz); K.ring(SG, 3.2, '#7fe3ff', cx, 0.12, cz); }

  // ---------- palms (instanced): forests (mix "palm") + palm-lined paths + planters ----------
  const FT = C.forestTrees ? C.forestTrees(L, { thin: touch ? 1.35 : 1 }) : [];
  for (const q of FT) palmPts.push({ x: q.x, z: q.z, s: q.s || 1 });
  { const pb = new Batch(), TC = [].concat(lk.trees || [PAL.palm, '#6b8f34', '#8aa03a']);
    for (let i = 0; i < 6; i++) K.box(pb, 0.42 - i * 0.03, 1.05, 0.42 - i * 0.03, i % 2 ? PAL.trunk : '#7a5c3a', Math.sin(i * 0.7) * 0.12 * i, i * 1.0, 0, 0, 0, 0.02 * i);
    const top = [0.9, 6.1, 0]; for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; pb.add(GEO.box, TC[i % TC.length], M4(top[0] + Math.sin(a) * 1.5, top[1] - 0.25, Math.cos(a) * 1.5, a, 0.55, 0, 0.75, 0.07, 3.4)); pb.add(GEO.box, TC[(i + 1) % TC.length], M4(top[0] + Math.sin(a) * 2.9, top[1] - 1.05, Math.cos(a) * 2.9, a, 0.95, 0, 0.55, 0.06, 1.5)); }
    for (let i = 0; i < 3; i++) K.boxC(pb, 0.4, 0.4, 0.4, '#6b4a2c', top[0] + Math.cos(i * 2.1) * 0.35, top[1] - 0.35, Math.sin(i * 2.1) * 0.35, i);
    const g = pb.mesh().geometry, pts = palmPts.filter(q => !(L.water || []).some(w => w.e && Math.hypot((q.x - w.e[0]) / w.e[2], (q.z - w.e[1]) / w.e[3]) < 1.02));
    const im = new THREE.InstancedMesh(g, VC, Math.max(1, pts.length)), o = new THREE.Object3D();
    pts.forEach((q, i) => { o.position.set(q.x, heightAt(q.x, q.z) - 0.1, q.z); o.rotation.set(0, (q.x * 0.37 + q.z * 0.11) % 6.28, 0); o.scale.setScalar(q.s); o.updateMatrix(); im.setMatrixAt(i, o.matrix); palmData.push({ x: q.x, z: q.z, m: o.matrix.clone() }); });
    im.count = pts.length; root.add(im); palmIM = im; }

  // ---------- wild areas: scattered rocks + dry scrub (creatures live here, never on the path) ----------
  for (const w of L.wild || []) if (w.r) { const [x0, x1, z0, z1] = w.r, n = Math.min(60, Math.round((x1 - x0) * (z1 - z0) / (touch ? 900 : 600)));
    for (let i = 0; i < n; i++) { const fx = ((i * 0.618 + x0 * 0.013) % 1 + 1) % 1, fz = ((i * 0.381 + z0 * 0.017) % 1 + 1) % 1, x = x0 + fx * (x1 - x0), z = z0 + fz * (z1 - z0); if (onWay(x, z, 3)) continue; const y = heightAt(x, z);
      if (i % 3) K.sph(S, 0.7 + (i % 4) * 0.35, i % 2 ? '#a8774e' : '#b98a5e', x, y + 0.3, z, 0.7); else for (let k = 0; k < 4; k++) K.cone(S, 0.12, 1.1, '#8a7a4a', x + Math.cos(k * 1.6) * 0.4, y, z + Math.sin(k * 1.6) * 0.4, 4); } }

  // ---------- DESERT DRESSING (graphics polish): rock clusters, dry scrub, bleached bones and old way-marker cairns across the open
  // dune sea, so the ground between the districts is not bare. Three instanced draw calls; seeded (the same every load); kept off every
  // path (+4 m), building, water, the town zones, battle gates and spots. Visual only (no solids).
  { let seed = 8812; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    const keepOut = (L.zones || []).filter(z => z.r && !/Spy/.test(z.key) && ['kufaTown', 'kufaTownSquare', 'kufaBazaar', 'kufaWayStation', 'kufaCastleGrounds', 'kufaSandDock', 'kufaBerth'].includes(z.key)).map(z => z.r);
    const busy = [].concat((L.spots || []).filter(s => s.at && !s.room).map(s => [s.at[0], s.at[1], 9]), (L.gates || []).filter(g => g.at).map(g => [g.at[0], g.at[1], (g.r || 6) + 6]));
    const free = (x, z) => Math.abs(x) < half - 6 && Math.abs(z) < half - 6 && !onWay(x, z, 4) && !C.inWater(L, x, z) && !BLD.some(b => inR(x, z, b.f, 6)) && !keepOut.some(q => inR(x, z, q, 2)) && !busy.some(([bx, bz, br]) => Math.hypot(x - bx, z - bz) < br);
    const proto = fn => { const b = new Batch(); fn(b); const m = b.mesh(VC); return m.geometry; };
    const rockG = proto(b => { b.add(new THREE.DodecahedronGeometry(0.6, 0), '#b07d52', M4(0, 0.25, 0, 0, 0, 0, 1, 0.6, 1)); b.add(new THREE.DodecahedronGeometry(0.38, 0), '#9a6c46', M4(0.55, 0.12, 0.2, 0.5, 0, 0, 1, 0.7, 1)); });   // 2 stones, 72 triangles
    const scrubG = proto(b => { for (let k = 0; k < 5; k++) { const a = k * 1.26, rr = 0.12 + (k % 3) * 0.12; b.add(GEO.cone4, k % 2 ? '#8a7a4a' : '#9c8a52', M4(Math.cos(a) * rr, 0.4, Math.sin(a) * rr, a, Math.cos(a) * 0.35, Math.sin(a) * 0.35, 0.12, 0.8 + (k % 3) * 0.25, 0.12)); } b.add(GEO.box, '#7a6a3e', M4(0, 0.08, 0, 0.4, 0, 0, 0.45, 0.16, 0.45)); });   // ~50 triangles a tuft
    const boneG = proto(b => { b.add(GEO.box, '#efe6d2', M4(0, 0.06, 0, 0, 0, 0, 0.12, 0.12, 1.2)); for (let k = 0; k < 4; k++) b.add(GEO.halfTorus, '#efe6d2', M4(0, 0.05, -0.35 + k * 0.24, 0, Math.PI / 2, 0, 0.32, 0.3, 0.5)); b.add(GEO.sph, '#e4d9c2', M4(0.1, 0.12, 0.85, 0.3, 0, 0, 0.36, 0.28, 0.5)); });
    const place = (geo, n, sMin, sMax, tries = 8) => { const pts = []; for (let i = 0; i < n * tries && pts.length < n; i++) { const x = (rnd() * 2 - 1) * half, z = (rnd() * 2 - 1) * half; if (!free(x, z)) continue; pts.push([x, z, sMin + rnd() * (sMax - sMin), rnd() * 6.28]); }
      const im = new THREE.InstancedMesh(geo, VC, Math.max(1, pts.length)); im.count = pts.length; pts.forEach(([x, z, sc, ry], i) => im.setMatrixAt(i, M4(x, heightAt(x, z) - 0.05, z, ry, 0, 0, sc, sc, sc))); im.instanceMatrix.needsUpdate = true; root.add(im); return pts; };
    place(rockG, touch ? 360 : 600, 0.9, 3.2); place(rockG, 36, 4, 7.5); place(scrubG, touch ? 420 : 700, 1, 1.9); place(boneG, 18, 1, 1.5);   // small rocks, a few big outcrops, scrub, bones
    // way-marker cairns: a stack of flat stones every ~45 m beside the roads that cross open desert (helps a low-vision walker follow a road)
    const cairn = new Batch(); for (const w of [].concat(L.roads || [], L.paths || [])) { const pts = w.pts || w.p || []; for (let i = 0; i + 1 < pts.length; i++) { const [ax, az] = pts[i], [bx, bz] = pts[i + 1], len = Math.hypot(bx - ax, bz - az), ux = (bx - ax) / (len || 1), uz = (bz - az) / (len || 1), wd = (w.w || 6) / 2 + 2.2;
      for (let d = 20; d < len; d += 45) { const x = ax + ux * d - uz * wd, z = az + uz * d + ux * wd; if (keepOut.some(q => inR(x, z, q, 4)) || BLD.some(b => inR(x, z, b.f, 4)) || C.inWater(L, x, z)) continue; const y = heightAt(x, z);
        K.cyl(cairn, 0.55, 0.28, '#b8936a', x, y, z, 6); K.cyl(cairn, 0.42, 0.26, '#a37c55', x, y + 0.28, z, 6); K.cyl(cairn, 0.3, 0.24, '#c9a47a', x, y + 0.54, z, 6); K.sph(cairn, 0.16, PAL.terra, x, y + 0.9, z); } } }
    const cm = cairn.mesh(VC); if (cm) root.add(cm); }

  // ---------- canvas text (signs + labels) ----------
  const textCanvas = (lines, { h = 220, fg = '#fbf3e0', bg = '#201e1d', rim = '#e6b45a', pad = 70, font = 900 } = {}) => {
    const c = document.createElement('canvas'), g = c.getContext('2d'), fam = 'Archivo, "Arial Black", Arial, sans-serif', sizes = lines.map((_, i) => i ? h * 0.42 : h * 0.62);
    let w = 0; lines.forEach((s, i) => { g.font = `${font} ${sizes[i]}px ${fam}`; w = Math.max(w, g.measureText(s).width); });
    c.width = Math.min(4096, Math.ceil(w + pad * 2)); c.height = Math.ceil(h + (lines.length - 1) * h * 0.55);
    g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height); g.fillStyle = rim; const rb = Math.round(h * 0.05); g.fillRect(0, 0, c.width, rb); g.fillRect(0, c.height - rb, c.width, rb); g.fillRect(0, 0, rb, c.height); g.fillRect(c.width - rb, 0, rb, c.height);
    g.fillStyle = fg; g.textBaseline = 'middle'; g.textAlign = 'center'; let y = h * 0.53; lines.forEach((s, i) => { g.font = `${font} ${sizes[i]}px ${fam}`; const sc = Math.min(1, (c.width - pad * 1.4) / Math.max(1, g.measureText(s).width)); g.save(); g.translate(c.width / 2, y); g.scale(sc, 1); g.fillText(s, 0, 0); g.restore(); y += h * 0.55; });
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return { t, aspect: c.width / c.height }; };
  const signs = [];
  // a flat sign (board + text face) in a group's local frame; faces +z
  // bt = the batch (same frame as parent) that takes the dark backing board; bottom = y is the board's bottom edge
  const signBoard = (parent, lines, hgt, maxW, x, y, z, opts = {}, bt = null, bottom = false) => { const { t, aspect } = textCanvas(lines, opts); let h = hgt, w = h * aspect; if (w > maxW) { w = maxW; h = Math.max(hgt * 0.55, w / aspect); w = h * aspect; }
    const yc = bottom ? y + h / 2 : y, g = new THREE.Group(); g.position.set(x, yc, z);
    if (bt) { K.boxC(bt, w + 0.24, h + 0.24, 0.22, '#201e1d', x, yc, z - 0.12); K.boxC(bt, w - 0.12, h - 0.12, 0.05, '#8a6a44', x, yc, z - 0.25); for (let k = 1; k < Math.round(h / 0.45); k++) K.boxC(bt, w - 0.12, 0.05, 0.07, '#6b4f32', x, yc - h / 2 + 0.06 + k * (h - 0.12) / Math.round(h / 0.45), z - 0.26); }   /* from behind: a planked timber back in a dark frame (it was a flat black slab) */ else { const back = new THREE.Mesh(GEO.box, new THREE.MeshToonMaterial({ color: '#201e1d', gradientMap: grad })); back.scale.set(w + 0.24, h + 0.24, 0.22); back.position.z = -0.12; g.add(back); }
    const face = new THREE.Mesh(GEO.plane, new THREE.MeshBasicMaterial({ map: t, toneMapped: false })); face.scale.set(w, h, 1); face.position.z = 0.005; g.add(face); parent.add(g); return { g, w, h, x, y: yc }; };
  const labelSprite = (lines, hgt = 1.6, opts = {}) => { const { t, aspect } = textCanvas([].concat(lines), { h: 160, pad: 50, ...opts }); const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, toneMapped: false, depthTest: true })); s.scale.set(hgt * aspect, hgt * (t.image.height / 160), 1); return s; };

  // ---------- BUILDINGS ----------
  const solids = [], doors = [], rooms = [], spinners = [], winMeshes = [], FR = new Batch(); let nGlass = 0, nWood = 0;
  const FACE_RY = { S: 0, N: Math.PI, E: Math.PI / 2, W: -Math.PI / 2 };
  const toWorld = (bd, lx, lz) => { const c = Math.cos(bd.ry), s = Math.sin(bd.ry); return [bd.cx + lx * c + lz * s, bd.cz - lx * s + lz * c]; };
  const solidLocal = (bd, x0, x1, z0, z1) => { const a = toWorld(bd, x0, z0), b = toWorld(bd, x1, z1); solids.push([Math.min(a[0], b[0]), Math.max(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[1], b[1])]); };
  const TYPE = { kufaCamelPen: 'yard', kufaStadium: 'bowl', kufaThroneRoom: 'keep' };

  for (const b of BLD) {
    const [x0, x1, z0, z1] = b.f, ry = FACE_RY[b.face] || 0, ew = b.face === 'E' || b.face === 'W', W = ew ? z1 - z0 : x1 - x0, D = ew ? x1 - x0 : z1 - z0, H = b.h || 8, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
    const bd = { b, key: b.key, cx, cz, ry, W, D, H, type: TYPE[b.key] || 'shell', wall: ({ kufaHouse1: '#ece2cc', kufaHouse2: '#d49a72', kufaHouse4: '#d8b060' })[b.key] || b.color || PAL.stone };   // the four houses were near-identical sand: whitewash, terracotta, ochre (graphics polish; the layout colour still rules every other building)
    const dl = b.door ? (() => { const dx = b.door[0] - cx, dz = b.door[1] - cz; return b.face === 'S' ? dx : b.face === 'N' ? -dx : b.face === 'E' ? -dz : dz; })() : 0;
    bd.lx = Math.max(-W / 2 + 2.6, Math.min(W / 2 - 2.6, dl));
    const grp = new THREE.Group(); grp.position.set(cx, 0, cz); grp.rotation.y = ry; root.add(grp); bd.grp = grp;
    const shellB = new Batch(), sides = { front: shellB, back: shellB, left: shellB, right: shellB }, top = new Batch(), deco = new Batch(), inner = new Batch(), innerGlow = new Batch(), glow = new Batch(), win = new Batch();
    const t = 0.4, room = b.room || {}, ceil = Math.min(H - 0.6, room.h && room.h > 2 ? Math.max(room.h, 3.6) : H - 0.6), doorW = 4.2, doorH = Math.min(4.5, ceil - 0.3), wc = bd.wall, trim = b.key === 'kufaCreamery' ? '#7fc8b0' : PAL.stoneD;
    bd.ceil = ceil; bd.doorH = doorH;
    // fake long shadow (low sun from the west-south-west → shadows to the east-north-east)
    { const sx = H * 1.25, sz = -H * 0.45, pts = [[x0, z0], [x1, z0], [x1, z1], [x0, z1], [x0 + sx, z0 + sz], [x1 + sx, z0 + sz], [x1 + sx, z1 + sz], [x0 + sx, z1 + sz]];
      const hull = (P => { P = P.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]); const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]), lo = [], up = []; for (const p of P) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], p) <= 0) lo.pop(); lo.push(p); } for (const p of P.reverse()) { while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], p) <= 0) up.pop(); up.push(p); } return lo.slice(0, -1).concat(up.slice(0, -1)); })(pts);
      for (let i = 1; i < hull.length - 1; i++) SH.pos.push(hull[0][0], 0.1, hull[0][1], hull[i + 1][0], 0.1, hull[i + 1][1], hull[i][0], 0.1, hull[i][1]); }
    // ---- shell walls with the door gap + windows
    const wallRun = (bt, lenA, lenB, zc, side) => { // a wall along local x from lenA to lenB at local z = zc (rotated for sides by the caller)
      K.box(bt, lenB - lenA, H, t, wc, (lenA + lenB) / 2, 0, zc); K.box(bt, lenB - lenA + 0.1, 0.5, t + 0.25, trim, (lenA + lenB) / 2, 0, zc); K.box(bt, lenB - lenA + 0.2, 0.45, t + 0.3, trim, (lenA + lenB) / 2, H - 0.45, zc); };
    if (bd.type === 'shell' || bd.type === 'keep') {
      const fz = D / 2 - t / 2, gA = bd.lx - doorW / 2, gB = bd.lx + doorW / 2;
      // front: left of the door, right of the door, lintel
      K.box(sides.front, gA + W / 2, H, t, wc, (-W / 2 + gA) / 2, 0, fz); K.box(sides.front, W / 2 - gB, H, t, wc, (gB + W / 2) / 2, 0, fz); K.box(sides.front, doorW, H - doorH, t, wc, bd.lx, doorH, fz);
      K.box(sides.front, W + 0.1, 0.5, t + 0.25, trim, 0, 0, fz); K.box(sides.front, W + 0.2, 0.45, t + 0.3, trim, 0, H - 0.45, fz);
      wallRun(sides.back, -W / 2, W / 2, -D / 2 + t / 2);
      // sides: built along local z, so draw as rotated boxes
      for (const [bt, sx] of [[sides.left, -W / 2 + t / 2], [sides.right, W / 2 - t / 2]]) { K.box(bt, t, H, D, wc, sx, 0, 0); K.box(bt, t + 0.25, 0.5, D + 0.1, trim, sx, 0, 0); K.box(bt, t + 0.3, 0.45, D + 0.2, trim, sx, H - 0.45, 0); }
      solidLocal(bd, -W / 2, gA, D / 2 - t, D / 2); solidLocal(bd, gB, W / 2, D / 2 - t, D / 2); solidLocal(bd, -W / 2, W / 2, -D / 2, -D / 2 + t); solidLocal(bd, -W / 2, -W / 2 + t, -D / 2, D / 2); solidLocal(bd, W / 2 - t, W / 2, -D / 2, D / 2);
      // windows: front row either side of the door, side rows; a second row on tall buildings
      const rows = H >= 9.5 ? [2.3, Math.min(H - 2.8, 6.2)] : [2.3];
      const hk = [...b.key].reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) % 9973, 7), acc = ['#2f6d8a', '#2f8a7a', '#3a4f8a', '#8a3a3a', '#4a7a3a', '#b8742a'][hk % 6];   // each building's own shutter colour
      const winAt = (bt, x, y, z, ry2, w = 1.5, h = 1.7) => { K.boxC(bt, w + 0.3, h + 0.3, 0.12, trim, x, y + h / 2, z, ry2); for (const sd of [-1, 1]) { const o = sd * (w / 2 + 0.42); K.boxC(bt, 0.55, h + 0.1, 0.08, acc, x + Math.cos(ry2) * o + Math.sin(ry2) * 0.1, y + h / 2, z - Math.sin(ry2) * o + Math.cos(ry2) * 0.1, ry2); K.boxC(bt, 0.45, 0.06, 0.1, '#1f2a30', x + Math.cos(ry2) * o + Math.sin(ry2) * 0.14, y + h * 0.33, z - Math.sin(ry2) * o + Math.cos(ry2) * 0.14, ry2); K.boxC(bt, 0.45, 0.06, 0.1, '#1f2a30', x + Math.cos(ry2) * o + Math.sin(ry2) * 0.14, y + h * 0.7, z - Math.sin(ry2) * o + Math.cos(ry2) * 0.14, ry2); }   /* open painted shutters with louvre lines */ bt.add(GEO.halfTorus, trim, M4(x + Math.sin(ry2) * 0.04, y + h + 0.12, z + Math.cos(ry2) * 0.04, ry2, 0, 0, w / 2 + 0.05, w / 2 + 0.05, 0.5));   /* a round arch over every window (graphics polish) */ win.add(GEO.box, '#ffffff', M4(x + Math.sin(ry2) * 0.07, y + h / 2, z + Math.cos(ry2) * 0.07, ry2, 0, 0, w, h, 0.06)); };
      for (const y of rows) { for (let x = -W / 2 + 2.4; x < W / 2 - 1.8; x += 4.2) if (Math.abs(x - bd.lx) > doorW / 2 + 1.4 || y > doorH + 0.5) winAt(sides.front, x, y, D / 2 + 0.02, 0);
        for (let z = -D / 2 + 2.6; z < D / 2 - 2; z += 4.6) { winAt(sides.left, -W / 2 - 0.02, y, z, -Math.PI / 2); winAt(sides.right, W / 2 + 0.02, y, z, Math.PI / 2); } }
      // DESERT ARCHITECTURE (graphics polish): timber beam ends poking out under the parapet (toron) on all four sides, and corner buttresses
      { const by = H - 1.15, bm = '#5a3e26'; for (let x = -W / 2 + 1.1; x < W / 2 - 0.8; x += 1.9) { if (Math.abs(x - bd.lx) > Math.min(W * 0.3, 7)) K.box(sides.front, 0.2, 0.2, 0.7, bm, x, by, D / 2 + 0.15); K.box(sides.back, 0.2, 0.2, 0.7, bm, x, by, -D / 2 - 0.15); }
        for (let z = -D / 2 + 1.1; z < D / 2 - 0.8; z += 1.9) { K.box(sides.left, 0.7, 0.2, 0.2, bm, -W / 2 - 0.15, by, z); K.box(sides.right, 0.7, 0.2, 0.2, bm, W / 2 + 0.15, by, z); }
        for (const [cx2, cz2] of [[-W / 2, D / 2], [W / 2, D / 2], [-W / 2, -D / 2], [W / 2, -D / 2]]) { const bt2 = cz2 > 0 ? sides.front : sides.back; K.box(bt2, 0.9, H * 0.55, 0.9, wc, cx2 + Math.sign(cx2) * 0.15, 0, cz2 + Math.sign(cz2) * 0.15); K.box(bt2, 0.75, H * 0.28, 0.75, wc, cx2 + Math.sign(cx2) * 0.1, H * 0.55, cz2 + Math.sign(cz2) * 0.1); } }
      // the welcome at every door: two glazed pots with clipped bushes and two brass wall lanterns (they glow at night with the windows)
      for (const sd of [-1, 1]) { const px = bd.lx + sd * (doorW / 2 + 0.95), pz = D / 2 + 0.55; if (Math.abs(px) > W / 2 - 0.4) continue;
        K.cyl(deco, 0.38, 0.75, sd > 0 ? '#2f6d8a' : '#2f6d8a', px, 0, pz, 12); K.cyl(deco, 0.42, 0.1, PAL.brass, px, 0.72, pz, 12); K.sph(deco, 0.55, '#5f7f2e', px, 1.25, pz, 0.9); K.sph(deco, 0.36, '#6f8f36', px + 0.12, 1.65, pz - 0.05);
        K.box(deco, 0.12, 0.5, 0.3, PAL.ink, bd.lx + sd * (doorW / 2 + 0.45), doorH - 0.2, D / 2 + 0.15); K.box(glow, 0.36, 0.48, 0.36, '#ffcf7a', bd.lx + sd * (doorW / 2 + 0.45), doorH - 0.75, D / 2 + 0.42); K.cone(deco, 0.3, 0.3, PAL.brass, bd.lx + sd * (doorW / 2 + 0.45), doorH - 0.27, D / 2 + 0.42, 4, Math.PI / 4); { const [wx, wz] = toWorld(bd, bd.lx + sd * (doorW / 2 + 0.45), D / 2 + 1.2); lampPts.push([wx, 0, wz, 0.55]); } }
      // HOUSE VARIETY (graphics polish): a carved wooden mashrabiya bay on the upper front, an upper-floor room on some roofs, bougainvillea spilling over the parapet
      if (/^kufaHouse[124]$|^kufaHome$/.test(b.key)) { const side = bd.lx > 0 ? -1 : 1, mx = side * Math.min(W / 4, 4.2), my = Math.max(doorH + 0.6, H * 0.5);
        if (b.key !== 'kufaHome') { K.box(sides.front, 2.6, 2.2, 0.9, PAL.woodD, mx, my, D / 2 + 0.45); K.box(sides.front, 2.9, 0.2, 1.15, PAL.wood, mx, my + 2.2, D / 2 + 0.5); K.box(sides.front, 2.9, 0.25, 1.1, PAL.wood, mx, my - 0.25, D / 2 + 0.5);
          for (let i = 0; i < 7; i++) K.box(sides.front, 0.07, 1.9, 0.07, '#c49a62', mx - 1.15 + i * 0.38, my + 0.15, D / 2 + 0.93); for (let j = 0; j < 5; j++) K.box(sides.front, 2.5, 0.06, 0.07, '#c49a62', mx, my + 0.3 + j * 0.42, D / 2 + 0.93);
          for (const sx of [-1, 1]) K.box(sides.front, 0.18, 0.7, 0.5, PAL.woodD, mx + sx * 1.15, my - 0.7, D / 2 + 0.3, 0, -0.6); }
        if (b.key === 'kufaHouse1' || b.key === 'kufaHouse4') { const uw = W * 0.45, ud = D * 0.42, ux = -side * W * 0.22, uz = -D * 0.22; K.box(top, uw, 3.2, ud, wc, ux, H, uz); K.box(top, uw + 0.3, 0.35, ud + 0.3, trim, ux, H + 3.2, uz);
          for (let x = ux - uw / 2 + 1.2; x < ux + uw / 2 - 0.8; x += 2.2) { K.boxC(top, 1.0, 1.3, 0.1, '#3a4a52', x, H + 1.7, uz + ud / 2 + 0.03); K.boxC(top, 0.4, 1.3, 0.08, acc, x - 0.75, H + 1.7, uz + ud / 2 + 0.06); K.boxC(top, 0.4, 1.3, 0.08, acc, x + 0.75, H + 1.7, uz + ud / 2 + 0.06); }
          for (let x = ux - uw / 2 + 0.3; x <= ux + uw / 2 - 0.3; x += 1.5) K.box(top, 0.5, 0.45, 0.35, trim, x, H + 3.55, uz + ud / 2); }
        if (b.key === 'kufaHouse4' || b.key === 'kufaHome' || b.key === 'kufaHouse2') { const bx = side * (W / 2 - 2.2); for (let i = 0; i < 9; i++) { const yy = H + 0.6 - i * 0.42, xx = bx + Math.sin(i * 1.7) * 0.9; K.sph(deco, 0.5 - i * 0.03, i % 3 ? '#d6337a' : '#e05a96', xx, yy, D / 2 + 0.28, 0.8); if (i % 2) K.sph(deco, 0.32, '#4f7a2a', xx + 0.5, yy - 0.15, D / 2 + 0.22, 0.8); } } }
      // ROOFTOP LIFE (graphics polish): a stair hut, clay water jars and a washing line, picked per building so the skyline varies
      if (W * D > 60) { const rx0 = -W / 2 + 2.4, rz0 = -D / 2 + 2.4;
        if (hk % 2 === 0 && W > 9 && D > 9) { K.box(top, 2.4, 2.5, 2.4, wc, rx0 + 0.3, H, rz0 + 0.3); K.box(top, 2.7, 0.25, 2.7, trim, rx0 + 0.3, H + 2.5, rz0 + 0.3); K.box(top, 1.0, 1.9, 0.08, PAL.woodD, rx0 + 0.3, H, rz0 + 1.52); }
        if (hk % 5 !== 1) for (let i = 0; i < 3 + hk % 3; i++) { const jx = W / 2 - 1.6 - (i % 3) * 0.8, jz = -D / 2 + 1.6 + Math.floor(i / 3) * 0.8, rr = 0.32 + (i % 2) * 0.08; K.sph(top, rr, i % 2 ? '#b8603a' : '#c47a4a', jx, H + rr * 0.9, jz, 1.2); K.cyl(top, rr * 0.38, rr * 0.5, '#a0502e', jx, H + rr * 1.8, jz, 8); }
        if (hk % 3 === 0 && W > 10) { const lz = D / 2 - 2.6, la = -W / 2 + 1.4, lb = Math.min(W / 2 - 1.4, la + 9); K.cyl(top, 0.05, 2.2, PAL.woodD, la, H, lz, 6); K.cyl(top, 0.05, 2.2, PAL.woodD, lb, H, lz, 6); K.box(top, lb - la, 0.03, 0.03, '#efe6d2', (la + lb) / 2, H + 2.05, lz);
          ['#c42d3c', '#f6ecd6', '#2f6d9a', '#e6b45a', '#2f9a8f'].forEach((c, i) => { const cx3 = la + (lb - la) * (i + 0.7) / 5.4; K.box(top, 0.8, 0.9 + (i % 2) * 0.3, 0.03, c, cx3, H + 2.02 - 0.9 - (i % 2) * 0.3, lz); }); } }
      // INTERIOR polish for the rooms the world furnishes itself (not the repo game rooms): a glazed tile dado with a brass rail, a checker
      // tile floor with a border, dark ceiling beams and a few arched wall niches. Drawn only when you are inside (the inner batch).
      if (!b.fit) { const ix0 = -W / 2 + t, ix1 = W / 2 - t, iz0 = -D / 2 + t, iz1 = D / 2 - t, dado = ['#2f6d8a', '#2f8a7a', '#8a3a3a', '#3a4f8a'][(b.key.length + Math.round(W)) % 4], dh = 1.15;
        const along = (x0, x1, z, fn) => { if (z > 0) { if (bd.lx - doorW / 2 - 0.2 > x0) fn(x0, bd.lx - doorW / 2 - 0.2); if (x1 > bd.lx + doorW / 2 + 0.2) fn(bd.lx + doorW / 2 + 0.2, x1); } else fn(x0, x1); };
        for (const z of [iz0 + 0.03, iz1 - 0.03]) along(ix0, ix1, z, (a, c) => { K.box(inner, c - a, dh, 0.06, dado, (a + c) / 2, 0.08, z); K.box(inner, c - a, 0.1, 0.12, PAL.brass, (a + c) / 2, dh + 0.08, z); });
        for (const x of [ix0 + 0.03, ix1 - 0.03]) { K.box(inner, 0.06, dh, iz1 - iz0, dado, x, 0.08, (iz0 + iz1) / 2); K.box(inner, 0.12, 0.1, iz1 - iz0, PAL.brass, x, dh + 0.08, (iz0 + iz1) / 2); }
        const ts = W * D > 300 ? 1.6 : 1.2, nx = Math.floor((ix1 - ix0 - 1.2) / ts), nz = Math.floor((iz1 - iz0 - 1.2) / ts), ox = -nx * ts / 2, oz = -nz * ts / 2, tA = '#e8d6b0', tB = '#c9ad7e';
        K.quad(inner, ix1 - ix0 - 0.2, iz1 - iz0 - 0.2, '#8a5a3a', 0, 0.08, 0);   // the floor's border band
        for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) K.quad(inner, ts - 0.04, ts - 0.04, (i + j) % 2 ? tA : tB, ox + (i + 0.5) * ts, 0.085, oz + (j + 0.5) * ts);
        for (let x = ix0 + 1.6; x < ix1 - 0.8; x += 2.6) K.box(inner, 0.26, 0.18, iz1 - iz0, PAL.woodD, x, ceil - 0.18, (iz0 + iz1) / 2);   /* thin, tight to the ceiling: the indoor camera stays below them */   // ceiling beams
        for (const x of [ix0 + 0.06, ix1 - 0.06]) for (let z = iz0 + 2.4; z < iz1 - 2.4; z += 4.6) { K.box(inner, 0.08, 1.2, 0.9, '#7a5a3a', x, dh + 0.5, z); inner.add(GEO.halfTorus, PAL.brass, M4(x, dh + 1.7, z, Math.PI / 2, 0, 0, 0.5, 0.5, 0.35)); } }
      // roof slab + parapet (styles add domes, terraces…)
      K.box(top, W - 0.2, 0.5, D - 0.2, PAL.stoneD, 0, H - 0.5, 0); K.box(top, W, 0.9, 0.35, trim, 0, H, D / 2 - 0.17); K.box(top, W, 0.9, 0.35, trim, 0, H, -D / 2 + 0.17); K.box(top, 0.35, 0.9, D, trim, -W / 2 + 0.17, H, 0); K.box(top, 0.35, 0.9, D, trim, W / 2 - 0.17, H, 0);
      // stepped merlons along the parapet (the Kufa skyline; graphics polish) — skipped where the front's roof sign stands
      { const mw = 0.62, gap = 1.7; for (const [len, along, at, rot] of [[W, 'x', D / 2 - 0.17, 0], [W, 'x', -D / 2 + 0.17, 0], [D, 'z', -W / 2 + 0.17, 1], [D, 'z', W / 2 - 0.17, 1]]) { const n = Math.max(2, Math.floor((len - 0.6) / gap));
        for (let i = 0; i <= n; i++) { const u = -len / 2 + 0.3 + i * (len - 0.6) / n, x = along === 'x' ? u : at, z = along === 'x' ? at : u; if (along === 'x' && at > 0 && Math.abs(u) < Math.min(W * 0.3, 7)) continue;
          K.box(top, rot ? 0.42 : mw, 0.5, rot ? mw : 0.42, trim, x, H + 0.9, z); K.box(top, rot ? 0.42 : mw * 0.5, 0.26, rot ? mw * 0.5 : 0.42, trim, x, H + 1.4, z); } } }
      if (ceil < H - 0.8) K.box(top, W - 0.8, 0.3, D - 0.8, '#efe3c8', 0, ceil, 0);
      // interior (phase 2: an empty, lit room + a plaque saying what comes in phase 3)
      K.quad(inner, W - 2 * t, D - 2 * t, { tile: '#d9c39a', wood: '#a87a4a', sand: '#e2c995', grass: '#7f9a46' }[room.floor] || '#cdb894', 0, 0.075, 0);
      for (const [lx, lz] of [[-W / 4, -D / 4], [W / 4, -D / 4], [-W / 4, D / 5], [W / 4, D / 5]]) { K.box(inner, 0.08, 0.8, 0.08, PAL.ink, lx, ceil - 0.8, lz); K.box(innerGlow, 0.7, 0.5, 0.7, '#ffd890', lx, ceil - 1.3, lz); }
      rooms.push({ key: b.key, bd, inner: [-W / 2 + t, W / 2 - t, -D / 2 + t, D / 2 - t], ceil });
    }
    // ---- per-building UNIQUE outsides (from the layout "outside" notes) ----
    const F = D / 2, top0 = H + 0.45, X = bd.lx;
    const porchCols = (n, w, h, z, c = PAL.stone) => { for (let i = 0; i < n; i++) { const x = -w / 2 + w * i / (n - 1); if (Math.abs(x - X) < doorW / 2 + 0.6) continue; K.cyl(deco, 0.38, h, c, x, 0, z, 10); K.box(deco, 1, 0.4, 1, trim, x, h, z); } K.box(deco, w + 1.4, 0.8, F + 0.1 > 0 ? 3.6 : 3, trim, 0, h + 0.4, z - 1.6); };
    switch (b.key) {
      case 'kufaTavern': // two-storey caravanserai front, arched porch on 4 columns, striped awning, roof terrace with lanterns, brass backgammon board over the door
        porchCols(4, Math.min(W - 4, 14), 4.6, F + 3.2); K.awning(deco, Math.min(W - 2, 16), 1.6, 0.8, X, 5.9, F + 3.6, [PAL.terra, PAL.cream]);
        for (let x = -W / 2 + 2; x <= W / 2 - 2; x += 3.2) { K.box(top, 0.12, 2.2, 0.12, PAL.woodD, x, top0, D / 2 - 1); K.box(glow, 0.36, 0.44, 0.36, '#ffb347', x, top0 + 1.6, D / 2 - 1); }
        K.box(top, W - 1, 0.1, 0.1, PAL.woodD, 0, top0 + 2.1, D / 2 - 1); K.box(deco, 3.4, 2.2, 0.2, PAL.brass, X, doorH + 1.0, F + 0.25); for (let i = 0; i < 6; i++) { K.cone(deco, 0.22, 0.9, i % 2 ? PAL.red : PAL.ink, X - 1.35 + i * 0.54, doorH + 2.1, F + 0.38, 4); }
        break;
      case 'kufaArmory': // squat thick forge: brass-studded double doors, tall smoking chimney with glowing vent, crossed halberds
        { const pt = 0.8, gA = X - doorW / 2 - 0.1, gB = X + doorW / 2 + 0.1; K.box(deco, W + 0.8, 1.6, pt, PAL.stoneD, 0, 0, -D / 2 - 0.4 + pt / 2); K.box(deco, pt, 1.6, D + 0.8, PAL.stoneD, -W / 2 - 0.4 + pt / 2, 0, 0); K.box(deco, pt, 1.6, D + 0.8, PAL.stoneD, W / 2 + 0.4 - pt / 2, 0, 0);   // the forge's thick plinth: a hollow ring (it filled the room before), open at the doors
          K.box(deco, gA + W / 2 + 0.4, 1.6, pt, PAL.stoneD, (-W / 2 - 0.4 + gA) / 2, 0, D / 2 + 0.4 - pt / 2); K.box(deco, W / 2 + 0.4 - gB, 1.6, pt, PAL.stoneD, (gB + W / 2 + 0.4) / 2, 0, D / 2 + 0.4 - pt / 2); } K.cyl(top, 1.3, 9, '#7a5a3a', W / 2 - 2.5, top0 - 0.4, -D / 2 + 2.5, 12); K.box(glow, 1.1, 0.9, 0.2, '#ff6a2a', W / 2 - 2.5, top0 + 2, -D / 2 + 3.75);
        for (const s of [-1, 1]) { K.box(deco, 0.18, 4.4, 0.18, PAL.woodD, X + s * 1.4, doorH + 0.3, F + 0.3, 0, 0, s * 0.6); K.cone(deco, 0.35, 0.9, PAL.steel, X + s * 2.65, doorH + 4.0, F + 0.3, 4); }
        for (let i = 0; i < 6; i++) K.sph(deco, 0.12, PAL.brass, X - 2.3 + i * 0.92, doorH + 0.25, F + 0.25); break;
      case 'kufaItemShop': // narrow shopfront under a cream awning, jar + canteen window, hanging brass scale sign
        K.awning(deco, W - 1, 2.4, 0.9, 0, 4.6, F + 0.2, [PAL.cream, '#e8d6b0']); for (let i = 0; i < 5; i++) { K.sph(deco, 0.35, PAL.terra, -W / 2 + 2 + i * 1.1, 1.45, F + 0.4, 1.2); }
        K.box(deco, 0.1, 1.1, 0.1, PAL.ink, X + 3.2, 3.7, F + 1.2); K.box(deco, 1.6, 0.08, 0.08, PAL.brass, X + 3.2, 3.7, F + 1.2); for (const s of [-1, 1]) K.cyl(deco, 0.35, 0.08, PAL.brass, X + 3.2 + s * 0.75, 3.1, F + 1.2, 12); break;
      case 'kufaSpyShop': // plainest front: dark shutters, one small brass eye over the door, a fake BOOKS sign
        for (let x = -W / 2 + 1.6; x < W / 2 - 1; x += 3) if (Math.abs(x - X) > 3) K.box(deco, 1.8, 2, 0.15, '#3a3230', x, 1.6, F + 0.1); K.sph(deco, 0.32, PAL.brass, X, doorH + 0.6, F + 0.25, 0.6); K.sph(deco, 0.14, PAL.ink, X, doorH + 0.6, F + 0.42, 0.8);
        signBoard(grp, ['BOOKS'], 0.8, 4, 0, H - 2.2, F + 0.12, { bg: '#5a4a3a', rim: '#3a3230' }, deco); break;
      case 'kufaCreamery': // mint + white plaster, a scoop-of-ice-cream dome roof, frosty glass front, a big cone on top; ice-cream terrace beside it
        K.dome(top, Math.min(W, D) * 0.48, PAL.white, 0, top0 - 0.2, 0, 0.75); K.dome(top, Math.min(W, D) * 0.36, '#f4b6c8', 0, top0 + 0.6, 0, 0.6);
        K.cone(top, 1.1, 3.2, '#d9a35a', 0, top0 + 2.0, 0, 8); top.add(GEO.cone8, '#d9a35a', M4(0, top0 + 3.0, 0, 0, Math.PI, 0, 2.2, 3.2, 2.2)); K.sph(top, 1.2, '#f7f2e8', 0, top0 + 4.9, 0); K.sph(top, 1.0, '#9ad6c0', 0, top0 + 5.9, 0); K.sph(top, 0.25, PAL.red, 0, top0 + 6.9, 0);
        K.box(deco, 5.4, 2.2, 0.1, '#d8f2ec', -2.4, 0.9, F + 0.08); K.awning(deco, 8, 1.4, 0.5, -1.5, 3.8, F + 0.1, [PAL.mint, PAL.white]);
        for (const [x, z] of [[W / 2 + 4, -2], [W / 2 + 4, 2.5], [W / 2 + 8.5, 0.2]]) { K.cyl(deco, 0.7, 0.9, PAL.white, x, 0, z, 12); K.cyl(deco, 0.08, 2.6, PAL.ink, x, 0.9, z, 6); K.cone(deco, 1.6, 0.9, z > 0 ? PAL.mint : '#f4b6c8', x, 3.3, z, 8); } break;
      case 'kufaBank': // columned sandstone front, stepped roof, giant brass water drop over the door, carved jar reliefs
        porchCols(5, W - 4, 6.4, F + 2.6, PAL.cream); K.box(top, W - 3, 1.2, D - 3, PAL.stone, 0, top0, 0); K.box(top, W - 7, 1.2, D - 7, PAL.stoneD, 0, top0 + 1.2, 0);
        K.sph(deco, 1.0, PAL.brass, X, 8.1, F + 2.8, 1.1); K.cone(deco, 0.86, 1.4, PAL.brass, X, 8.6, F + 2.8, 12); for (let x = -W / 2 + 1.5; x < W / 2 - 1; x += 2.2) K.sph(deco, 0.32, PAL.stoneD, x, H - 1.2, F + 0.22, 1.3); break;
      case 'kufaPost': // pale stone, small clock tower + Meru flag, red mail box by the door, Galactic Post antenna dish
        K.box(top, 3.6, 6, 3.6, PAL.cream, -W / 2 + 3, top0 - 0.4, -D / 2 + 3); K.cyl(top, 1.2, 0.2, PAL.white, -W / 2 + 3, top0 + 3.6, -D / 2 + 4.82, 16, Math.PI / 2); K.box(top, 0.1, 0.9, 0.1, PAL.ink, -W / 2 + 3, top0 + 3.5, -D / 2 + 4.95); K.cone(top, 2.4, 2, PAL.terra, -W / 2 + 3, top0 + 5.6, -D / 2 + 3, 4, Math.PI / 4);
        K.cyl(top, 0.06, 4, PAL.ink, -W / 2 + 3, top0 + 7.4, -D / 2 + 3, 6); K.box(top, 1.8, 1.1, 0.06, '#7a5ab8', -W / 2 + 3.95, top0 + 10.6, -D / 2 + 3); K.dome(top, 2, PAL.white, W / 2 - 4, top0 + 1.6, -D / 2 + 4, 0.35); K.cyl(top, 0.2, 1.6, PAL.steel, W / 2 - 4, top0, -D / 2 + 4, 8);
        K.box(deco, 0.9, 1.4, 0.7, PAL.red, X + 3.2, 0, F + 0.7); K.box(deco, 1.0, 0.2, 0.8, PAL.ink, X + 3.2, 1.4, F + 0.7); break;
      case 'kufaWatchHouse': // low fort: crenellations, blue lamp over the door, a lookout turret, barred windows
        for (let x = -W / 2 + 0.7; x < W / 2; x += 1.6) { K.box(top, 0.8, 1.1, 0.5, PAL.stoneD, x, top0, D / 2 - 0.25); K.box(top, 0.8, 1.1, 0.5, PAL.stoneD, x, top0, -D / 2 + 0.25); }
        K.cyl(top, 2.2, 5, bd.wall, W / 2 - 2.2, top0 - 0.5, D / 2 - 2.2, 12); for (let a = 0; a < 8; a++) K.box(top, 0.7, 1, 0.7, PAL.stoneD, W / 2 - 2.2 + Math.cos(a * 0.785) * 2, top0 + 4.5, D / 2 - 2.2 + Math.sin(a * 0.785) * 2);
        K.box(glow, 1.0, 0.7, 0.5, '#3a8aff', X, doorH + 0.5, F + 0.35); break;
      case 'kufaFireStation': // red hall, wide roll-up bay, sand-rescue buggy out front, bell tower with a siren
        K.box(deco, 7, 4.8, 0.2, '#e8e0d0', X > 0 ? -W / 2 + 4.5 : W / 2 - 4.5, 0, F + 0.12); for (let y = 0.4; y < 4.6; y += 0.5) K.box(deco, 6.8, 0.06, 0.06, '#b0a898', X > 0 ? -W / 2 + 4.5 : W / 2 - 4.5, y, F + 0.25);
        { const bx = X > 0 ? -W / 2 + 4.5 : W / 2 - 4.5, bz = F + 4.4; K.box(deco, 2.6, 1.0, 4.2, PAL.red, bx, 0.7, bz); K.box(deco, 2.2, 0.9, 1.8, '#333', bx, 1.7, bz - 0.4); for (const [a, c] of [[-1.3, -1.3], [1.3, -1.3], [-1.3, 1.3], [1.3, 1.3]]) K.cyl(deco, 0.55, 0.45, PAL.ink, bx + a, 0.55, bz + c, 10, 0, Math.PI / 2); K.box(glow, 0.9, 0.25, 0.4, '#3a8aff', bx, 2.7, bz - 0.4); }
        K.box(top, 3, 5, 3, '#a8442e', W / 2 - 2.5, top0 - 0.4, -D / 2 + 2.5); K.cone(top, 2.4, 1.8, PAL.ink, W / 2 - 2.5, top0 + 4.6, -D / 2 + 2.5, 4, Math.PI / 4); K.sph(top, 0.7, PAL.brass, W / 2 - 2.5, top0 + 3.6, -D / 2 + 2.5); K.box(glow, 0.5, 0.5, 0.5, '#ff3a2a', W / 2 - 2.5, top0 + 6.6, -D / 2 + 2.5); break;
      case 'kufaCrier': // tall thin tower with a wrap balcony, radio mast + dish, news ticker under the roof sign
        K.box(top, W * 0.45, 9, D * 0.45, bd.wall, 0, top0 - 0.4, -D * 0.1); K.box(top, W * 0.45 + 2.4, 0.3, D * 0.45 + 2.4, PAL.woodD, 0, top0 + 4.2, -D * 0.1); for (let a = 0; a < 16; a++) { const r = 1, xx = (a % 4 - 1.5) / 1.5 * (W * 0.225 + 1.1), zz = (Math.floor(a / 4) - 1.5) / 1.5 * (D * 0.225 + 1.1); if (Math.abs(xx) > W * 0.2 + 0.8 || Math.abs(zz) > D * 0.2 + 0.8) K.box(top, 0.1, 1.1, 0.1, PAL.ink, xx, top0 + 4.5, zz - D * 0.1); }
        K.cyl(top, 0.12, 9, PAL.steel, 0, top0 + 8.6, -D * 0.1, 6); K.sph(glow, 0.3, '#ff3a2a', 0, top0 + 13.2, -D * 0.1); K.dome(top, 1.4, PAL.white, 1.8, top0 + 9.2, -D * 0.1, 0.35);
        K.box(glow, W - 3, 0.7, 0.1, '#ffd23a', 0, H - 1.6, F + 0.18); break;
      case 'kufaHospital': // white plaster, blue trim, inner courtyard palm, red cross on the roof
        K.box(deco, W + 0.2, 0.5, 0.12, '#3a6ea5', 0, H - 1.1, D / 2 + 0.06); K.box(deco, W + 0.2, 0.5, 0.12, '#3a6ea5', 0, H - 1.1, -D / 2 - 0.06); K.box(deco, 0.12, 0.5, D + 0.2, '#3a6ea5', -W / 2 - 0.06, H - 1.1, 0); K.box(deco, 0.12, 0.5, D + 0.2, '#3a6ea5', W / 2 + 0.06, H - 1.1, 0);   /* blue band round the walls (it was a solid slab through the rooms) */ K.box(top, 6, 0.3, 1.6, PAL.red, 0, top0, 0); K.box(top, 1.6, 0.3, 6, PAL.red, 0, top0, 0);
        K.box(top, 6, 2.4, 6, '#d8e8f0', -W / 4, top0 - 0.2, -D / 4); K.awning(deco, 6, 1.6, 0.6, X, 4.4, F + 0.1, ['#3a6ea5', PAL.white]); break;
      case 'kufaHome': // courtyard house: blank outer walls, carved wooden door, roof terrace with striped shade sail + plants
        K.box(deco, 4.4, doorH + 0.6, 0.2, PAL.woodD, X, 0, F + 0.05); for (let i = 0; i < 5; i++) K.box(deco, 0.12, doorH, 0.24, PAL.brass, X - 1.6 + i * 0.8, 0.2, F + 0.12);
        for (const [a, b2] of [[-W / 2 + 2, -D / 2 + 2], [W / 2 - 2, -D / 2 + 2], [-W / 2 + 2, D / 2 - 2], [W / 2 - 2, D / 2 - 2]]) K.box(top, 0.14, 3, 0.14, PAL.woodD, a, top0, b2); for (let i = 0; i < 6; i++) K.box(top, (W - 4) / 6, 0.06, D - 4, i % 2 ? PAL.cream : PAL.teal, -W / 2 + 2 + (W - 4) / 6 * (i + 0.5), top0 + 2.9, 0);
        for (let i = 0; i < 4; i++) { K.box(top, 0.8, 0.6, 0.8, PAL.terra, -W / 2 + 3 + i * 2.2, top0, D / 2 - 1.4); K.sph(top, 0.6, PAL.palm, -W / 2 + 3 + i * 2.2, top0 + 1, D / 2 - 1.4); } break;
      case 'kufaHouse1': K.cyl(top, 1.2, 2, '#c8d0d6', W / 4, top0, -D / 4, 12); K.box(deco, 2.2, doorH, 0.15, '#2f6d9a', X, 0, F + 0.06); break;
      case 'kufaHouse2': K.box(top, 2.4, 5, 2.4, bd.wall, -W / 4, top0, 0); K.box(top, 2.6, 1.3, 0.2, PAL.ink, -W / 4, top0 + 3.6, 1.2); K.box(top, 2.6, 1.3, 0.2, PAL.ink, -W / 4, top0 + 3.6, -1.2); K.box(deco, 2.2, doorH, 0.15, '#3f8a4a', X, 0, F + 0.06); break;
      case 'kufaHouse3': K.box(deco, 6, 2.6, 1.4, PAL.woodD, X > 0 ? -W / 4 : W / 4, 5.2, F + 0.7); for (let i = 0; i < 9; i++) K.box(deco, 0.08, 2.2, 0.08, PAL.wood, (X > 0 ? -W / 4 : W / 4) - 2.6 + i * 0.65, 5.4, F + 1.42); K.box(deco, 2.2, doorH, 0.15, PAL.red, X, 0, F + 0.06); break;
      case 'kufaHouse4': K.dome(top, 2.6, PAL.white, W / 5, top0, 0, 0.8); for (const s of [-1, 1]) K.box(top, 0.1, 2.4, 0.1, PAL.woodD, s * (W / 2 - 1.5), top0, -D / 3); K.box(top, W - 3, 0.04, 0.04, PAL.ink, 0, top0 + 2.2, -D / 3); for (let i = 0; i < 6; i++) K.box(top, 0.8, 1, 0.04, [PAL.red, PAL.teal, PAL.cream][i % 3], -W / 2 + 3 + i * 1.6, top0 + 1.2, -D / 3); K.box(deco, 2.2, doorH, 0.15, '#e8c35a', X, 0, F + 0.06); break;
      case 'kufaWeapons': // dark bronze front, weapon-rack shutters, huge crossed sword + laser sign
        { const gA = X - doorW / 2, gB = X + doorW / 2; K.box(deco, gA + W / 2 + 0.05, H - 0.6, 0.15, '#6a4a2a', (-W / 2 - 0.05 + gA) / 2, 0, F + 0.04); K.box(deco, W / 2 + 0.05 - gB, H - 0.6, 0.15, '#6a4a2a', (gB + W / 2 + 0.05) / 2, 0, F + 0.04); K.box(deco, doorW, H - 0.6 - doorH, 0.15, '#6a4a2a', X, doorH, F + 0.04); }   /* bronze front with the doorway left open */ for (let x = -W / 2 + 2; x < W / 2 - 1; x += 2.6) if (Math.abs(x - X) > 3.3) { K.box(deco, 2, 3, 0.25, PAL.woodD, x, 0.8, F + 0.35); for (let k = 0; k < 3; k++) K.box(deco, 0.1, 2.4, 0.1, PAL.steel, x - 0.6 + k * 0.6, 1.1, F + 0.55); }
        K.boxC(top, 0.5, 9, 0.3, PAL.steel, -1.2, top0 + 5.3, D / 2 - 1, 0, 0, 0.6); K.boxC(top, 2.4, 0.45, 0.45, PAL.brass, -0.35, top0 + 4.06, D / 2 - 1, 0, 0, 0.6); K.boxC(glow, 0.35, 9, 0.2, '#ff2a6a', 1.2, top0 + 5.3, D / 2 - 1, 0, 0, -0.6); K.boxC(top, 2.4, 0.45, 0.45, PAL.ink, 0.35, top0 + 4.06, D / 2 - 1, 0, 0, -0.6); break;
      case 'kufaRelicShop': { // brass dome + a giant spinning ASTROLABE (slow turn), star-cut shutters
        K.dome(top, Math.min(W, D) * 0.4, PAL.brass, 0, top0 - 0.2, 0, 0.8); const a = new THREE.Group(); a.position.set(0, top0 + Math.min(W, D) * 0.32 + 3.4, 0); grp.add(a); const ab = new Batch(); K.ring(ab, 3.2, PAL.brass, 0, 0, 0, false); ab.add(GEO.torus, PAL.brassD, M4(0, 0, 0, Math.PI / 2, 0, 0, 5.2, 5.2, 5.2)); ab.add(GEO.torus, PAL.brass, M4(0, 0, 0, 0, Math.PI / 2, 0, 4.4, 4.4, 4.4)); K.sph(ab, 0.5, '#ffd23a', 0, 0, 0); K.box(ab, 0.2, 6.6, 0.2, PAL.ink, 0, -3.3, 0); a.add(ab.mesh()); spinners.push({ o: a, sp: 0.35 });
        for (let x = -W / 2 + 2; x < W / 2 - 1; x += 3) if (Math.abs(x - X) > 3.2) { K.box(deco, 2, 2.4, 0.15, '#3a2a5a', x, 1.4, F + 0.1); for (let k = 0; k < 4; k++) K.box(glow, 0.18, 0.18, 0.05, '#ffe7a3', x - 0.6 + (k % 2) * 1.1, 1.8 + Math.floor(k / 2) * 1.2, F + 0.2, 0, 0, 0.785); } break; }
      case 'kufaDominoes': { // small club with an ARCADE PORCH, domino tables outside, a giant domino tile roof sign
        for (const s of [-1, 1]) { K.arch(deco, 3.2, 4.2, PAL.stone, X + s * 4.4, 0, F + 2.6, 0, 0.5); K.awning(deco, 3.6, 1.6, 0.5, X + s * 4.4, 4.0, F + 0.1, [PAL.terra, PAL.cream]); K.box(deco, 1.6, 0.9, 1.6, PAL.wood, X + s * 4.4, 0, F + 4.6); K.box(deco, 1.5, 0.05, 1.5, '#2a5a3a', X + s * 4.4, 0.92, F + 4.6); for (const c of [-1, 1]) K.box(deco, 0.6, 0.5, 0.6, PAL.woodD, X + s * 4.4 + c * 1.3, 0, F + 4.6); }
        const tile = new THREE.Group(); tile.position.set(0, top0 + 3.2, 0); tile.rotation.z = 0.18; grp.add(tile); const tb = new Batch(); K.boxC(tb, 3, 5.6, 0.7, PAL.white, 0, 0, 0); K.boxC(tb, 3.05, 0.12, 0.75, PAL.ink, 0, 0, 0); for (const [a, b2] of [[-0.7, 1.9], [0.7, 1.9], [0, 1.4], [-0.7, 0.9], [0.7, 0.9], [-0.7, -1.0], [0.7, -1.9], [0, -1.4]]) K.sph(tb, 0.24, PAL.ink, a, b2, 0.36, 0.4); tile.add(tb.mesh()); spinners.push({ o: tile, sp: 0.25 }); break; }
      case 'kufaWagonHire': // open garage shed, corrugated roof, buggies + a camel cart out front, tyre stack
        for (let i = 0; i < 10; i++) K.box(top, W / 10 - 0.1, 0.25, D + 1, i % 2 ? '#8a8f94' : '#a8adb2', -W / 2 + W / 10 * (i + 0.5), top0 - 0.1, 0); for (const [x, c] of [[-W / 2 + 4, '#e8c35a'], [W / 2 - 4, '#2f9a8f']]) { K.box(deco, 2.4, 0.9, 3.8, c, x, 0.7, F + 4.5); for (const [a, b2] of [[-1.2, -1.2], [1.2, -1.2], [-1.2, 1.2], [1.2, 1.2]]) K.cyl(deco, 0.55, 0.5, PAL.ink, x + a, 0.55, F + 4.5 + b2, 10, 0, Math.PI / 2); K.box(deco, 2, 0.12, 1.4, PAL.ink, x, 2.2, F + 4.0); }
        for (let i = 0; i < 4; i++) K.cyl(deco, 0.6, 0.35, PAL.ink, X + 3.2, 0.35 * i, F + 1.2, 12); break;
      case 'kufaOstrichStable': // reed + timber stable, tall feathered weather vane, ostriches over the half doors
        for (let x = -W / 2 + 0.3; x < W / 2; x += 0.6) K.box(deco, 0.25, H - 0.6, 0.2, '#c8a86a', x, 0.3, F + 0.12); for (let x = -W / 2 + 3; x < W / 2 - 2; x += 4) if (Math.abs(x - X) > 3.5) { K.box(deco, 2.6, 1.4, 0.2, PAL.woodD, x, 0, F + 0.3); K.cyl(deco, 0.12, 1.8, '#f0d0b8', x, 1.4, F + 0.8, 6); K.sph(deco, 0.3, '#f0d0b8', x, 3.3, F + 1.0); K.sph(deco, 0.8, PAL.ink, x, 1.5, F + 0.3, 0.8); }
        K.box(top, 0.12, 6, 0.12, PAL.ink, 0, top0, 0); K.box(top, 2.6, 0.6, 0.1, PAL.ink, 0.6, top0 + 5.6, 0); for (let i = 0; i < 4; i++) K.box(top, 0.12, 1.3, 0.06, [PAL.red, PAL.white, PAL.ink, PAL.brass][i], -0.9 + i * 0.3, top0 + 5.9, 0, 0, 0, 0.3 - i * 0.2); break;
      case 'kufaBarracks': // long fortified block with arrow slits, a training yard behind a low wall, the Emir's banner on a pole
        for (let x = -W / 2 + 1.5; x < W / 2 - 1; x += 2.4) K.box(deco, 0.25, 1.6, 0.1, PAL.ink, x, H - 3.2, F + 0.22); for (let x = -W / 2 + 0.7; x < W / 2; x += 1.6) K.box(top, 0.8, 1.1, 0.5, PAL.stoneD, x, top0, D / 2 - 0.25);
        K.box(deco, W, 1.6, 0.6, bd.wall, 0, 0, -D / 2 - 10); K.box(deco, 0.6, 1.6, 10, bd.wall, -W / 2 + 0.3, 0, -D / 2 - 5); K.box(deco, 0.6, 1.6, 10, bd.wall, W / 2 - 0.3, 0, -D / 2 - 5); for (let i = 0; i < 3; i++) { K.box(deco, 0.25, 1.8, 0.25, PAL.woodD, -W / 4 + i * W / 4, 0, -D / 2 - 5); K.sph(deco, 0.45, PAL.cream, -W / 4 + i * W / 4, 2.0, -D / 2 - 5); }
        K.cyl(deco, 0.12, 12, PAL.ink, W / 2 + 2, 0, F + 1, 6); K.box(deco, 0.06, 2.4, 3.6, PAL.red, W / 2 + 2, 9, F + 2.9); K.box(deco, 0.08, 0.6, 1.2, PAL.brass, W / 2 + 2, 10, F + 2.6); break;
      case 'kufaFoxFarm': // mud-brick farmhouse among the date palms, a water wheel + channel, drying racks of dates
        K.box(top, W * 0.55, 3, D * 0.6, bd.wall, -W / 5, top0 - 0.2, -D / 6); { const wh = new THREE.Group(); wh.position.set(W / 2 + 3, 3.4, F - 3); wh.rotation.y = Math.PI / 2; grp.add(wh); const wb = new Batch(); K.ring(wb, 3.2, PAL.wood, 0, 0, 0, false); for (let i = 0; i < 8; i++) K.boxC(wb, 0.2, 6.2, 0.6, PAL.woodD, 0, 0, 0, 0, 0, i * 0.39); wh.add(wb.mesh()); spinners.push({ o: wh, sp: 0.6, axis: 'z' }); }
        K.box(deco, 1.6, 0.6, 24, '#8a6a44', W / 2 + 3, 0, F + 8); K.box(deco, 1.0, 0.05, 24, '#3aa7a0', W / 2 + 3, 0.55, F + 8);
        for (let i = 0; i < 3; i++) { const x = -W / 2 - 3, z = -D / 3 + i * 5; K.box(deco, 0.2, 2.2, 0.2, PAL.woodD, x, 0, z - 1.8); K.box(deco, 0.2, 2.2, 0.2, PAL.woodD, x, 0, z + 1.8); for (let k = 0; k < 3; k++) K.box(deco, 1.2, 0.1, 3.8, '#7a3a1a', x, 0.6 + k * 0.6, z); } break;
      case 'kufaThroneRoom': { // the grandest: tall hall, gold onion dome, 2 minarets, red + brass K crest over the arched gate, banners
        K.onion(top, Math.min(W, D) * 0.22, '#e6b45a', 0, top0 - 0.6, -D * 0.08); K.cyl(top, Math.min(W, D) * 0.2, 3, bd.wall, 0, top0 - 0.6, -D * 0.08, 20); K.cone(top, 0.5, 4, PAL.brass, 0, top0 + Math.min(W, D) * 0.58, -D * 0.08, 8);
        for (const s of [-1, 1]) { const mx = s * (W / 2 - 2.5), mz = D / 2 - 2.5; K.cyl(top, 2, 16, bd.wall, mx, top0 - 0.6, mz, 12); K.cyl(top, 2.6, 0.6, PAL.stoneD, mx, top0 + 10, mz, 12); K.onion(top, 1.6, PAL.brass, mx, top0 + 15.2, mz); K.cone(top, 0.3, 2.4, PAL.brass, mx, top0 + 17.2, mz, 8); for (let k = 0; k < 4; k++) K.box(glow, 0.6, 1, 0.1, '#ffcf7a', mx + Math.sin(k * 1.57) * 2.02, top0 + 6, mz + Math.cos(k * 1.57) * 2.02, k * 1.57); }
        K.arch(deco, doorW + 2.4, doorH + 3.2, PAL.stoneD, X, 0, F + 0.4, 0, 0.9); K.cyl(deco, 2.3, 0.4, PAL.brass, X, doorH + 4.8, F + 0.25, 20, Math.PI / 2); K.cyl(deco, 1.9, 0.5, PAL.red, X, doorH + 4.8, F + 0.35, 20, Math.PI / 2);
        for (const s of [-1, 1]) for (const k of [1, 2]) { K.box(deco, 2, 6, 0.1, PAL.red, X + s * (doorW / 2 + 2.2 + k * 3.2), H - 7.8, F + 0.25); K.box(deco, 2, 0.6, 0.12, PAL.brass, X + s * (doorW / 2 + 2.2 + k * 3.2), H - 2.2, F + 0.27); }
        break; }
    }
    // ---- special types
    if (bd.type === 'yard') { // UMMI'S CAMEL PEN: mud-brick yard wall, wide wooden gate (open), shade tent, wagons, camel-head sign
      const wh = 3.2, gA = bd.lx - 3, gB = bd.lx + 3, fz = D / 2 - 0.3;
      K.box(sides.front, gA + W / 2, wh, 0.6, bd.wall, (-W / 2 + gA) / 2, 0, fz); K.box(sides.front, W / 2 - gB, wh, 0.6, bd.wall, (gB + W / 2) / 2, 0, fz);
      K.box(sides.back, W, 0.9, 0.6, bd.wall, 0, 0, -D / 2 + 0.3); K.box(sides.left, 0.6, wh, D, bd.wall, -W / 2 + 0.3, 0, 0); K.box(sides.right, 0.6, wh, D, bd.wall, W / 2 - 0.3, 0, 0);
      for (const s of [-1, 1]) { K.box(deco, 0.7, 4.4, 0.7, PAL.woodD, bd.lx + s * 3.2, 0, fz); K.box(deco, 2.6, 2.4, 0.15, PAL.wood, bd.lx + s * 4.4, 0.3, fz + 1.2, s * 0.9); }
      K.box(deco, 7, 0.4, 0.4, PAL.woodD, bd.lx, 4.2, fz); for (let x = -W / 2 + 2; x < W / 2 - 1; x += 4) { K.box(inner, 0.15, 3.4, 0.15, PAL.woodD, x, 0, -D / 2 + 3); } K.box(inner, W - 3, 0.1, 5, PAL.cream, 0, 3.4, -D / 2 + 3.4);
      K.quad(inner, W - 1.2, D - 1.2, '#e2c995', 0, 0.075, 0); solidLocal(bd, -W / 2, gA, D / 2 - 0.6, D / 2); solidLocal(bd, gB, W / 2, D / 2 - 0.6, D / 2); solidLocal(bd, -W / 2, W / 2, -D / 2, -D / 2 + 0.6); solidLocal(bd, -W / 2, -W / 2 + 0.6, -D / 2, D / 2); solidLocal(bd, W / 2 - 0.6, W / 2, -D / 2, D / 2);
      rooms.push({ key: b.key, bd, inner: [-W / 2 + 0.6, W / 2 - 0.6, -D / 2 + 0.6, D / 2 - 0.6], ceil: 30, open: true }); bd.ceil = 30; bd.doorH = 0;
    }
    if (bd.type === 'bowl') { // KUFA STADIUM: an oval sandstone bowl, arched outer wall, 4 floodlight masts, the Cistern Cup banner over the south gate, pitch inside
      const ra = W / 2, rb = D / 2, n = 44, gateA = Math.PI / 2, gHalf = Math.atan2(8, rb);
      K.quad(inner, 46, 30, '#5f8f3a', 0, 0.08, 0); K.quad(inner, 38, 22, '#6fa33f', 0, 0.09, 0); for (let i = 0; i < 8; i++) K.quad(inner, 38 / 8, 22, i % 2 ? '#78ad46' : '#6fa33f', -19 + 38 / 16 * (2 * i + 1), 0.095, 0); K.ring(inner, 3, PAL.white, 0, 0.11, 0); K.quad(inner, 0.2, 22, PAL.white, 0, 0.11, 0);
      K.cyl(inner, 1.6, 0.6, PAL.stoneD, 0, 0, 0, 16); K.cyl(inner, 1.3, 0.05, '#3aa7a0', 0, 0.6, 0, 16); for (const s of [-1, 1]) { K.box(inner, 0.2, 2.4, 0.2, PAL.white, s * 19, 0, -1.35); K.box(inner, 0.2, 2.4, 0.2, PAL.white, s * 19, 0, 1.35); K.box(inner, 0.2, 0.2, 2.9, PAL.white, s * 19, 2.3, 0); }
      for (let i = 0; i < n; i++) { const a0 = i / n * Math.PI * 2, a1 = (i + 1) / n * Math.PI * 2, am = (a0 + a1) / 2; let da = Math.atan2(Math.sin(am - gateA), Math.cos(am - gateA)); if (Math.abs(da) < gHalf + 0.05) continue;
        const px = Math.cos(am) * ra, pz = Math.sin(am) * rb, seg = Math.hypot(Math.cos(a1) * ra - Math.cos(a0) * ra, Math.sin(a1) * rb - Math.sin(a0) * rb) + 0.3;
        const nx = Math.cos(am) / ra, nz = Math.sin(am) / rb, nl = Math.hypot(nx, nz), ux = nx / nl, uz = nz / nl, wry = Math.atan2(ux, uz);
        K.box(sides.front, seg, H, 1.2, bd.wall, px, 0, pz, wry); K.box(deco, seg * 0.55, H * 0.55, 0.2, PAL.stoneD, px + ux * 0.62, 1.2, pz + uz * 0.62, wry);
        for (let k = 0; k < 5; k++) { const f = 1 - (k + 1) * 0.06; K.box(sides.back, seg * f, H - 1 - k * 2.2, 2.4, k % 2 ? '#c9a874' : '#d8bc8a', px * f - ux * 0.4, 0, pz * f - uz * 0.4, wry); }
        const wx0 = px - ux * 0.8, wz0 = pz - uz * 0.8; const [w0x, w0z] = toWorld(bd, wx0, wz0); solids.push([w0x - 2.6, w0x + 2.6, w0z - 2.6, w0z + 2.6]); }
      for (const [s, t2] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { const mx = s * ra * 0.74, mz = t2 * rb * 0.74; K.box(deco, 0.8, 24, 0.8, PAL.steel, mx, 0, mz); K.box(deco, 4, 2.4, 0.6, PAL.ink, mx, 24, mz, Math.atan2(-mx, -mz)); K.box(glow, 3.4, 1.8, 0.2, '#fff6d8', mx - Math.sin(Math.atan2(mx, mz)) * 0.4, 25.2, mz - Math.cos(Math.atan2(mx, mz)) * 0.4, Math.atan2(-mx, -mz)); }
      for (const s of [-1, 1]) K.box(deco, 2.2, H + 4, 2.2, PAL.stoneD, bd.lx + s * 6.2, 0, D / 2); K.box(deco, 14.6, 2.6, 0.4, PAL.red, bd.lx, H + 0.8, D / 2 + 0.6);
      rooms.push({ key: b.key, bd, inner: [-ra + 6, ra - 6, -rb + 6, rb - 4], ceil: 40, open: true }); bd.ceil = 40; bd.doorH = 0;
    }
    bd.top = new THREE.Group(); grp.add(bd.top); grp.updateMatrix();
    // ---- BIG ROOF SIGN (faces the door's path; light ink on a dark board, brass rim; readable from 60 m+)
    const sg = b.sign || {}, roofTxt = (sg.roof || b.label || b.key).toUpperCase(), doorTxt = (sg.door || b.label || b.key).toUpperCase(), onTop = bd.type === 'shell' || bd.type === 'keep';
    { const sH = bd.type === 'bowl' ? 4.2 : bd.type === 'yard' ? 1.9 : Math.max(2.0, Math.min(3.0, W / 7)), sy = bd.type === 'bowl' ? H + 4.6 : bd.type === 'yard' ? 4.6 : H + 0.55, sz = bd.type === 'bowl' ? D / 2 + 1.0 : bd.type === 'yard' ? D / 2 + 0.05 : D / 2 + 0.25;
      const maxW = bd.type === 'bowl' ? 40 : Math.max(W + 2, 10), bt = onTop ? top : deco, rs = signBoard(onTop ? bd.top : grp, [roofTxt], sH, maxW, bd.type === 'yard' ? bd.lx : 0, sy + 0.1, sz, {}, bt, true);
      for (const s of [-1, 1]) K.box(bt, 0.25, rs.h * 0.5 + 0.4, 0.25, '#201e1d', rs.x + s * rs.w * 0.35, sy - 0.3, sz - 0.2);
      signs.push({ key: b.key, kind: 'roof', g: rs.g, bd }); }
    // ---- EYE-LEVEL DOOR SIGN (centre 2.0 m; letters ~0.45 m) beside the door, facing the path you walk in on
    { const dH = 0.95, maxW = 6.5, roomR = W / 2 - (bd.lx + doorW / 2) - 0.6, roomL = (bd.lx - doorW / 2) - (-W / 2) - 0.6, test = textCanvas([doorTxt]), wNeed = Math.min(maxW, dH * test.aspect); test.t.dispose();
      let sx, sz = D / 2 + 0.16, post = false; if (bd.type === 'bowl') { sx = bd.lx + 9.5; sz = D / 2 + 1.6; post = true; } else if (bd.type === 'yard') { sx = bd.lx + 3.2 + 0.6 + wNeed / 2; sz = D / 2 + 0.1; if (sx + wNeed / 2 > W / 2) { sx = bd.lx - 3.2 - 0.6 - wNeed / 2; } }
      else if (roomR >= wNeed) sx = bd.lx + doorW / 2 + 0.5 + wNeed / 2; else if (roomL >= wNeed) sx = bd.lx - doorW / 2 - 0.5 - wNeed / 2; else { sx = bd.lx + doorW / 2 + 0.4 + wNeed / 2; sz = D / 2 + 1.4; post = true; }
      const ds = signBoard(grp, [doorTxt], dH, maxW, sx, 2.0, sz, { h: 200, pad: 40 }, deco);
      if (post) for (const s of [-1, 1]) K.box(deco, 0.16, 1.75, 0.16, '#201e1d', sx + s * (ds.w / 2 - 0.2), 0, sz - 0.12);
      signs.push({ key: b.key, kind: 'door', g: ds.g, bd });
      if (/NOW HIRING/.test(doorTxt) || (L.spots || []).some(s => s.kind === 'hiring' && Math.hypot(s.at[0] - b.door[0], s.at[1] - b.door[1]) < 9)) { const hb = signBoard(grp, ['NOW HIRING'], 0.6, 3.2, sx, 0.95, sz + 0.02, { bg: '#ec3013', rim: '#f3f2f2', fg: '#ffffff', h: 160, pad: 30 }, deco); signs.push({ key: b.key, kind: 'hiring', g: hb.g, bd }); } }
    // ---- meshes (one per batch: shell · top · deco · inside · glow · windows)
    { const sm = shellB.mesh(VC); if (sm) { sm.matrixAutoUpdate = true; grp.add(sm); bd.shellMesh = sm; } }
    { const tm = top.mesh(); if (tm) { tm.matrixAutoUpdate = true; bd.top.add(tm); } }
    for (const [bt, mat] of [[deco, VC], [inner, VC], [innerGlow, GLOW], [glow, GLOW]]) { const m = bt.mesh(mat); if (m) { m.matrixAutoUpdate = true; grp.add(m); if (bt === inner) bd.innerMesh = m; if (bt === innerGlow) bd.innerGlow = m; } }
    { const wm = win.mesh(WIN); if (wm) { wm.matrixAutoUpdate = true; grp.add(wm); winMeshes.push(wm); } }
    // ---- WALK-IN DOORS (Meru 2): gold light-up frame (one merged mesh for the town), automatic sliding glass panels (one instanced mesh), open within ~3.4 m, chime
    if (onTop) { const base = grp.matrix.clone(), fz = D / 2 - t / 2, fw = (w, h, d, x, y, z) => FR.add(GEO.box, '#ffffff', base.clone().multiply(M4(x, y + h / 2, z, 0, 0, 0, w, h, d)));
      fw(0.28, doorH, 0.6, bd.lx - doorW / 2 + 0.14, 0, fz); fw(0.28, doorH, 0.6, bd.lx + doorW / 2 - 0.14, 0, fz); fw(doorW, 0.3, 0.6, bd.lx, doorH - 0.3, fz);
      const [wx, wz] = toWorld(bd, bd.lx, D / 2), [ox, oz] = toWorld(bd, bd.lx, D / 2 + 2.6), [ix, iz] = toWorld(bd, bd.lx, D / 2 - 2.6), d = { key: b.key, bd, at: [wx, wz], out: [ox, oz], inn: [ix, iz], open: 0, last: -1, base, fz, doorW, doorH, panels: [], fade: bd.type === 'keep', label: doorTxt };
      for (const s of [-1, 1]) d.panels.push({ s, wood: bd.type === 'keep', idx: bd.type === 'keep' ? nWood++ : nGlass++ }); doors.push(d); }
    else { const [wx, wz] = toWorld(bd, bd.lx, D / 2), [ox, oz] = toWorld(bd, bd.lx, D / 2 + 3.5), [ix, iz] = toWorld(bd, bd.lx, D / 2 - 4); doors.push({ key: b.key, bd, at: [wx, wz], out: [ox, oz], inn: [ix, iz], open: 1, panels: [], gate: true, label: doorTxt }); }
    if (!b.interior && bd.type === 'shell') solidLocal(bd, -W / 2, W / 2, -D / 2, D / 2);
    bd.signs = signs.filter(s => s.bd === bd);
  }
  const FRAME = new THREE.MeshBasicMaterial({ vertexColors: true, color: '#c8962e', toneMapped: false }); const doorFX = []; { const fm = FR.mesh(FRAME); if (fm) { root.add(fm); doorFX.push(fm); } }   // doorFX: the town-wide door frames + panels (a stage game's camera may stand where they are: the host hides them)
  const glassIM = new THREE.InstancedMesh(GEO.box, GLASS, Math.max(1, nGlass)), woodIM = new THREE.InstancedMesh(GEO.box, new THREE.MeshToonMaterial({ color: '#6b4a2c', gradientMap: grad }), Math.max(1, nWood)); glassIM.count = nGlass; woodIM.count = nWood; glassIM.frustumCulled = woodIM.frustumCulled = false; root.add(glassIM, woodIM);
  const panelM = (d, s) => d.base.clone().multiply(M4(d.bd.lx + s * (d.doorW / 4 - 0.07) + s * d.open * (d.doorW / 2 - 0.15), (d.doorH - 0.35) / 2, d.fz, 0, 0, 0, d.doorW / 2 - 0.28, d.doorH - 0.35, d.bd.type === 'keep' ? 0.25 : 0.08));
  doorFX.push(glassIM, woodIM);
  const setPanels = d => { for (const pn of d.panels) { const im = pn.wood ? woodIM : glassIM; im.setMatrixAt(pn.idx, panelM(d, pn.s)); im.instanceMatrix.needsUpdate = true; } d.last = d.open; };
  for (const d of doors) if (!d.gate) setPanels(d);
  { const sm = new THREE.BufferGeometry(); sm.setAttribute('position', new THREE.Float32BufferAttribute(SH.pos, 3)); const m = new THREE.Mesh(sm, SHADOW); m.renderOrder = -1; root.add(m); var shadowMesh = m; }

  // ---------- spots, pads, dock, gates ----------
  const labels = [], pads = [];
  const spotOut = (L.spots || []).filter(s => s.at && !s.room);
  const helipadTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d'); g.fillStyle = '#2b2a2a'; g.beginPath(); g.arc(128, 128, 126, 0, 7); g.fill(); g.strokeStyle = '#ffd23a'; g.lineWidth = 14; g.beginPath(); g.arc(128, 128, 104, 0, 7); g.stroke(); g.fillStyle = '#ffd23a'; g.font = '900 150px Archivo, Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('H', 128, 136); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; })();
  const addLabel = (lines, x, y, z, h = 1.4, opts) => { const s = labelSprite(lines, h, opts); s.position.set(x, y, z); root.add(s); labels.push(s); return s; };
  for (const s of spotOut) { const [x, z] = s.at, y = groundY(x, z);
    if (s.kind === 'helipad') { const m = new THREE.Mesh(GEO.circle, new THREE.MeshBasicMaterial({ map: helipadTex, toneMapped: false })); m.rotation.x = -Math.PI / 2; m.scale.setScalar(13); m.position.set(x, y + 0.1, z); root.add(m); K.cyl(S, 6.8, 0.12, PAL.stoneD, x, y, z, 20); for (let a = 0; a < 8; a++) K.sph(SG, 0.22, '#ffd23a', x + Math.cos(a * 0.785) * 6.6, y + 0.25, z + Math.sin(a * 0.785) * 6.6); addLabel(s.key === 'kufaRoyalHelipad' ? ['ROYAL HELIPAD'] : ['HELIPAD', (s.note || '').split(':')[0].replace(/helipad/i, '').trim().toUpperCase() || ''], x, y + 4.5, z, 1.3); }
    else if (s.kind === 'telepad') { K.cyl(S, 4.2, 0.3, '#3a3f46', x, y, z, 20); K.ring(SG, 3.6, '#7fe3ff', x, y + 0.36, z); K.ring(SG, 2.4, '#7fe3ff', x, y + 0.36, z); const beam = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.2, 14, 24, 1, true), new THREE.MeshBasicMaterial({ color: '#7fe3ff', transparent: true, opacity: 0.18, depthWrite: false, side: THREE.DoubleSide })); beam.position.set(x, y + 7, z); root.add(beam); pads.push({ beam }); addLabel(['ROYAL TELEPORT PAD', '→ KUFA DOCK'], x, y + 5.5, z, 1.3); }
    else if (s.kind === 'vehicle') { K.cyl(S, 3, 0.2, PAL.stoneD, x, y, z, 16); K.ring(SG, 2.8, '#ffd23a', x, y + 0.24, z); addLabel([s.key === 'kufaKroo' ? 'KANGAROO BOOTS' : 'OSTRICH', 'SPECIAL VEHICLE'], x, y + 3.6, z, 1.2); }
    else if (s.kind === 'hiring') { K.box(S, 0.2, 2.6, 0.2, PAL.woodD, x - 1, y, z); K.box(S, 0.2, 2.6, 0.2, PAL.woodD, x + 1, y, z); signBoard(root, ['NOW HIRING'], 0.7, 3, x, y + 2.2, z + 0.12, { bg: '#ec3013', rim: '#f3f2f2', fg: '#ffffff', h: 160, pad: 30 }, S); }
    else if (s.kind === 'game') { if (s.key !== 'kufaFoxFarmPlots') { K.ring(SG, 2.4, '#e6b45a', x, y + 0.12, z); for (let a = 0; a < 6; a++) K.cyl(SG, 0.18, 0.3, '#ffd23a', x + Math.cos(a * 1.047) * 2.4, y, z + Math.sin(a * 1.047) * 2.4, 6); }   /* the farm's ring would sit under its plots */ addLabel([(s.label || (s.note || s.key).split(/[:(]/)[0]).toUpperCase().slice(0, 28), 'GAME'], x, y + 3.2, z, 1.0); }
    else if (s.kind === 'relicFind') { K.sph(SG, 0.5, '#ffe7a3', x + 1.6, y + 0.4, z + 0.6); addLabel(['RELIC · DRAFT'], x, y + 9.5, z, 1.0); }
    else { K.ring(SG, 0.75, '#38bdf8', x, y + 0.1, z); K.disc(S, 0.62, '#2e4a6b', x, y + 0.09, z); K.cone(SG, 0.22, 0.5, '#38bdf8', x, y + 0.1, z, 4); } }   // NPC = a floor spot only (avatars come at the merge)
  if (L.dock && L.dock.pad) { const [x, z] = L.dock.pad, r = L.dock.r || 14, y = groundY(x, z); K.cyl(S, r, 0.5, '#9ba3ab', x, y, z, 32); K.cyl(S, r * 0.8, 0.52, '#7a828a', x, y, z, 32); K.ring(SG, r * 0.88, '#ec3013', x, y + 0.56, z);
    K.cyl(S, 2.4, 3, '#d8dde2', x + 3, y + 0.5, z - 2, 12); K.cone(S, 2.4, 3, '#ec3013', x + 3, y + 3.5, z - 2, 12); for (const a of [0, 2.1, 4.2]) K.box(S, 0.25, 1.6, 0.25, PAL.steel, x + 3 + Math.cos(a) * 2.6, y + 0.5, z - 2 + Math.sin(a) * 2.6, 0, 0, 0.3);
    K.box(S, 0.8, 10, 0.8, '#5a5f66', x - r - 2, y, z); K.box(S, 7, 0.8, 0.8, '#5a5f66', x - r + 1.5, y + 9.4, z); addLabel(['KUFA DOCK', 'SPACE DOCK · THE SAND DOCK'], x, y + 8, z, 2.0); }
  const GN = { kufaConvoy: 'THE CONVOY', kufaSiphonRig: 'THE SIPHON', kufaBerthGate: 'THE BERTH', kufaCisternWyrm: 'THE CISTERN WYRM', kufaScorpionHollow: 'THE SCORPION HOLLOW · DRAFT' };
  for (const g of L.gates || []) if (g.at) { const [x, z] = g.at, y = groundY(x, z), r = g.r || 6;
    if (g.kind === 'cave') { K.sph(S, 9, '#a87a52', x, y + 1, z - 6, 0.7); K.sph(S, 6, '#b98a5e', x - 6, y, z - 3, 0.7); K.sph(S, 3.4, '#1a1410', x, y + 1, z - 1.8, 0.9); K.ring(SG, r, '#ec3013', x, y + 0.15, z); addLabel(['CAVE', GN[g.key] || g.key], x, y + 9, z, 1.6); }
    else { K.arch(S, 9, 8, '#cbb28a', x, y, z, 0, 1.0); K.box(S, 10.5, 1, 1.6, '#a8845a', x, y + 7.8, z); K.ring(SG, r, '#ec3013', x, y + 0.15, z); addLabel(['BATTLE', GN[g.key] || g.key], x, y + 10.5, z, 1.6); } }
  // station 9 label at the dive buoy + skiff at the dock
  for (const s of spotOut.filter(s => s.key === 'kufaSkiff')) { const [x, z] = s.at, sk = new Batch(); K.box(sk, 1.8, 0.6, 5, PAL.wood, 0, 0, 0); K.box(sk, 1.4, 0.2, 4.4, PAL.woodD, 0, 0.5, 0); K.cone(sk, 0.9, 1.4, PAL.wood, 0, 0, 3.1, 4, Math.PI / 4); K.box(sk, 0.1, 2.6, 0.1, PAL.ink, 0, 0.6, -0.8); K.box(sk, 1.6, 1.4, 0.04, PAL.cream, 0.2, 1.6, -0.8); const m = sk.mesh(); m.matrixAutoUpdate = true; m.position.set(x, 0.05, z + 5); root.add(m); pads.push({ bob: m, y0: 0.05 }); addLabel(['THE SKIFF', 'ROW OUT · DIVE TO STATION 9'], x, 4.2, z, 1.2); }
  for (const w of L.water || []) if (w.e) addLabel(['STATION 9 ↓', 'UNDER THE LAKE'], w.e[0], 5.4, w.e[1], 1.5);
  // TOWN SQUARE LIFE (graphics polish): shade sails over three plaza corners, a carpet seller's rugs + pots in the fourth.
  // Visual only (no solids: thin poles, you walk under the cloth). Placed clear of the layout's props, benches, spots and the tally set.
  { const sq = (L.zones || []).find(z => z.key === 'kufaTownSquare'); if (sq) { const cx0 = (sq.r[0] + sq.r[1]) / 2, cz0 = (sq.r[2] + sq.r[3]) / 2, sail = new Batch(), shB = new Batch();
    const tri = (a, b, c, col) => { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute([...a, ...b, ...c], 3)); g.computeVertexNormals(); sail.add(g, col, new THREE.Matrix4()); g.dispose(); };
    const shade = (x, z, rot, cols) => { const R = 5.2, pts = [0, 1, 2].map(i => { const a = rot + i * 2.094; return [x + Math.cos(a) * R, 4.4 + (i % 2) * 0.9, z + Math.sin(a) * R]; }), mid = [x, 3.7, z];
      for (const p of pts) { K.cyl(S, 0.09, p[1] + 0.25, PAL.woodD, p[0], 0, p[2], 6); K.sph(S, 0.16, PAL.brass, p[0], p[1] + 0.3, p[2]); }
      for (let i = 0; i < 3; i++) tri(pts[i], pts[(i + 1) % 3], mid, cols[i % cols.length]);
      K.disc(shB, 4.2, '#000', x + 2.2, 0.03, z - 0.9); };   // a soft shade patch on the stones, pushed away from the sun
    shade(cx0 + 14, cz0 - 16, 0.3, ['#c42d3c', '#f6ecd6']); shade(cx0 + 14, cz0 + 16, 1.1, ['#2f9a8f', '#f6ecd6']); shade(cx0 - 14, cz0 + 16, 2.0, ['#e6b45a', '#c4563a']);
    // the carpet seller (north-west corner, between the standpipe and the path)
    const rx0 = cx0 - 10, rz0 = cz0 - 12;
    [['#9a2b2b', 0], ['#2f4f8a', 1.7], ['#b8742a', 3.4]].forEach(([c, dx], i) => { K.box(S, 1.6, 0.04, 2.6, c, rx0 + dx, 0.02, rz0, 0.12 * (i - 1)); K.box(S, 1.1, 0.045, 2.0, i ? '#f6ecd6' : '#e6b45a', rx0 + dx, 0.03, rz0, 0.12 * (i - 1)); });
    for (let i = 0; i < 4; i++) K.cyl(S, 0.22, 1.5, ['#9a2b2b', '#2f4f8a', '#2f9a8f', '#b8742a'][i], rx0 + 5.1, 0.2, rz0 - 1.2 + i * 0.6, 12, Math.PI / 2);   // rolled carpets on a low stand
    K.box(S, 1.0, 0.2, 2.8, PAL.woodD, rx0 + 5.1, 0, rz0 - 0.3);
    [[0.35, '#c4563a'], [0.28, '#2f9a8f'], [0.42, '#b98a52'], [0.25, '#e6b45a']].forEach(([r, c], i) => { K.sph(S, r, c, rx0 - 1.4 + i * 0.7, r * 0.9, rz0 + 1.9, 1.15); K.cyl(S, r * 0.35, r * 0.6, c, rx0 - 1.4 + i * 0.7, r * 1.7, rz0 + 1.9, 8); });
    tri([rx0 - 1.2, 2.9, rz0 - 1.8], [rx0 + 4.4, 2.9, rz0 - 1.8], [rx0 + 1.6, 2.5, rz0 + 2.0], '#f6ecd6');   // a cream canopy over the rugs
    for (const [px, pz] of [[rx0 - 1.2, rz0 - 1.8], [rx0 + 4.4, rz0 - 1.8], [rx0 + 1.6, rz0 + 2.0]]) K.cyl(S, 0.07, 2.9, PAL.woodD, px, 0, pz, 6);
    const sm = sail.mesh(VCD); if (sm) root.add(sm); if (shB.pos.length) { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(shB.pos, 3)); const m = new THREE.Mesh(g, SHADOW); m.renderOrder = -1; shadowMesh.add(m); } } }   // shade patches hide at night with the other fake shadows
  for (const m of [S.mesh(VC), SG.mesh(GLOW)]) if (m) root.add(m);

  // ---------- per-frame ----------
  const roomAt = (x, z, m = 0) => { for (const r of rooms) { const c = Math.cos(r.bd.ry), s = Math.sin(r.bd.ry), dx = x - r.bd.cx, dz = z - r.bd.cz, lx = dx * c - dz * s, lz = dx * s + dz * c; if (lx > r.inner[0] - m && lx < r.inner[1] + m && lz > r.inner[2] - m && lz < r.inner[3] + m) return r; } return null; };
  let night = false;
  function waterGlint() { const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d'); g.lineCap = 'round';
    for (let i = 0; i < 70; i++) { const x = Math.random() * 256, y = Math.random() * 256, w = 6 + Math.random() * 22; g.strokeStyle = `rgba(255,255,240,${0.25 + Math.random() * 0.5})`; g.lineWidth = 1.5 + Math.random() * 2; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + w / 2, y - 3, x + w, y); g.stroke(); }
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
  // HORIZON (graphics polish): two rings of far mesas + buttes and a low sun disc, always centred on the camera (they never get
  // closer), no fog on them so they read as hazy silhouettes against the sky. 3 draw calls. Night: dark blue-violet + a moon.
  const sky = new THREE.Group(); sky.renderOrder = -1; root.add(sky);
  const ridge = (R, base, amp, seed, col) => { const N = 180, pos = [], idx = [], hsh = i => { const x = Math.sin(i * 127.1 + seed * 311.7) * 43758.5453; return x - Math.floor(x); };
    let h = 0; const hs = []; for (let i = 0; i <= N; i++) { const k = i % N, flat = hsh(k * 3 + 1) < 0.55;   // flat-topped mesas with steep sides, some lone buttes
      const tgt = hsh(Math.floor(k / 6) + seed) < 0.35 ? 0 : (0.35 + hsh(Math.floor(k / 6) * 7 + seed) * 0.65); h = flat ? h + (tgt - h) * 0.85 : tgt * (0.6 + 0.4 * hsh(k)); hs.push(h); }
    hs[N] = hs[0]; for (let i = 0; i <= N; i++) { const a = i / N * Math.PI * 2, x = Math.cos(a) * R, z = Math.sin(a) * R; pos.push(x, base - 40, z, x, base + hs[i] * amp, z); if (i < N) { const j = i * 2; idx.push(j, j + 2, j + 1, j + 1, j + 2, j + 3); } }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx);
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: col, fog: false, side: THREE.DoubleSide, depthWrite: false })); m.frustumCulled = false; m.renderOrder = -1; sky.add(m); return m; };
  const far = ridge(1150, -6, 120, 3, '#b48f8c'), nearR = ridge(900, -8, 78, 11, '#966760');
  const sunTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 128; const g = c.getContext('2d'), gr = g.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,250,230,1)'); gr.addColorStop(0.28, 'rgba(255,240,200,1)'); gr.addColorStop(0.36, 'rgba(255,214,150,0.55)'); gr.addColorStop(1, 'rgba(255,190,120,0)'); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); return new THREE.CanvasTexture(c); })();
  const sun = new THREE.Sprite(new THREE.SpriteMaterial({ map: sunTex, fog: false, depthWrite: false, transparent: true, toneMapped: false })); sun.scale.setScalar(260); sun.renderOrder = -1; sky.add(sun);
  const SUN_DIR = new THREE.Vector3(-120, 70, 50).normalize();   // the same direction as the scene's sun light
  // BIRDS: a few kites circling high over the oasis (one instanced draw call)
  const birdGeo = new THREE.BufferGeometry(); birdGeo.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0.3, -1.1, 0.25, -0.2, 0, 0, -0.3, 0, 0, 0.3, 1.1, 0.25, -0.2, 0, 0, -0.3], 3)); birdGeo.computeVertexNormals();
  const birdIM = new THREE.InstancedMesh(birdGeo, new THREE.MeshBasicMaterial({ color: '#3a2a22', side: THREE.DoubleSide }), 7); birdIM.frustumCulled = false; root.add(birdIM);
  const lw = (L.water || []).find(w => w.e), bc = lw ? [lw.e[0], lw.e[1]] : [0, 0];
  const birds = Array.from({ length: 7 }, (_, i) => ({ r: 18 + i * 7, h: 34 + (i % 3) * 9, sp: 0.12 + (i % 4) * 0.03, ph: i * 1.7, f: 4 + i % 3 }));
  const updSky = (t, cam) => { if (cam) sky.position.set(cam.x, 0, cam.z); sun.position.copy(SUN_DIR).multiplyScalar(1000);
    for (let i = 0; i < birds.length; i++) { const b = birds[i], a = t * b.sp + b.ph, flap = 0.55 + Math.sin(t * b.f + i) * 0.45;
      tmpE.set(0, -a, 0.25, 'YXZ'); tmpQ.setFromEuler(tmpE); tmpV.set(bc[0] + Math.cos(a) * b.r, b.h + Math.sin(t * 0.4 + i) * 2, bc[1] + Math.sin(a) * b.r); tmpS.set(1.4, flap * 1.4, 1.4); tmpM.compose(tmpV, tmpQ, tmpS); birdIM.setMatrixAt(i, tmpM); } birdIM.instanceMatrix.needsUpdate = true; };
  // STARS (night only): one Points draw call on the sky dome
  const stars = (() => { const n = touch ? 500 : 900, p = []; for (let i = 0; i < n; i++) { const u = Math.random(), v = 0.06 + Math.pow(Math.random(), 0.7) * 0.94, a = u * Math.PI * 2, r = 1000; p.push(Math.cos(a) * Math.sqrt(1 - v * v) * r, v * r * 0.7 + 20, Math.sin(a) * Math.sqrt(1 - v * v) * r); }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3)); const m = new THREE.Points(g, new THREE.PointsMaterial({ color: '#fff6dc', size: touch ? 2.2 : 1.8, sizeAttenuation: false, fog: false, depthWrite: false })); m.frustumCulled = false; m.renderOrder = -1; m.visible = false; sky.add(m); return m; })();
  // DRIFTING SAND: a thin wind of grains skimming the ground round the camera (one Points draw call; day only, not indoors)
  const SAND_N = touch ? 160 : 300, sandP = new Float32Array(SAND_N * 3), sandV = []; for (let i = 0; i < SAND_N; i++) { sandP[i * 3] = (Math.random() - 0.5) * 50; sandP[i * 3 + 1] = Math.random() * 1.4; sandP[i * 3 + 2] = (Math.random() - 0.5) * 50; sandV.push(4 + Math.random() * 5); }
  const sandG = new THREE.BufferGeometry(); sandG.setAttribute('position', new THREE.BufferAttribute(sandP, 3));
  const sand = new THREE.Points(sandG, new THREE.PointsMaterial({ color: '#fff0cf', size: 0.07, transparent: true, opacity: 0.6, depthWrite: false, map: (() => { const c = document.createElement('canvas'); c.width = c.height = 32; const g = c.getContext('2d'), gr = g.createRadialGradient(16, 16, 0, 16, 16, 16); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, 32, 32); return new THREE.CanvasTexture(c); })() })); sand.frustumCulled = false; root.add(sand);
  const updSand = (dt, t, cam, indoors) => { sand.visible = !night && !indoors && !!cam; if (!sand.visible) return; const gust = 0.6 + 0.4 * Math.sin(t * 0.37);
    for (let i = 0; i < SAND_N; i++) { let x = sandP[i * 3] + sandV[i] * gust * dt, z = sandP[i * 3 + 2] + sandV[i] * 0.35 * gust * dt; const y = 0.15 + Math.abs(Math.sin(t * 2 + i)) * (0.3 + (i % 5) * 0.25);
      x = cam.x + ((x - cam.x + 25) % 50 + 50) % 50 - 25; z = cam.z + ((z - cam.z + 25) % 50 + 50) % 50 - 25;   // world-anchored grains, wrapped into a 50 m box round the camera
      sandP[i * 3] = x; sandP[i * 3 + 2] = z; sandP[i * 3 + 1] = Math.max(0, heightAt(x, z)) + y; }
    sandG.attributes.position.needsUpdate = true; };
  // NIGHT LIGHT POOLS: a warm soft disc of light on the ground under every lamp (one instanced, additive draw call; night only)
  const poolTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d'), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,150,60,0.75)'); gr.addColorStop(0.45, 'rgba(240,120,40,0.3)'); gr.addColorStop(1, 'rgba(220,100,30,0)'); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
  const pools = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: poolTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 }), Math.max(1, lampPts.length));
  pools.count = lampPts.length; lampPts.forEach(([x, y, z, k], i) => pools.setMatrixAt(i, M4(x, y + 0.06, z, 0, 0, 0, 9 * k, 1, 9 * k))); pools.instanceMatrix.needsUpdate = true; pools.visible = false; pools.renderOrder = 1; root.add(pools);
  const skyNight = on => { stars.visible = on; pools.visible = on; far.material.color.set(on ? '#2c2a4a' : '#b48f8c'); nearR.material.color.set(on ? '#1d1b33' : '#966760'); sun.material.color.set(on ? '#c8d4ff' : '#ffffff'); sun.scale.setScalar(on ? 110 : 260); birdIM.visible = !on; };
  const setNight = on => { night = on; FRAME.color.set(on ? '#ffd98a' : '#c8962e'); WIN.color.set(on ? '#ffcf7a' : '#3a4a52'); GLOW.color.set(on ? '#ffffff' : '#c9bfa8'); GOLD.color.set(on ? '#ffd27a' : '#e6b45a'); shadowMesh.visible = !on; skyNight(on); };
  let audioCtx = null; const chime = () => { try { audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)(); const t0 = audioCtx.currentTime; for (const [f, d] of [[988, 0], [1319, 0.12]]) { const o = audioCtx.createOscillator(), g = audioCtx.createGain(); o.type = 'sine'; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t0 + d); g.gain.exponentialRampToValueAtTime(0.12, t0 + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d + 0.6); o.connect(g).connect(audioCtx.destination); o.start(t0 + d); o.stop(t0 + d + 0.7); } } catch (e) {} };
  const update = (dt, t, fox, cam) => {
    updSky(t, cam); for (const w of waterFX) { w.material.map.offset.set(t * 0.012, Math.sin(t * 0.3) * 0.03); w.material.opacity = night ? 0.18 : 0.42 + Math.sin(t * 1.3) * 0.12; }
    for (const s of spinners) { if (s.axis === 'z') s.o.rotation.z += dt * s.sp; else s.o.rotation.y += dt * s.sp; }
    for (const p of pads) { if (p.beam) p.beam.material.opacity = 0.12 + 0.08 * Math.sin(t * 3); if (p.bob) p.bob.position.y = p.y0 + Math.sin(t * 1.4) * 0.08; }
    const inRoom = roomAt(fox.x, fox.z, 0.2), camRoom = cam ? roomAt(cam.x, cam.z, 0.1) : null;
    updSand(dt, t, cam, inRoom && !inRoom.open);
    for (const d of doors) { if (d.gate) continue; const dist = Math.hypot(fox.x - d.at[0], fox.z - d.at[1]), want = dist < 3.4 ? 1 : 0, was = d.open;
      d.open += (want - d.open) * Math.min(1, dt * 7); if (d.open < 0.002) d.open = 0; if (was < 0.15 && d.open >= 0.15 && want) chime(); if (Math.abs(d.open - d.last) > 0.002) setPanels(d); }
    // palms right by the camera step aside (never a frond in your face)
    if (cam) { const hide = new Set(); if ((cam.y || 0) < 10) for (let i = 0; i < palmData.length; i++) { const q = palmData[i]; if (Math.abs(q.x - cam.x) < 5 && Math.abs(q.z - cam.z) < 5 && Math.hypot(q.x - cam.x, q.z - cam.z) < 4.5) hide.add(i); }
      for (const i of palmHidden) if (!hide.has(i)) { palmIM.setMatrixAt(i, palmData[i].m); palmIM.instanceMatrix.needsUpdate = true; }
      for (const i of hide) if (!palmHidden.has(i)) { palmIM.setMatrixAt(i, ZERO); palmIM.instanceMatrix.needsUpdate = true; } palmHidden = hide; }
    for (const r of rooms) { const here = r === inRoom || r === camRoom; if (r.bd.top) r.bd.top.visible = !here; for (const sg of r.bd.signs) if (sg.kind === 'roof' && !r.open) sg.g.visible = !here; }
    return inRoom; };
  for (const wm of winMeshes) wm.renderOrder = 0;
  return { group: root, doorFX, solids, doors, rooms, signs, labels, update, roomAt, heightAt, groundY, setNight, palmCount: palmPts.length };
}
