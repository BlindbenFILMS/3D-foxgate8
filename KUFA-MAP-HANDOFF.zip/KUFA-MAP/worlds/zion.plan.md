# ZION — WORLD PLAN (the wild west gold town)
From WORLD_GAMES_PLAN.md (main project, s345). Repo = GitHub BlindbenFILMS/3D-foxgate8. Build each game IN THE WORLD with IN_WORLD_GAMES.md (the Meru Claw Crane recipe).

## PHASE 1 · LAYOUT (Map Workshop)
Every building below needs its place on the map (a building with "games": [page path], or a spot kind "game"). Plus the EVERY WORLD HAS list (PARALLEL_WORLDS.md section 7).

## PHASE 2 · EXTERIORS (then Ben walks it)
Every building: own shape + roof in this world's look, a BIG ROOF SIGN + a DOOR SIGN at eye level beside the door, walk-in doors like Meru 2 (PARALLEL_WORLDS.md section 9).

## PHASE 3 · INTERIORS, one by one, DELUXE (Ben walks each)
REUSE the room each game / job below already has in the repo (its shop, kitchen, hall, court, cabinet), fitted into its building, so phase 4 plays right there. MOBILE FIRST: 390x844 + 844x390 every time.

## PHASE 4 · JOBS + GAMES IN THE WORLD, in this order (one per pass, Ben tests each on the phone)
1. TAVERN GAME: Dusty Gulch cabinet in the saloon — `3D-GAMES/g/dusty-gulch/index.html`
2. RESTAURANT: Zion bakery — NOT BUILT YET
3. SPORT: Foxtruck Crush + Mechanical Bull — `3D-GAMES/Zion Monster Arena.dc.html` · `3D-GAMES/g/zion-mechanical-bull/Main.dc.html`
4. SPECIALTY SHOP: Goldsmith of Zion — `3D-GAMES/g/goldsmith-of-zion/Main.dc.html`
5. Bex's Truck Shop — `3D-GAMES/g/bex-truck-shop/Main.dc.html`
6. Zion Gold Rush — `3D-GAMES/g/gold-rush/Main.dc.html`
7. Fox Hoops — `3D-GAMES/g/fox-hoops-a28312/index.html`
8. Gold panning — `(other repo FOXgate8) 3D/minigames3d/gold.html`

## NOT BUILT YET (ideas for later, after the list above)
- Monster truck pit crew
- Stagecoach / mail run
- Horseshoes

## SPECIAL VEHICLES
- Monster Truck — `3D-GAMES/Vehicle Workshop.dc.html?v=truck` (models in engine/vehicle-kit.js + engine/vehicle-fun.js): a spot kind "vehicle" where you get it; ride it on the map's roads / open ground

## STAYS IN THE MAIN PROJECT
Avatars, story, quests, dialogue, the real save, enemies + battles. Use stand-ins (the test fox, box keepers) and mark lines DRAFT.
