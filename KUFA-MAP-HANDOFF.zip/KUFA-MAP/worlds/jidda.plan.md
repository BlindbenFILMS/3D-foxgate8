# JIDDA — WORLD PLAN (the beach and ocean world)
From WORLD_GAMES_PLAN.md (main project, s345). Repo = GitHub BlindbenFILMS/3D-foxgate8. Build each game IN THE WORLD with IN_WORLD_GAMES.md (the Meru Claw Crane recipe).

## PHASE 1 · LAYOUT (Map Workshop)
Every building below needs its place on the map (a building with "games": [page path], or a spot kind "game"). Plus the EVERY WORLD HAS list (PARALLEL_WORLDS.md section 7).

## PHASE 2 · EXTERIORS (then Ben walks it)
Every building: own shape + roof in this world's look, a BIG ROOF SIGN + a DOOR SIGN at eye level beside the door, walk-in doors like Meru 2 (PARALLEL_WORLDS.md section 9).

## PHASE 3 · INTERIORS, one by one, DELUXE (Ben walks each)
REUSE the room each game / job below already has in the repo (its shop, kitchen, hall, court, cabinet), fitted into its building, so phase 4 plays right there. MOBILE FIRST: 390x844 + 844x390 every time.

## PHASE 4 · JOBS + GAMES IN THE WORLD, in this order (one per pass, Ben tests each on the phone)
1. TAVERN GAME: Cornhole + Washers at the beach bar — `3D-GAMES/g/8-gates-minigames-phone-preview/Cornhole.dc.html` · `3D-GAMES/g/8-gates-minigames-phone-preview/Washers.dc.html`
2. RESTAURANT: Foxy Blends Smoothies (+ a FOX Gelato kiosk) — `3D-GAMES/Jidda Smoothie.dc.html` · `3D-GAMES/g/fox-gelato/Main.dc.html`
3. SPORT: Surf Contest — `3D-GAMES/Jidda Surf.dc.html`
4. SPECIALTY SHOP: Jib's Surf Shop — `3D-GAMES/g/jibs-surf-shop/Main.dc.html`
5. Ocean World Dolphin Trainer — `3D-GAMES/g/ocean-world-aquarium/Main.dc.html`
6. Swim Trials — `3D-GAMES/Jidda Swim.dc.html`
7. Deep Dive — `3D-GAMES/Jidda Deep Dive.dc.html`
8. Submarine — `3D-GAMES/Jidda Submarine.dc.html`
9. Jetski Run — `3D-GAMES/Jidda Jetski.dc.html`
10. Inner Tube Run — `3D-GAMES/Jidda Inner Tube.dc.html`
11. Volleyball on the beach — `3D-GAMES/g/volleyball/Volleyball.dc.html`

## NOT BUILT YET (ideas for later, after the list above)
- Water taxi pilot
- Fish market auction
- Lighthouse keeper
- Skimmer

## SPECIAL VEHICLES
- Jet Ski — `3D-GAMES/Vehicle Workshop.dc.html?v=jetski` (models in engine/vehicle-kit.js + engine/vehicle-fun.js): a spot kind "vehicle" where you get it; ride it on the map's roads / open ground
- Surfboard — `3D-GAMES/Vehicle Workshop.dc.html?v=surf` (models in engine/vehicle-kit.js + engine/vehicle-fun.js): a spot kind "vehicle" where you get it; ride it on the map's roads / open ground
- Giant Turtle — `3D-GAMES/Vehicle Workshop.dc.html?v=turtle` (models in engine/vehicle-kit.js + engine/vehicle-fun.js): a spot kind "vehicle" where you get it; ride it on the map's roads / open ground

## STAYS IN THE MAIN PROJECT
Avatars, story, quests, dialogue, the real save, enemies + battles. Use stand-ins (the test fox, box keepers) and mark lines DRAFT.
