// 8 GATES · KUFA — PHASE 4: games played INSIDE their place (the Meru Claw Crane recipe, IN_WORLD_GAMES.md).
// Walk up → the PLAY button / E → the camera eases (1.7 s, one shot) from the walk camera to the game's own camera → play → BACK eases out.
// Two kinds of game:
//  · kind 'direct' (Backgammon): the game module has opts.world; the host ticks it; the play UI is drawn by Kufa World.dc.html.
//  · kind 'stage' (games built on engine/restaurant-kit.js createStage): the game's OWN page HUD is reused as a panel component
//    ("<Name> Play.dc.html", dc-imported by Kufa World). The panel calls window.__kufaGames.attach({ container, onState }) and gets the
//    game's api back. createStage runs in WORLD MODE (globalThis.__kufaStageHost): no own renderer / lights; its scene is a group in the
//    building, its camera is copied by the world. While it runs, the world's copy of that room is hidden (the game brings its own, identical).
// createGames(THREE, { world, rooms, renderer, container, onUI }) → { near(fox), start(key, cam), back(), tick(dt, hostCam, walkPose), attach(opts), playing, busy, api }
// One file per game in ./games/ (key = the building key). A file that exports null is not wired yet.
import kufaTavern from './games/kufaTavern.js';
import kufaCreamery from './games/kufaCreamery.js';
import kufaSpyShop from './games/kufaSpyShop.js';
import kufaCamelPen from './games/kufaCamelPen.js';
import kufaStadium from './games/kufaStadium.js';
import kufaFoxFarm from './games/kufaFoxFarm.js';
import kufaDominoes from './games/kufaDominoes.js';
import kufaTreasureDig from './games/kufaTreasureDig.js';
import kufaTallyBoard from './games/kufaTallyBoard.js';
import kufaCaravanBoard from './games/kufaCaravanBoard.js';
export const GAMES = Object.fromEntries(Object.entries({ kufaTavern, kufaCreamery, kufaSpyShop, kufaCamelPen, kufaStadium, kufaFoxFarm, kufaDominoes, kufaTreasureDig, kufaTallyBoard, kufaCaravanBoard }).filter(([, g]) => g));
// src paths in ./games/*.js are relative to that folder; resolve them from here
const srcURL = G => new URL(G.src, new URL('./games/x.js', import.meta.url)).href;

export function createGames(THREE, { world, rooms, renderer, container, L, onUI = () => {} }) {
  // OPEN-AIR games (the three jobs) sit at a layout SPOT, not in a building: they get a stand-in "room" = a group at the spot
  // (bd: cx, cz, ry = 0, grp; building-local metres = metres from the spot, +z = south). G.spot = true marks them.
  const spotRooms = []; for (const [key, G] of Object.entries(GAMES)) if (G.spot) { const s = (L && L.spots || []).find(q => q.key === key); if (!s || !s.at) continue;
    const grp = new THREE.Group(), y = world.groundY(s.at[0], s.at[1]); grp.position.set(s.at[0], y, s.at[1]); world.group.add(grp);
    const R = { spot: s, y, extra: [] }; spotRooms.push({ key, bd: { key, cx: s.at[0], cz: s.at[1], ry: 0, W: 0, D: 0, H: 0, grp, y }, R, state: 'ready', spot: true });
    if (G.idle) import(srcURL(G)).then(m => { const set = m[G.idle] && m[G.idle](THREE, grp); if (set) R.extra.push(set); }).catch(e => console.warn('idle set', key, e)); }   // G.idle: the job's set shows while you walk (hidden while it plays: its game builds its own)
  const allRooms = () => rooms.rooms.concat(spotRooms);
  let cur = null;   // { key, G, r, R, api, ST, blend, dir, from: { pos, quat, fov } }
  const local = (bd, x, z) => { const c = Math.cos(bd.ry), s = Math.sin(bd.ry), dx = x - bd.cx, dz = z - bd.cz; return [dx * c - dz * s, dx * s + dz * c]; };
  const V = new THREE.Vector3(), Q = new THREE.Quaternion(), S = new THREE.Vector3(), ease = t => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  const showRoom = (r, on) => { const R = r.R; if (!R) return; if (R.host) R.host.visible = on; for (const e of R.extra || []) e.visible = on; for (const k of R.keeperObjs || []) k.g.visible = on; r.hidden = !on; };
  const self = {
    get playing() { return !!cur && cur.dir >= 0; }, get blend() { return cur ? cur.blend : -1; }, get busy() { return !!cur; }, get api() { return cur && cur.api; }, get key() { return cur && cur.key; }, get kind() { return cur && cur.G.kind; },
    near(fox) { if (cur) return null; for (const r of allRooms()) { const G = GAMES[r.key]; if (!G || r.state !== 'ready') continue; const [lx, lz] = local(r.bd, fox.x, fox.z); if (G.near(r.R, lx, lz)) return { key: r.key, label: G.label, sub: G.sub }; } return null; },
    async start(key, hostCam) { if (cur) return; const G = GAMES[key], r = allRooms().find(q => q.key === key); if (!G || !r || r.state !== 'ready') return;
      cur = { key, G, r, R: r.R, api: null, ST: null, blend: 0, dir: 1, from: { pos: hostCam.position.clone(), quat: hostCam.quaternion.clone(), fov: hostCam.fov } };
      if (G.panel) { onUI({ panel: G.panel, playing: G.label, kind: 'stage' }); return; }   // the panel (the game's own page HUD) mounts and calls attach()
      onUI({ loading: G.label });
      try { const m = await import(srcURL(G)); const host = { container, renderer, onState: h => onUI({ state: h }), active: () => !!cur && cur.dir > 0 && cur.blend > 0.6 };
        cur.api = await G.create(m, r.R, host); onUI({ loading: null, playing: G.label, kind: 'direct' }); }
      catch (e) { console.error(e); onUI({ loading: null, error: G.label + ' could not start: ' + e.message }); cur = null; } },
    // called by a game panel ("<Name> Play.dc.html") when it mounts: build the game in WORLD MODE, give the panel its api
    attach(opts) { if (!cur || !cur.G.panel) return Promise.reject(new Error('no world game is starting')); const c = cur;   // a panel that mounts twice gets the SAME game (never two)
      if (c.attaching) { if (opts && opts.onState) c.onStates.push(opts.onState); return c.attaching; } c.onStates = [opts.onState]; c.attaching = self._attach(c, opts.container, s => c.onStates.forEach(f => f(s))); return c.attaching; },
    async _attach(c, panelEl, onState) { const G = c.G;
      const m = await import(srcURL(G));
      if (G.kind === 'direct') c.api = await G.create(m, c.R, { container: panelEl, renderer, onState, active: () => !!cur && cur.dir > 0 && cur.blend > 0.6, bd: c.r.bd });
      else { globalThis.__kufaStageHost = { renderer, parent: c.r.bd.grp, origin: G.origin, rotY: G.rotY, onStage: ST => { c.ST = ST; } };
        try { c.api = await G.create(m, { container: panelEl, onState }); } finally { delete globalThis.__kufaStageHost; } }
      if (cur !== c) { try { c.api.destroy(); } catch (e) {} if (!renderer.domElement.isConnected) container.insertBefore(renderer.domElement, container.firstChild); return null; }
      if (G.hideRoom !== false) showRoom(c.r, false);
      if (G.kind === 'stage') { const keep = c.ST && c.ST.scene; const hk = c.r.bd.grp.children.filter(o => o !== keep && o.visible); for (const o of world.doorFX || []) if (o.visible) hk.push(o); hk.forEach(o => o.visible = false); c.hiddenKids = (c.hiddenKids || []).concat(hk); }   // the game's shots may stand outside the room walls (as in its own page): our shell, roof + signs step aside
      return c.api; },
    back() { if (!cur) return; const gc = (cur.api && cur.api.camera) || (cur.ST && cur.ST.camera);   // freeze the game's last shot: the panel unmounts and the game stops now
      if (gc) { gc.updateMatrixWorld(); const p = new THREE.Vector3(), q = new THREE.Quaternion(); gc.matrixWorld.decompose(p, q, new THREE.Vector3()); if (isFinite(p.x) && isFinite(gc.fov)) cur.end = { pos: p, quat: q, fov: gc.fov }; }
      cur.dir = -1; cur.blend = Math.min(cur.blend, 1); onUI({ playing: null, state: null, panel: null }); },
    // returns true while the game owns (or is blending) the camera
    tick(dt, hostCam, walkPose) { if (!cur) return false; const api = cur.api; if (api && api.tick) api.tick(dt);
      const now = performance.now(), rdt = Math.min(0.25, ((now - (cur.lastT || now)) / 1000) || dt); cur.lastT = now; cur.blend = Math.max(0, Math.min(1, cur.blend + cur.dir * rdt / 1.7));   // real time: the ease is 1.7 s even when frames are slow
      if (cur.dir < 0 && cur.blend <= 0) { try { api && api.destroy(); } catch (e) { console.warn(e); } if (!renderer.domElement.isConnected) container.insertBefore(renderer.domElement, container.firstChild); /* games' destroy() removes 'their' canvas: in the world that is ours */ if (cur.ST && cur.ST.scene) cur.ST.scene.removeFromParent(); (cur.hiddenKids || []).forEach(o => o.visible = true); showRoom(cur.r, true); cur = null; return false; }
      const a = cur.dir > 0 ? cur.from : walkPose, k = ease(cur.blend); let gf;
      if (cur.dir < 0 && cur.end) { V.copy(cur.end.pos); Q.copy(cur.end.quat); gf = cur.end.fov; }
      else { const gc = (api && api.camera) || (cur.ST && cur.ST.camera); if (!gc) { hostCam.position.copy(cur.from.pos); hostCam.quaternion.copy(cur.from.quat); return true; } gc.updateMatrixWorld(); gc.matrixWorld.decompose(V, Q, S); gf = gc.fov; }
      if (!isFinite(V.x) || !isFinite(gf)) { V.copy(a.pos); Q.copy(a.quat); gf = a.fov; }
      hostCam.position.copy(a.pos).lerp(V, k); hostCam.quaternion.copy(a.quat).slerp(Q, k); hostCam.fov = a.fov + (gf - a.fov) * k; hostCam.updateProjectionMatrix(); return true; },
  };
  return self;
}
