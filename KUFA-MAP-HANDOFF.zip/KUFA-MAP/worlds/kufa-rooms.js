// 8 GATES · KUFA — PHASE 3 INTERIORS: the rooms our games already have (GitHub BlindbenFILMS/3D-foxgate8), built INSIDE their buildings.
// Each room is the game's own builder (copied into minigames/kufa/<game>/, only import paths changed), called with the
// building's group as its "scene", so it sits in the footprint with the door where the room's door is.
// Rooms load when you come within ~40 m (lazy: the town still loads fast) and only draw while you are near.
// API: createRooms(THREE, world, { touch }) → { update(fox, cam), block(x, z, r) → true if a room's own walls / furniture block, camRect(x, z) → [x0, x1, z0, z1] in building-local metres or null, loaded }
import { roomCtx } from '../minigames/kufa/kufa-engine.js';
import { DRESS } from './kufa-interiors.js';   // Phase 3: dressed rooms for the new buildings (no repo room, no 2D room)

// FIT: per building — which game file, which builder, where it sits (building-local metres, +z toward the door), its walk test.
const FIT = {
  kufaCreamery: { // creamery-shift.js buildCreamery (takes origin + rotY; front +z = our door side; game door at x +3.6)
    src: '../minigames/kufa/creamery/creamery-shift.js',
    build(m, ctx) { const K = m.buildCreamery({ ...ctx, origin: { x: 0, z: 0 }, rotY: 0 });
      return { root: K.root, hideIn: K.cut, walk: (x, z) => z > 4.6 ? Math.abs(x - 3.6) < 0.62 && z < 5.6 : K.walkable(x, z, 0.32), cams: [[-5.6, 5.6, -4.6, 4.6]], keepers: [{ name: 'JAMIL', at: [-2.2, -2.6], face: 0, col: '#f2b7c6' }] }; } },
  kufaSpyShop: { // spy-shop.js buildSpyShop (origin only): game origin = the front-room centre = building-local (0, +2.2)
    src: '../minigames/kufa/spyshop/spy-shop.js', origin: [0, 2.2],
    build(m, ctx) { const Y = m.buildSpyShop({ ...ctx, origin: { x: 0, z: 2.2 } }), Wk = Y.walk;
      const walk = (x, z) => { z -= 2.2; if (z > 3.6 && Math.abs(x) < 0.55) return z < 4.6; if (!Wk.rooms.some(r => x > r.x0 && x < r.x1 && z > r.z0 && z < r.z1)) return false; return !Wk.solids.some(s => x > s.x0 - 0.3 && x < s.x1 + 0.3 && z > s.z0 - 0.3 && z < s.z1 + 0.3); };
      return { root: Y.root, hideIn: Y.ceil || [], tick: (dt, t) => Y.update && Y.update(dt, t), walk, cams: Wk.rooms.slice(0, 2).map(r => [r.x0 + 0.1, r.x1 - 0.1, r.z0 + 2.3, r.z1 + 2.1]), keepers: [{ name: 'RAFIQ', at: [-1.15, 0.35], face: 0, col: '#8fa8e0' }] }; } },
  kufaDominoes: { // dominoes-club.js buildParlor: a closed 7.2 x 7.2 parlour → we cut its door in the +z wall
    src: '../minigames/kufa/dominoes/dominoes-club.js',
    build(m, ctx, T) { const P = m.buildParlor({ toon: ctx.toon, M: ctx.M, scene: ctx.scene, origin: new T.Vector3(0, 0, 0) }); cutDoor(T, P.group, 7.2, 7.2, 3.2, 0, 1.9, 2.5);
      return { root: P.group, walk: parlorWalk(0, 0, true), cams: [[-3.2, 3.2, -3.2, 3.2, 3.2]] }; } },
  kufaTavern: { // backgammon-club.js buildParlor = the BACKGAMMON PARLOUR, a back room (north-east corner) of the tavern hall; + the hall itself (bar, foosball, darts, jukebox)
    src: '../minigames/kufa/backgammon/backgammon-club.js',
    build(m, ctx, T, bd) { const px = bd.W / 2 - 0.4 - 3.7, pz = -bd.D / 2 + 0.4 + 3.7, P = m.buildParlor({ toon: ctx.toon, M: ctx.M, scene: ctx.scene, origin: new T.Vector3(px, 0, pz) }); cutDoor(T, P.group, 7.2, 7.2, 3.4, 0, 1.9, 2.5);
      const hall = dressTavern(T, ctx, bd, px, pz), pw = parlorWalk(px, pz, true);
      const walk = (x, z) => { const inP = Math.abs(x - px) < 3.75 && Math.abs(z - pz) < 3.75; if (inP) return pw(x, z); return hall.walk(x, z); };
      return { root: P.group, parlor: P, parlorAt: [px, pz], extra: [hall.g], walk, cams: [[px - 3.2, px + 3.2, pz - 3.2, pz + 3.2, 3.4], null], keepers: [{ name: 'NASRIN', at: hall.bar, face: 0, col: '#e0a48a' }, { name: 'SURA', at: [-3, 4], face: 2.4, col: '#c9682a', seat: true }, { name: 'JIBRIL', at: [-1.2, 4.6], face: -2.6, col: '#9a6f4a', seat: true }] }; } },
  kufaCamelPen: { open: true, // camel-pen.js buildCamelPen + addPenCamels (origin only): turned a quarter so its gate (-x wall) faces Camel Pen Lane
    src: '../minigames/kufa/camel-pen/camel-pen.js', rot: Math.PI / 2, origin: [0.95, 0],
    build(m, ctx, T) { const Y = m.buildCamelPen({ ...ctx, origin: { x: 0, z: 0 } }); let cam = null; try { cam = m.addPenCamels(ctx, Y); } catch (e) { console.warn('camels', e); }
      // local → game: gz = lx - 0.95, gx = -lz
      const walk = (x, z) => { const gz = x - 0.95, gx = -z; if (gx < -8.4 && gz > -2.3 && gz < 0.7) return gx > -10.2; return Y.walk(gx, gz); };
      return { root: Y.root, tick: dt => cam && cam.update(dt), walk, cams: null, hideOwn: true, keepers: [{ name: 'UMMI', at: [-2.2, 2.4], face: Math.PI / 2, col: '#d8b98a' }] }; } },
  // ---- open-air game places (Phase 4 hooks: their game builds its own pitch / plots when you press PLAY)
  kufaStadium: { open: true, keepFloor: true, build: (m, ctx, T, bd) => { const g = new T.Group(); ctx.scene.add(g); return { root: g, walk: () => true, cams: null }; } },
  kufaFoxFarm: { keepFloor: true, build: (m, ctx, T, bd) => { const g = new T.Group(); ctx.scene.add(g); return { root: g, walk: () => true, cams: null, field: [0, -(bd.D / 2 + 22)] }; } },   // the FIELD (layout "field") lies behind the farmhouse: building-local (0, -33)
  // ---- the 2D game's other rooms (no repo game yet): dressed here from the brief, keepers at their 2D spots
  kufaItemShop: { keepFloor: true, build: (m, ctx, T, bd) => dressShop(T, ctx, bd, 'items') },
  kufaArmory: { keepFloor: true, build: (m, ctx, T, bd) => dressShop(T, ctx, bd, 'armory') },
  kufaThroneRoom: { keepFloor: true, build: (m, ctx, T, bd) => dressThrone(T, ctx, bd) },
  kufaBarracks: { keepFloor: true, build: (m, ctx, T, bd) => dressBarracks(T, ctx, bd) },
};

// shared dressing helpers (building-local metres, +z toward the door)
const kit = (T, ctx) => { const { M, toon } = ctx, g = new T.Group(); ctx.scene.add(g); const solids = [];
  const B = (w, h, d, mat, x, y, z, solid = false) => { const o = M(new T.BoxGeometry(w, h, d), typeof mat === 'string' ? toon(mat) : mat, x, y + h / 2, z, g, 0.02); if (solid) solids.push([x - w / 2, x + w / 2, z - d / 2, z + d / 2]); return o; };
  const C = (r, h, mat, x, y, z, seg = 12, solid = false) => { const o = M(new T.CylinderGeometry(r, r, h, seg), typeof mat === 'string' ? toon(mat) : mat, x, y + h / 2, z, g, 0.02, r); if (solid) solids.push([x - r, x + r, z - r, z + r]); return o; };
  const glow = (w, h, d, col, x, y, z) => { const o = new T.Mesh(new T.BoxGeometry(w, h, d), new T.MeshBasicMaterial({ color: col })); o.position.set(x, y, z); g.add(o); return o; };
  const plate = (lines, w, h, x, y, z, ry = 0) => { const c = document.createElement('canvas'); c.width = 512; c.height = Math.round(512 * h / w); const q = c.getContext('2d'); q.fillStyle = '#201e1d'; q.fillRect(0, 0, c.width, c.height); q.strokeStyle = '#e6b45a'; q.lineWidth = 10; q.strokeRect(5, 5, c.width - 10, c.height - 10); q.fillStyle = '#fbf3e0'; q.textBaseline = 'middle'; lines.forEach((l, i) => { q.font = `900 ${i ? 30 : 46}px Archivo, Arial`; q.fillText(l, 24, (i + 0.7) * c.height / (lines.length + 0.4)); }); const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; const o = new T.Mesh(new T.PlaneGeometry(w, h), new T.MeshBasicMaterial({ map: t })); o.position.set(x, y, z); o.rotation.y = ry; g.add(o); return o; };
  const walk = (W, D) => (x, z) => Math.abs(x) < W / 2 - 0.75 && Math.abs(z) < D / 2 - 0.75 || (z > 0 && Math.abs(x) < 2) ? !solids.some(s => x > s[0] - 0.3 && x < s[1] + 0.3 && z > s[2] - 0.3 && z < s[3] + 0.3) : false;
  return { g, B, C, glow, plate, solids, walk }; };
// ITEM SHOP ("plain trader's hall": counter with Heal Beam Batteries, Energy Cells, dates, canteens; back shelf) · ARMORY ("hot forge hall, brass over steel": counter, weapon racks, forge)
function dressShop(T, ctx, bd, kind) { const k = kit(T, ctx), W = bd.W, D = bd.D, wood = '#6b4a2c', woodL = '#9a7444', brass = '#e6b45a', zc = -D / 2 + 6;
  k.B(W - 6, 1.1, 1.3, kind === 'armory' ? '#5a4a3a' : woodL, 0, 0, zc, true); k.B(W - 5.6, 0.12, 1.5, kind === 'armory' ? brass : wood, 0, 1.1, zc);
  k.B(W - 2, 3.2, 0.7, wood, 0, 0, -D / 2 + 1.0, true); for (let r = 0; r < 3; r++) k.B(W - 2.2, 0.08, 0.8, woodL, 0, 0.9 + r * 0.9, -D / 2 + 1.05);
  if (kind === 'items') {
    for (let i = 0; i < 14; i++) { const x = -W / 2 + 2.2 + i * (W - 4.4) / 13; for (let r = 0; r < 3; r++) { const col = ['#c2410c', '#3a6ea5', '#e6b45a', '#7a3a1a'][(i + r) % 4]; if ((i + r) % 2) k.C(0.22, 0.5, col, x, 0.98 + r * 0.9, -D / 2 + 1.05, 10); else k.B(0.4, 0.35, 0.3, r === 1 ? '#38bdf8' : '#d8c39a', x, 0.98 + r * 0.9, -D / 2 + 1.05); } }
    for (const [x, lab] of [[-W / 4, 'HEAL BEAM BATTERY'], [0, 'ENERGY CELL'], [W / 4, 'DATES · CANTEEN']]) { k.B(1.6, 0.4, 0.8, '#d8c39a', x, 1.22, zc); k.plate([lab], 2.6, 0.5, x, 2.0, zc + 0.8); }
    k.B(0.9, 1.6, 0.9, brass, W / 2 - 2, 0, zc + 2.2, true); for (const [x, z] of [[-W / 3, 2], [W / 3, 2], [-W / 3, 6], [W / 3, 6]]) { k.B(2.2, 0.9, 1.4, woodL, x, 0, z, true); for (let i = 0; i < 4; i++) k.C(0.18, 0.4, ['#c2410c', '#e6b45a'][i % 2], x - 0.75 + i * 0.5, 0.9, z, 10); }
    k.plate(['HADI · TRADER', 'THREE PRICES. HE MEANS THE SECOND.'], 5, 1.1, 0, 4.2, -D / 2 + 1.4);
  } else {
    // forge (glowing) in the back corner + anvil + weapon racks on the side walls
    k.B(4, 1.4, 3, '#4a3a30', W / 2 - 3.2, 0, -D / 2 + 3, true); k.glow(3, 0.4, 2, '#ff6a2a', W / 2 - 3.2, 1.45, -D / 2 + 3); k.B(2.4, 5, 1.6, '#5a4a3a', W / 2 - 3.2, 1.4, -D / 2 + 1.8); const L = new T.PointLight(0xff8a3a, 1.6, 12, 1.5); L.position.set(W / 2 - 3.2, 2.2, -D / 2 + 4); k.g.add(L);
    k.B(1.4, 0.8, 0.6, '#2a2a2e', W / 2 - 6.5, 0, -D / 2 + 3.4, true); k.B(1.8, 0.35, 0.7, '#3a3a40', W / 2 - 6.5, 0.8, -D / 2 + 3.4);
    for (const s of [-1, 1]) for (let i = 0; i < 5; i++) { const z = -D / 2 + 9 + i * 2.4, x = s * (W / 2 - 1.1); k.B(0.4, 2.8, 0.2, wood, x, 0, z - 0.8); k.B(0.4, 2.8, 0.2, wood, x, 0, z + 0.8); for (let j = 0; j < 3; j++) k.B(0.12, 2.6, 0.12, ['#c9ccd2', brass, '#8f969c'][j], x - s * 0.2, 0.2, z - 0.5 + j * 0.5).rotation.z = s * 0.15; }
    for (const [x, lab] of [[-W / 4, 'HALBERD · MAUL'], [0, 'BRIGANDINE'], [W / 4, 'SPEARS · CLAWS']]) { k.B(1.8, 0.2, 0.5, '#c9ccd2', x, 1.25, zc); k.plate([lab], 2.6, 0.5, x, 2.0, zc + 0.8); }
    k.plate(['ZOHRA · ARMORER', 'BRASS OVER STEEL. STEEL COOKS YOU.'], 5, 1.1, -W / 4, 4.2, -D / 2 + 1.4);
  }
  // NOW the walkway door → counter stays open; rugs show it
  const rug = new T.Mesh(new T.PlaneGeometry(2.6, D / 2), new T.MeshToonMaterial({ color: kind === 'armory' ? '#7a1d2a' : '#2f6d9a' })); rug.rotation.x = -Math.PI / 2; rug.position.set(0, 0.1, D / 4 - 1); k.g.add(rug);
  const keeper = kind === 'items' ? { name: 'HADI', at: [0, zc - 1.3], face: 0, col: '#d8b98a' } : { name: 'ZOHRA', at: [-W / 6, zc - 1.3], face: 0, col: '#e6c884' };
  return { root: k.g, walk: k.walk(W, D), cams: null, keepers: [keeper] }; }
// THRONE ROOM ("stone nave to a DAIS and THRONE, side aisles, TREASURY, crest medallion"; Emir Tahir)
function dressThrone(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D, red = '#a8202c', gold = '#e6b45a', stone = '#d8c39a';
  const carpet = new T.Mesh(new T.PlaneGeometry(5, D - 10), new T.MeshToonMaterial({ color: red })); carpet.rotation.x = -Math.PI / 2; carpet.position.set(0, 0.1, 3); k.g.add(carpet); k.B(5.4, 0.04, D - 10, gold, 0, 0.08, 3);
  for (const s of [-1, 1]) for (let i = 0; i < 6; i++) { const z = -D / 2 + 9 + i * (D - 14) / 5; k.C(0.9, bd.ceil - 0.2, stone, s * 8, 0, z, 14, true); k.B(2.2, 0.6, 2.2, gold, s * 8, bd.ceil - 0.8, z); k.glow(0.5, 0.7, 0.5, '#ffcf7a', s * 8 - s * 1.0, 3.2, z); }
  k.B(16, 0.6, 7, stone, 0, 0, -D / 2 + 5, true); k.B(10, 0.6, 5, '#c9a874', 0, 0.6, -D / 2 + 4.5, true);
  k.B(2.6, 1.2, 2, red, 0, 1.2, -D / 2 + 4); k.B(2.8, 4.2, 0.6, gold, 0, 1.2, -D / 2 + 3); for (const s of [-1, 1]) k.B(0.5, 1.6, 2, gold, s * 1.4, 1.2, -D / 2 + 4);
  const med = k.C(3.2, 0.3, gold, 0, bd.ceil - 6, -D / 2 + 0.7, 32); med.rotation.x = Math.PI / 2; const med2 = k.C(2.6, 0.32, red, 0, bd.ceil - 6, -D / 2 + 0.75, 32); med2.rotation.x = Math.PI / 2;
  k.plate(['K', ''], 2, 2, 0, bd.ceil - 4.5, -D / 2 + 1.0);
  // TREASURY behind brass bars (east aisle) + chests
  const tx = W / 2 - 6, tz = -D / 2 + 8; for (let i = 0; i < 9; i++) k.B(0.12, 3.2, 0.12, gold, tx - 4 + i, 0, tz + 4, true); for (const [a, b] of [[-2, 0], [0, -1], [2, 0.5]]) { k.B(1.6, 0.9, 1, '#6b4a2c', tx + a, 0, tz + b, true); k.B(1.7, 0.2, 1.1, gold, tx + a, 0.9, tz + b); }
  k.plate(['TREASURY'], 3, 0.6, tx, 3.6, tz + 4.1);
  for (const s of [-1, 1]) for (let i = 0; i < 3; i++) k.B(1.8, 6, 0.12, red, s * (W / 2 - 0.6), 3, -D / 2 + 8 + i * 12).rotation.y = Math.PI / 2;
  const L = new T.PointLight(0xffe0a8, 1.4, 60, 1.1); L.position.set(0, bd.ceil - 3, 0); k.g.add(L);
  return { root: k.g, walk: k.walk(W, D), cams: null, keepers: [{ name: 'EMIR TAHIR', at: [0, -D / 2 + 4.6], face: 0, col: '#c42d3c', y: 1.2 }] }; }
// BARRACKS ("rotunda with ROTUNDA DESK, DORM aisle with beds, TRAINING stand, ARMORY stand"; Captain Idris)
function dressBarracks(T, ctx, bd) { const k = kit(T, ctx), W = bd.W, D = bd.D, wood = '#6b4a2c', blanket = '#3a6ea5';
  k.C(2.6, 1.1, '#9a7444', 0, 0, -D / 2 + 6, 20, true); k.C(2.8, 0.1, '#e6b45a', 0, 1.1, -D / 2 + 6, 20); k.plate(['CAPTAIN IDRIS', 'TWO CARAVANS LOST ON THE FIRST LEG'], 6, 1.2, 0, 4.2, -D / 2 + 0.6);
  for (const s of [-1, 1]) for (let i = 0; i < 5; i++) { const z = -D / 2 + 12 + i * 5, x = s * (W / 2 - 2.2); k.B(2.2, 0.6, 1.2, wood, x, 0, z, true); k.B(2.0, 0.2, 1.1, blanket, x, 0.6, z); k.B(0.5, 0.2, 0.9, '#f2e6c8', x + s * 0.7, 0.75, z); }
  for (const [x, z] of [[-3, 6], [3, 6]]) { k.C(0.15, 1.6, wood, x, 0, z, 8, true); k.B(0.9, 0.9, 0.5, '#d8c39a', x, 1.6, z); k.C(0.3, 0.4, '#d8c39a', x, 2.5, z); }
  for (let i = 0; i < 4; i++) k.B(0.12, 2.4, 0.12, '#c9ccd2', W / 2 - 1.2, 0.3, -D / 2 + 3 + i * 0.5);
  const L = new T.PointLight(0xffe0a8, 1.2, 40, 1.2); L.position.set(0, bd.ceil - 2, 0); k.g.add(L);
  return { root: k.g, walk: k.walk(W, D), cams: null, keepers: [{ name: 'CAPTAIN IDRIS', at: [0, -D / 2 + 3], face: 0, col: '#8a9aa8' }] }; }

// a doorway in a parlour's +z wall (the repo parlours are closed rooms): replace that wall plane with two side pieces + a lintel
function cutDoor(T, G, W, D, H, x, w, h) {
  const wall = G.children.find(o => o.isMesh && o.geometry && o.geometry.type === 'PlaneGeometry' && Math.abs(o.position.z - D / 2) < 0.01 && Math.abs(o.rotation.y - Math.PI) < 0.01); if (!wall) return;
  const mat = wall.material; G.remove(wall);
  const piece = (pw, ph, px, py) => { const g = new T.PlaneGeometry(pw, ph), uv = g.attributes.uv, u0 = (W / 2 - (px + pw / 2)) / W, v0 = (py - ph / 2) / H; for (let i = 0; i < uv.count; i++) uv.setXY(i, u0 + uv.getX(i) * pw / W, v0 + uv.getY(i) * ph / H); const m = new T.Mesh(g, mat); m.position.set(px, py, D / 2); m.rotation.y = Math.PI; G.add(m); };
  const lw = (W / 2 + x - w / 2), rw = (W / 2 - x - w / 2); piece(lw, H, -W / 2 + lw / 2, H / 2); piece(rw, H, W / 2 - rw / 2, H / 2); piece(w, H - h, x, h + (H - h) / 2);
  // a brass door frame so the way in reads at once
  const brass = new T.MeshToonMaterial({ color: '#e6b45a' }); for (const s of [-1, 1]) { const p = new T.Mesh(new T.BoxGeometry(0.12, h, 0.16), brass); p.position.set(x + s * w / 2, h / 2, D / 2); G.add(p); } const l = new T.Mesh(new T.BoxGeometry(w + 0.24, 0.12, 0.16), brass); l.position.set(x, h, D / 2); G.add(l);
}
// parlour walk: inside the 7.2 room, round the table + stools, out through the cut door
function parlorWalk(cx, cz, door) { return (x, z) => { x -= cx; z -= cz; if (door && z > 3.2 && Math.abs(x) < 0.6) return z < 4.3; if (Math.abs(x) > 3.25 || Math.abs(z) > 3.25) return false; if (Math.abs(x) < 1.25 && Math.abs(z) < 1.15) return false; if (Math.abs(x) < 0.55 && Math.abs(z) > 0.8 && Math.abs(z) < 1.7) return false; return true; }; }

// THE TAVERN HALL (deluxe, from the 2D brief: BAR with harira / mint tea / pastry, JUKEBOX, DARTBOARD, FOOSBALL, round tables), built here
function dressTavern(T, ctx, bd, px, pz) {
  const { M, toon } = ctx, g = new T.Group(), W = bd.W, D = bd.D, wood = toon('#6b4a2c'), woodL = toon('#9a7444'), brass = toon('#e6b45a'), red = toon('#c42d3c'), cream = toon('#f2e6c8'), ink = toon('#201e1d'), teal = toon('#2f9a8f'), tile = toon('#c9a46a');
  ctx.scene.add(g); const B = (w, h, d, mat, x, y, z, p = g) => M(new T.BoxGeometry(w, h, d), mat, x, y + h / 2, z, p, 0.02);
  // floor tiles + a long rug down the walkway (door → hall → parlour)
  const fl = new T.Mesh(new T.PlaneGeometry(W - 0.9, D - 0.9), new T.MeshToonMaterial({ map: ctx.canvasTex(256, 256, c => { for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) { c.fillStyle = (x + y) % 2 ? '#c9a46a' : '#e2c995'; c.fillRect(x * 32, y * 32, 32, 32); c.fillStyle = '#a8792e'; c.fillRect(x * 32 + 14, y * 32 + 14, 4, 4); } }, [W / 4, D / 4]), gradientMap: ctx.grad })); fl.rotation.x = -Math.PI / 2; fl.position.y = 0.09; g.add(fl);
  const rug = new T.Mesh(new T.PlaneGeometry(3, D * 0.55), new T.MeshToonMaterial({ map: ctx.canvasTex(64, 256, c => { c.fillStyle = '#7a1d2a'; c.fillRect(0, 0, 64, 256); c.fillStyle = '#e6b45a'; c.fillRect(6, 0, 52, 256); c.fillStyle = '#1f4e8c'; c.fillRect(10, 0, 44, 256); for (let y = 8; y < 256; y += 24) { c.fillStyle = '#c42d3c'; c.beginPath(); c.moveTo(32, y); c.lineTo(46, y + 10); c.lineTo(32, y + 20); c.lineTo(18, y + 10); c.fill(); } }), gradientMap: ctx.grad })); rug.rotation.x = -Math.PI / 2; rug.position.set(0, 0.1, D * 0.2); g.add(rug);
  // THE BAR along the west wall: counter, brass rail, stools, back shelf with jars + teapots, a menu board
  const bx = -W / 2 + 3.2, bz = -2; B(1.2, 1.1, 9, wood, bx, 0, bz); B(1.4, 0.1, 9.2, woodL, bx, 1.1, bz); const rail = M(new T.CylinderGeometry(0.05, 0.05, 9, 8), brass, bx + 0.75, 0.3, bz, g, 0); rail.rotation.x = Math.PI / 2;
  for (let i = 0; i < 5; i++) { const z = bz - 3.6 + i * 1.8; M(new T.CylinderGeometry(0.3, 0.3, 0.08, 14), red, bx + 1.5, 0.86, z, g, 0.02, 0.3); M(new T.CylinderGeometry(0.05, 0.06, 0.82, 8), brass, bx + 1.5, 0.41, z, g, 0.01, 0.05); }
  B(0.5, 2.6, 9, woodL, -W / 2 + 0.75, 0, bz); for (let r = 0; r < 3; r++) for (let k = 0; k < 8; k++) { const z = bz - 3.8 + k * 1.1; if ((r + k) % 3 === 0) { M(new T.SphereGeometry(0.18, 10, 8), brass, -W / 2 + 0.85, 1.0 + r * 0.7, z, g, 0.01, 0.18); M(new T.CylinderGeometry(0.03, 0.03, 0.18, 6), brass, -W / 2 + 0.85 + 0.18, 1.05 + r * 0.7, z, g, 0); } else M(new T.CylinderGeometry(0.13, 0.13, 0.36, 10), toon(['#c2410c', '#e6b45a', '#7a3a1a', '#3a6ea5'][k % 4]), -W / 2 + 0.85, 0.95 + r * 0.7, z, g, 0.01, 0.13); }
  const menu = new T.Mesh(new T.PlaneGeometry(3.4, 1.7), new T.MeshBasicMaterial({ map: ctx.canvasTex(512, 256, c => { c.fillStyle = '#201e1d'; c.fillRect(0, 0, 512, 256); c.strokeStyle = '#e6b45a'; c.lineWidth = 8; c.strokeRect(6, 6, 500, 244); c.fillStyle = '#fbf3e0'; c.font = '900 44px Archivo, Arial'; c.fillText('THE BAR', 24, 58); c.font = '800 30px Archivo, Arial'; ['HARIRA · 14', 'MINT TEA · 6', 'PASTRY · 8', 'WATER IS FREE'].forEach((s, i) => c.fillText(s, 24, 108 + i * 38)); }) })); menu.position.set(-W / 2 + 0.42, 3.4, bz); menu.rotation.y = Math.PI / 2; g.add(menu);
  // FOOSBALL table (the 2D minigame) in the middle-left
  const fx = -1.5, fz = -3.5; B(2.6, 0.8, 1.5, toon('#2a6a3a'), fx, 0.2, fz); B(2.7, 0.15, 1.6, woodL, fx, 1.0, fz); for (const [a, b] of [[-1.1, -0.6], [1.1, -0.6], [-1.1, 0.6], [1.1, 0.6]]) B(0.14, 0.9, 0.14, wood, fx + a, 0, fz + b);
  for (let i = 0; i < 8; i++) { const r = M(new T.CylinderGeometry(0.03, 0.03, 2.4, 6), toon('#d7dde3'), fx - 1.05 + i * 0.3, 1.05, fz, g, 0); r.rotation.x = Math.PI / 2; for (let k = -1; k <= 1; k++) B(0.08, 0.3, 0.1, i % 2 ? red : toon('#3a6ea5'), fx - 1.05 + i * 0.3, 0.85, fz + k * 0.4); }
  // DARTBOARD on the east wall + the oche line; JUKEBOX in the south-east corner (glowing)
  const dz = 2.5; const db = M(new T.CylinderGeometry(0.45, 0.45, 0.08, 24), ink, W / 2 - 0.5, 2.1, dz, g, 0.02, 0.45); db.rotation.z = Math.PI / 2; for (const [r, c] of [[0.36, '#c42d3c'], [0.24, '#f2e6c8'], [0.12, '#2a6a3a'], [0.04, '#c42d3c']]) { const d = M(new T.CylinderGeometry(r, r, 0.09, 24), toon(c), W / 2 - 0.5, 2.1, dz, g, 0); d.rotation.z = Math.PI / 2; }
  B(0.1, 0.02, 1.4, brass, W / 2 - 3.2, 0.1, dz);
  const jx = W / 2 - 1.3, jz = D / 2 - 1.6; B(1.4, 1.9, 0.9, toon('#7a1d2a'), jx, 0, jz); const top = M(new T.CylinderGeometry(0.7, 0.7, 0.9, 16, 1, false, 0, Math.PI), new T.MeshBasicMaterial({ color: '#ffb347' }), jx, 1.9, jz, g, 0); top.rotation.z = Math.PI / 2; top.rotation.y = Math.PI / 2; B(1.0, 0.8, 0.05, new T.MeshBasicMaterial({ color: '#ffe7a3' }), jx, 0.7, jz - 0.46);
  // round tables with low stools and a lantern on each
  for (const [x, z] of [[-3, 3], [3, 4.5], [5.5, -0.5], [-5, 8], [1.5, 8.5]]) { M(new T.CylinderGeometry(0.9, 0.9, 0.08, 18), woodL, x, 0.95, z, g, 0.02, 0.9); M(new T.CylinderGeometry(0.1, 0.14, 0.9, 8), wood, x, 0.45, z, g, 0.01, 0.12); M(new T.BoxGeometry(0.22, 0.3, 0.22), new T.MeshBasicMaterial({ color: '#ffcf7a' }), x, 1.15, z, g, 0); for (let a = 0; a < 3; a++) M(new T.CylinderGeometry(0.28, 0.28, 0.5, 12), red, x + Math.cos(a * 2.1 + 0.4) * 1.35, 0.25, z + Math.sin(a * 2.1 + 0.4) * 1.35, g, 0.01, 0.28); }
  // hanging brass lanterns + a warm light
  for (const [x, z] of [[-4, -4], [2, -4], [-4, 4], [3, 3], [0, 9]]) { M(new T.CylinderGeometry(0.02, 0.02, 1.2, 4), ink, x, bd.ceil - 0.6, z, g, 0); M(new T.BoxGeometry(0.4, 0.5, 0.4), new T.MeshBasicMaterial({ color: '#ffcf7a' }), x, bd.ceil - 1.45, z, g, 0); }
  const L = new T.PointLight(0xffd8a0, 1.6, 26, 1.2); L.position.set(0, bd.ceil - 1.2, 0); g.add(L);
  const solids = [[bx - 0.7, bx + 0.75, bz - 4.6, bz + 4.6], [-W / 2, -W / 2 + 1.05, bz - 4.6, bz + 4.6], [fx - 1.4, fx + 1.4, fz - 0.85, fz + 0.85], [jx - 0.75, jx + 0.75, jz - 0.5, jz + 0.5]].concat([[-3, 3], [3, 4.5], [5.5, -0.5], [-5, 8], [1.5, 8.5]].map(([x, z]) => [x - 0.95, x + 0.95, z - 0.95, z + 0.95]));
  return { g, bar: [bx - 0.1, bz], walk: (x, z) => !solids.some(s => x > s[0] - 0.3 && x < s[1] + 0.3 && z > s[2] - 0.3 && z < s[3] + 0.3) && !(Math.abs(x - px) < 3.75 && Math.abs(z - pz) < 3.75) };
}

// stand-in keeper (CLAUDE.md: a coloured box fox until the merge) — idles and waves when you come in
function standIn(T, col, name) { const g = new T.Group(), mt = c => new T.MeshToonMaterial({ color: c }), O = mt(col), Wt = mt('#f4f1ec'), D = mt('#201e1d'), m = (w, h, d, mat, x, y, z, p = g) => { const o = new T.Mesh(new T.BoxGeometry(w, h, d), mat); o.position.set(x, y, z); p.add(o); return o; };
  m(0.26, 0.9, 0.3, D, -0.2, 0.45, 0); m(0.26, 0.9, 0.3, D, 0.2, 0.45, 0); m(0.8, 0.85, 0.5, O, 0, 1.32, 0); m(0.6, 0.55, 0.58, mt('#f07a2a'), 0, 2.02, 0.02); m(0.3, 0.22, 0.34, Wt, 0, 1.94, 0.42);
  for (const x of [-0.2, 0.2]) { const e = new T.Mesh(new T.ConeGeometry(0.15, 0.36, 4), mt('#f07a2a')); e.position.set(x, 2.45, 0); e.rotation.y = Math.PI / 4; g.add(e); }
  const arm = new T.Group(); arm.position.set(0.48, 1.65, 0); g.add(arm); m(0.18, 0.7, 0.2, O, 0, -0.35, 0, arm);
  const c = document.createElement('canvas'); c.width = 256; c.height = 64; const x = c.getContext('2d'); x.fillStyle = '#201e1d'; x.fillRect(0, 0, 256, 64); x.fillStyle = '#f3f2f2'; x.font = '900 40px Archivo, Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(name, 128, 34);
  const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; const s = new T.Sprite(new T.SpriteMaterial({ map: t, toneMapped: false })); s.scale.set(1.6, 0.4, 1); s.position.y = 3.05; g.add(s);
  return { g, arm }; }

for (const k of Object.keys(DRESS)) if (!FIT[k]) FIT[k] = { keepFloor: true, build: (m, ctx, T, bd) => DRESS[k](T, ctx, bd) };

export function createRooms(THREE, world, { touch = false } = {}) {
  const rooms = [];
  for (const d of world.doors) { const F = FIT[d.key]; if (F) rooms.push({ key: d.key, F, bd: d.bd, door: d, state: 'idle', R: null }); }
  const load = async r => { r.state = 'loading';
    try { const m = r.F.src ? await import(new URL(r.F.src, import.meta.url).href) : null; const host = new THREE.Group(); if (r.F.rot) host.rotation.y = r.F.rot; if (r.F.origin && r.F.rot) host.position.set(r.F.origin[0], 0, r.F.origin[1]); r.bd.grp.add(host);
      const ctx = roomCtx(host, { touch }), R = r.F.build(m, ctx, THREE, r.bd); R.host = host; r.R = R;
      if (r.bd.innerMesh && !r.F.keepFloor) r.bd.innerMesh.visible = false; if (r.bd.innerGlow) r.bd.innerGlow.visible = false; if (R.hideOwn && r.bd.shellMesh) r.bd.shellMesh.visible = false;
      R.keeperObjs = (R.keepers || []).map(k => { const s = standIn(THREE, k.col, k.name); s.g.position.set(k.at[0], 0.09 + (k.y || 0), k.at[1]); s.g.rotation.y = k.face || 0; if (k.seat) s.g.scale.setScalar(0.92); r.bd.grp.add(s.g); return { ...k, ...s, ph: Math.random() * 6 }; });
      r.state = 'ready'; } catch (e) { console.error('room ' + r.key, e); r.state = 'error'; r.err = e.message; } };
  const local = (bd, x, z) => { const c = Math.cos(bd.ry), s = Math.sin(bd.ry), dx = x - bd.cx, dz = z - bd.cz; return [dx * c - dz * s, dx * s + dz * c]; };
  let t = 0;
  return {
    rooms,
    update(dt, fox, cam) { t += dt;
      for (const r of rooms) { const dist = Math.hypot(fox.x - r.door.at[0], fox.z - r.door.at[1]); if (r.state === 'idle' && dist < 45) load(r);
        if (r.state !== 'ready') continue; const R = r.R, [lx, lz] = local(r.bd, fox.x, fox.z), inside = Math.abs(lx) < r.bd.W / 2 && Math.abs(lz) < r.bd.D / 2, [cx, cz] = cam ? local(r.bd, cam.x, cam.z) : [0, 0], camIn = Math.abs(cx) < r.bd.W / 2 && Math.abs(cz) < r.bd.D / 2;
        // PHONE BUDGET: a walled room only draws while you are in it or at its door (you cannot see in from outside); open yards draw from 45 m
        const near = r.F.open ? dist < 45 : inside || camIn || dist < 9; const show = near && !r.hidden; R.host.visible = show; for (const e of R.extra || []) e.visible = show; for (const k of R.keeperObjs) k.g.visible = show; if (!show) continue;   // r.hidden: a game in WORLD MODE is showing its own copy of this room
        for (const o of R.hideIn || []) o.visible = !(inside || camIn);
        if (R.tick) R.tick(dt, t);
        for (const k of R.keeperObjs) { k.ph += dt; const wave = inside && Math.hypot(lx - k.at[0], lz - k.at[1]) < 7; k.arm.rotation.z = wave ? 2.4 + Math.sin(k.ph * 8) * 0.5 : Math.sin(k.ph * 1.3) * 0.08; k.g.position.y = 0.09 + (k.y || 0) + Math.abs(Math.sin(k.ph * 1.6)) * 0.03; } } },
    // true = the room's own walls / furniture block this point (only inside a loaded room's footprint)
    block(x, z) { for (const r of rooms) { if (r.state !== 'ready') continue; const [lx, lz] = local(r.bd, x, z); if (Math.abs(lx) < r.bd.W / 2 - 0.05 && Math.abs(lz) < r.bd.D / 2 - 0.05) return !r.R.walk(lx, lz); } return false; },
    // the camera box for the part of the room the fox is in (building-local), or null
    camRect(bd, lx, lz) { const r = rooms.find(r => r.bd === bd && r.state === 'ready'); if (!r || !r.R.cams) return null; for (const c of r.R.cams) { if (!c) return null; if (lx > c[0] - 0.5 && lx < c[1] + 0.5 && lz > c[2] - 0.5 && lz < c[3] + 0.5) return c; } return null; },
  };
}
