# KUFA — LAYOUT NOTES (world chat)

## Where we are (2026-10-22, session 1) — scroll down: PHASE 3 + PHASE 4 are now built
- PHASE 1 LAYOUT: done. `layout/kufa.layout.json` version 5 passes the checker: 0 FAIL, 0 WARN, all 71 keys from the 2D file accounted for.
- PHASE 2 EXTERIORS: first full pass done in `Kufa World.dc.html` (+ `worlds/kufa-walk.js`). **Next: Ben walks the town (phone first) and says OK or what to change.** No interiors yet.

## Ben decided (this session)
- Keep going without a question round. Build the MAP only: no avatars, no story, no quests. New storyline later; the 2D file is the source of names and places.
- Bring in the minigame interiors that belong to Kufa and build the outsides round them. Games must play IN the world, with no load screen and without leaving the map.
- If a game room comes with its own avatars, bring them along for now. They get replaced with the newest versions at the merge.
- Every DRAFT name stays as drafted for now (Scorpion Hollow, Brass Astrolabe, Water Bank, Watch House, Sand & Fire Brigade, Kufa Crier, Oasis Infirmary, Courtyard House, Brass & Blade, Dune Rides, Ostrich Stable, Sand Dock = the 2D "Kufa Dock"). Ben can rename any of them.

## Fixed against the 2D file (surface_kufa.html)
- There is no `var SCENE` list in this 2D file, so the checker reads every quoted `kufaXxx` key: 24 scenes (23 rooms + kufaSpacedock), NPC keys and a few story flags.
- Town square shops placed like the 2D lobbies. North row: Tavern (west), Creamery (east). South row: Armory and Item Shop (west), Spy Shop (east). In the 2D file the "item-shop" lobby opens the Spy Shop and the "spy-shop" lobby opens the Item Shop (flag kufaShopsSwapped). The layout follows what you SEE (sign ITEMS = Item Shop).
- Ummi's Camel Pen moved BELOW (south of) the bazaar stalls, a dead end, as in the 2D file.
- NPC spots now use the 2D keys verbatim (`from2d`, with the 2D name). Keepers are inside their rooms: kufaBarkeep (Nasrin), kufaTrader (Hadi), kufaSmith (Zohra), kufaSpy (Rafiq), kufaCreamer (Jamil), kufaEmir, kufaCaptain, kufaFaruq. Tavern customers: kufaSura, kufaJibril. Late square: kufaPadCoat + kufaPadG1-4, kufaRukayaPad. Station 9 people sit in their rooms.
- Castle gate guards have no 2D key: kufaNpc01, kufaNpc02 (draft).
- Station 9 (5 rooms) = marker zones under the oasis lake (stacked rows on the map). The way in is the skiff dive at the lake centre.
- `meta.cut` (keys that are not places): 5 story flags (kufaPitchRebuilt, kufaSquareRebuilt, kufaSquareClear, kufaShopsSwapped, kufaSpyBuilt). 5 party followers (kufaKass, kufaKassCut, kufaGhaziA, kufaSaharA, kufaRafiqA). kufaWarden (the Siphon boss, an enemy: its place is gate kufaSiphonRig).

## Game rooms fitted (footprint = the repo room; `fit` on each building says how)
| Building | Repo room | Size | Ready for phase 3/4 |
|---|---|---|---|
| kufaCreamery | g/kufa-creamery · creamery-shift.js buildCreamery | 12 x 10, ceiling 4.2, door at x +3.6 | YES: origin + rotY, solids, walkable, doorWorld, cutaway |
| kufaSpyShop | g/spyshop-of-kufa · spy-shop.js buildSpyShop | front 10.4 x 8.4 + back room 4.8 x 4.6 | origin + walk data yes; needs a rotY |
| kufaTavern | g/backgammon-club · buildParlor | parlour 7.2 x 7.2 as a back room of the 28 x 24 hall | room yes; no door, no world mode |
| kufaDominoes | g/dominoes-club · buildParlor | 7.2 x 7.2 + an outdoor arcade porch | room yes; cut a door; no world mode |
| kufaCamelPen | minigames/kufa/camel-pen.js buildCamelPen | yard 18.8 x 13.7, gate on its -x wall (turned to face the lane) | room yes; no world mode |
| kufaStadium | minigames/kufa/soccer-cup.js | pitch 38 x 22 + stands on 3 sides; open south gate | split the pitch out of createSoccer |
| kufaFoxFarm | g/fox-farm · farm.js | plots in the field south of the farmhouse (up to 35 x 10) | YES: real world mode already |

## Phase 2 exteriors: what is in Kufa World.dc.html
- One connected desert: dune hills, the dry wadi with a bridge on the Castle Path, the turquoise oasis with reeds, the skiff and the dive buoy.
- Lamps along every path: brass lanterns, hanging lanterns or palms. Palms only where the layout puts them (water, shade, courts). Paths are pale stone with dark curbs so they are easy to see.
- Every building has its own outside from its "outside" note, a BIG ROOF SIGN and an EYE-LEVEL DOOR SIGN (2 m). NOW HIRING boards show where there is a job.
- Walk-in sliding glass doors with gold frames and a chime. Inside, the roof and roof sign hide, the camera stays in the room, and the gold X-ray fox shows through walls. The castle keep uses a quick fade. The camel pen and the stadium are open air with walk-in gates.
- Pads: the royal helipad + royal teleport pad (→ Kufa Dock), plus 3 helipads (Way Station, Stadium, Infirmary). The ostrich and kangaroo boots spots. Battle arches and the cave. The space dock.
- GO TO menu, DAY / NIGHT (windows and lanterns light up), and phone frames 390x844 / 844x390. MAP: MY DRAFT walks Ben's Map Workshop draft.
- Phone budget: about 120 draw calls from the town square, about 280k triangles. Static parts are merged, palms instanced, door panels instanced.
- Interiors are empty lit rooms with a plaque: "ROOM COMES IN PHASE 3".

## PHASE 3 INTERIORS — pass 1 (2026-10-22, Ben: "please keep going")
Rooms from the repo now stand INSIDE their buildings, walkable, no load screen (`worlds/kufa-rooms.js`):
| Building | What is inside | From (file · function) | Changed |
|---|---|---|---|
| kufaCreamery | the whole Creamery: machine wall, front counter, freezer, seating | minigames/kufa/creamery/creamery-shift.js · buildCreamery | nothing; host passes the building group as its scene |
| kufaSpyShop | front room + false-bookcase back room | minigames/kufa/spyshop/spy-shop.js · buildSpyShop | nothing; origin (0, +2.2) |
| kufaTavern | BACKGAMMON PARLOUR (back room, NE corner) + the hall: bar with menu, foosball, dartboard, jukebox, round tables, lanterns | minigames/kufa/backgammon/backgammon-club.js · buildParlor; the hall is new (worlds/kufa-rooms.js dressTavern) | a doorway cut in the parlour's +z wall (host side, game file untouched) |
| kufaDominoes | the Dominoes parlour | minigames/kufa/dominoes/dominoes-club.js · buildParlor | doorway cut (host side) |
| kufaCamelPen | Ummi's yard: stalls, trough + pump, bins, canopy, 2 camels | minigames/kufa/camel-pen/camel-pen.js · buildCamelPen + addPenCamels | turned a quarter so its gate faces the lane |
| kufaItemShop · kufaArmory · kufaThroneRoom · kufaBarracks | dressed from the 2D brief (counter + back shelf; forge + racks; nave, dais, throne, treasury; rotunda desk, dorm beds, training dummies) | new (worlds/kufa-rooms.js) | — |
- Copied game files: `minigames/kufa/<game>/` (only import paths changed). Originals: `backup/<game>/*.pre-world.js`.
- `minigames/kufa/kufa-engine.js` = the ONE small adapter the copied files import instead of village-game.js / meru-game.js / engine/* / fox-kit.js (meru-game.js alone pulls the whole Meru world). At the merge: point those imports back at the real engine. The save in it is in memory only (the main project swaps engine/save.js in).
- Keepers = coloured box-fox stand-ins with name tags (Jamil, Rafiq, Nasrin, Sura, Jibril, Ummi, Hadi, Zohra, Emir Tahir, Captain Idris); they idle and wave when you come in. Replaced by the real cast at the merge.
- Phone budget: a walled room only draws while you are in it or at its door; the open camel pen from 45 m. Inside small rooms the camera sits under the ceiling and the fox turns see-through when the camera is close.
- Pass 2 (2026-10-22): `worlds/kufa-interiors.js` furnishes the rest: Bank, Post, Watch House, Fire Station, Crier, Infirmary, Home, Brass & Blade, Relic Shop (Astrolabe), Wagon Hire (Dune Rides), Ostrich Stable and Houses 1–4.
- Was not yet (pass 1): the soccer pitch from soccer-cup.js (no room builder to call; the stadium has our own 38 x 22 pitch for now) · the Fox Farm plots (its world mode builds them in phase 4) · Bank, Post, Watch House, Fire, Crier, Infirmary, Home, houses, Brass & Blade, Astrolabe, Dune Rides, Ostrich Stable (no 2D room and no repo room: plain lit rooms).

## PHASE 4 GAMES IN THE WORLD
### 1. BACKGAMMON — PLAYABLE in the Tavern parlour (2026-10-22) · HANDOFF
- Walk into the parlour (Tavern, back right) → red PLAY BACKGAMMON button (or E) → the camera eases 1.7 s from the walk camera to the game's camera → menu: PIP · HOPE · NOBLE, PASS & PLAY, WATCH (how to play) → tap a checker, tap where it goes (or drag) → BACK (or Esc) eases back and you walk on.
- Play UI (Modernist, dark): card top-left (portrait) / left column (landscape) with status, both sides + pips, dice left, the last move, the opponent's line; bottom bar ROLL · UNDO · HINT · VIEW · red BACK; GAME OVER card PLAY AGAIN · MENU · BACK. The board is framed into the screen part the cards leave free (api.setSafe).
- From the game: `minigames/kufa/backgammon/backgammon-club.js` createBackgammonClub (board, checkers, dice, rules worker, CPU, foxes Pip / Hope / Noble with fox-kit + cast, audio). The parlour room is the world's own (buildParlor, phase 3).
- What changed in the game file (all behind `opts.world`, the page version is untouched): no own renderer / scene background / lights / room / rAF loop; its objects live in a group inside the world parlour; its camera is a child of that group (lookAt + tap rays converted between the table frame and world space); `api.tick(dt)` + `api.camera` added; destroy() removes only its group. Original: backup/backgammon/backgammon-club.pre-world.js.
- Host side: `worlds/kufa-games.js` (start / ease / tick / back) + the play UI in `Kufa World.dc.html`.
- Avatars: fox-kit.js + engine/cast.js, cane.js, chair.js copied unchanged into minigames/kufa/ (Ben: bring them; the newest cast replaces them at the merge). presets/cane.json + chair.json at the project root for Noble's chair + Hope's cane.
- Not wired in the world yet: ONLINE play (it needs engine/duel-net.js + vendor/trystero-nostr.js, cap 4) — the menu leaves it out for now. The game still keeps its own prefs + resume in localStorage (backgammonClub.*), as on its page.

### 2. CREAMERY — PLAYABLE behind the counter (2026-10-22)
- Walk in → PLAY KUFA CREAMERY → the camera eases to the game's own shot → the game's own HUD (intro, shift, cones, orders) over the world. BACK eases out.
- How: the game is built on restaurant-kit createStage. In the world, createStage runs in WORLD MODE (`globalThis.__kufaStageHost`): no own renderer or lights, its scene is a group in the Creamery building, its camera is copied by the world. While it runs, the world's copy of the room, the shell, roof and signs step aside (the game brings its own identical room).
- Panel = `Creamery Play.dc.html`: a copy of the game's page HUD, transparent and click-through, attached to the game the world started.

### 3–7. CISTERN CUP · FOX FARM · DOMINOES (2026-10-22) — see each panel file's first line for what changed
| Game | Where you press PLAY | Panel | Game file changes (all marked `KUFA WORLD:`, the game's own page is unchanged) |
|---|---|---|---|
| The Cistern Cup (soccer) | inside the stadium bowl | Cistern Cup Play | soccer-cup.js: smaller sand floor in the bowl, crowd placed in the game's own frame, pop-up text projected from world space, destroy() safe twice. Own soccer stick + 1 SHOOT / 2 PASS / 3 TACKLE in the panel (the Game HUD import is gone) |
| Fox Farm | in the field behind the farmhouse | Fox Farm Play | farm.js: its world mode was already there; one lens fix. Saves under `farmField.` |
| Dominoes | inside the Dominoes club | Dominoes Play | dominoes-club.js: world mode like Backgammon (group in the club, camera child, taps converted, api.tick + api.camera) |
- The red "← KUFA" button (right edge) is hidden for Fox Farm and Dominoes: their panels have their own BACK.
- Landscape phone: the Cistern Cup intro card is taller than the screen (same card as Ben's page): scroll it to reach PLAY ROUND 1.

### 4–5. SPY SHOP · CAMEL PEN (2026-10-22)
| Game | Where you press PLAY | Panel | Game file changes (`KUFA WORLD:`) |
|---|---|---|---|
| Rafiq's Spy Shop | the front room | Spy Shop Play | spy-shop.js: points converted to the game's room frame (camera shots, rings, backdrop); its walk mode → back to the world; destroy() safe twice, removes its tap listener |
| Ummi's Camel Pen | anywhere in the yard | Camel Pen Play | camel-pen.js: helpers between the world and the turned yard (origin 0.95, rotY 90°); drags follow the finger; destroy() safe twice |
- While a game in a building plays (stage games), the town's gold door frames + glass doors hide too (`world.doorFX` in kufa-walk.js): the game camera may stand outside the shop front.
- Both panels have their own BACK TO KUFA, so the red ← KUFA is hidden for them. ← KUFA now shows only for the Creamery and the Cistern Cup.

### THE THREE JOBS from the plan's "later" list — NEW, open-air, at their layout spots (2026-10-22, all names/numbers DRAFT)
| Job | Spot | What you do | Files |
|---|---|---|---|
| TREASURE DIG | kufaTreasureDig (east dunes) | 6 x 6 roped sand grid (A–F, 1–6). Tap a square or move the big cursor + DIG. Empty holes say HOT / WARM / COLD (big coloured word + ring + rising beeps). 3 rounds (14 / 12 / 10 digs), HINT once per round (costs 2 digs) | minigames/kufa/jobs/treasure-dig.js · Treasure Dig Play · worlds/games/kufaTreasureDig.js |
| WELL TALLY KEEPER | kufaTallyBoard (by the town square) | Jars rise from the well and ride a rail past the STAMP zone. Stamp only FULL jars (own sound per jar type). At the end of each shift Qasim's ledger claims more: get the exact count = CAUGHT HIM. 3 shifts | minigames/kufa/jobs/well-tally.js · Tally Keeper Play · worlds/games/kufaTallyBoard.js |
| CARAVAN PACKER | kufaCaravanBoard (Ghazi's board, bazaar) | Load goods (weights 1–4) into the camel's LEFT or RIGHT bag (panned sounds). Too lopsided and the camel spills. Pottery goes on top. 3 rounds of 45 s, round 3 "Ghazi wants it even" | minigames/kufa/jobs/caravan-packer.js · Caravan Packer Play · worlds/games/kufaCaravanBoard.js |
- Host: `worlds/kufa-games.js` supports open-air games (`spot: true` = a stand-in room at the spot) and `idle` sets (the job's set stands at the spot while you walk; hidden while it plays).
- Rough: jar / item speeds were tuned on a very slow test machine; Qasim and Ghazi are not characters yet (story stays in the main project); the sets have no collisions.

### SPECIAL VEHICLES — OSTRICH + KANGAROO BOOTS, ridden on the map (2026-10-22)
- `worlds/kufa-rides.js`. The models are the Vehicle Workshop's own (`engine/vehicle-fun.js` funKit, copied unchanged to `minigames/kufa/engine/`), scaled up to the test fox.
- OSTRICH waits outside the Ostrich Stable door (its spot is inside the stable). KANGAROO BOOTS wait at the booth on the Stadium Path.
- RIDE (button or E) → stick / WASD steers, faster than walking (ostrich 16 m/s, boots 11 m/s, Shift = sprint). JUMP / FLAP: the ostrich jumps, hold = glide down. The boots bound while you move, each bound in a row higher (up to 5); BIG HOP = a high hop. GET OFF (or E) anywhere. Rides stay outdoors. Leave one 120 m behind and it goes home.
- Simple map version: PECK, DUST KICK, STOMP, DROP-KICK and the real rider poses need the main project's controller + cast (funKit update/press/pose) at the merge.

### FULL QA PASS (2026-10-22): all 10 games + both rides, at 390x844 and 844x390, plus a second game straight after BACK. Fixed:
- Cistern Cup on a landscape phone: the start card could not scroll, so PLAY ROUND 1 was unreachable. Its cards now take touches (`data-pe`); the same fix went into the Creamery and Spy Shop overlays.
- Creamery, Cistern Cup, Camel Pen: BACK no longer blanks the screen during the ease out (their destroy() removed the world's canvas). Creamery: destroy() safe twice (no AudioContext error).
- "← KUFA" moved up under the game's top bar and now needs TWO taps (TAP AGAIN TO LEAVE), so a stray thumb never quits a game. It shows again for the Camel Pen and Spy Shop (no way out during a work day before).
- Night: warm light pools on the ground under every lamp and lantern.
- Left as is: Fox Farm's landscape right column scrolls to reach BACK (Ben's page layout).

### GRAPHICS POLISH (2026-10-22, Ben: "more polish to the map graphics") — all in worlds/kufa-walk.js
- Surface detail: one shader patch on the merged materials. It adds plaster and sand grain, wind-blown mottling on open ground, ripples on sand and a soft dark band where walls meet the ground. It fades with distance; phones get a lighter version (no streaks, one grain octave). No textures, no extra draw calls.
- Horizon: two rings of far mesas and buttes (dusty mauve; deep blue-violet at night) and a sun disc that follows the sun light's direction. Stars at night. Birds circle the oasis by day.
- Oasis: drifting sun glints on the water. Drifting sand: soft grains skim the ground around you (day, outdoors).
- Town square: three shade sails (red, teal, gold) with shade patches, and a carpet seller's corner (rugs, rolled carpets, pots, canopy). Visual only: you walk under them.
- Open desert: rock clusters, big outcrops, dry scrub, bleached camel bones (instanced, seeded) kept off every path and out of the districts. Stone way-marker cairns every ~45 m beside the roads help you follow a road.
- Buildings: stepped merlons along every parapet (the Kufa skyline). Skipped behind the front roof sign.
- Budget: about +95k triangles (instanced), +8 draw calls.
- Pass 2 (Ben: "keep polishing the buildings, outside and in"):
  - Outside, on every walled building: a round arch over every window, timber beam ends under the parapet (toron), corner buttresses, mud-brick courses showing where the plaster has worn (shader, patches only), and at every door two glazed pots with clipped bushes plus two brass wall lanterns that cast warm light pools at night.
  - Inside, for the rooms the world furnishes itself (not the repo game rooms): a glazed tile dado (a colour per building) with a brass rail, a two-tone checker tile floor with a border band, thin dark ceiling beams, and arched niches on the side walls.
  - Pass 3 (Ben: "keep polishing the building exteriors"): open painted shutters with louvre lines beside every window (each building its own colour: teal, green, blue, red, olive or ochre); rooftop life picked per building (a roof stair hut, clay water jars, a washing line with coloured cloths) so the skyline varies; roof signs seen from behind are now a planked timber back in a dark frame (they were flat black slabs).
  - Pass 4 (houses): the four houses were near-identical sand, so House 1 is whitewashed, House 2 terracotta and House 4 ochre (set in kufa-walk.js; the layout colour still rules every other building). Houses 1, 2 and 4 have a carved wooden mashrabiya bay on the upper front, Houses 1 and 4 an upper-floor room on the roof, and bougainvillea spills over the parapet of Houses 2 and 4 and the Courtyard House.
  - Fixed: the Armory's thick plinth was a solid block filling the room (the fox stood inside it); the Infirmary's blue band was a solid slab through the rooms; Brass & Blade's bronze front covered its doorway. A probe now checks every room for stray outside parts.


### Walk camera (all outdoors)
- The camera no longer stands inside a building: it slides in toward the fox below the roof line (e.g. behind the farmhouse, in the stadium gate).

## Next
1. Ben walks the town + the rooms (phone portrait, phone landscape, desktop) and gives his notes.
2. PHASE 3, one building at a time, in plan order: Tavern (backgammon parlour + bar/foosball/darts) → Creamery → Stadium pitch → Spy Shop → Camel Pen → Fox Farm → Dominoes. Then the shops with no game (Item Shop, Armory, Bank…).
3. PHASE 4 games in the same order (worlds/kufa.plan.md), the Meru Claw Crane way.

## For Ben to take back to the main project (kit notes)
- The Map Workshop checks without the 2D room list, so it shows 1 WARN (rooms not checked). The Viewer passes with 0.
- Spot `room` local frame used here: metres from the building centre, +z toward the door (same as the repo rooms). Worth adding to PARALLEL_WORLDS.md section 2.
- Zones with `"under": "kufaOasis"` mark interior rooms below the lake (Station 9). The checker has no field for interior-only rooms yet.
